chrome.storage.local.get(["c_user", "fb_token"], function (result) {
  let cUser = result.c_user;
  let fbToken = result.fb_token;

  if (!cUser || !fbToken) {
    console.log("Required data not found in storage");
    return;
  }
  localStorage.setItem("cUser", cUser);
});
toast("Friends are loading please wait", "Information", "green");
var totalCount =0;
let upperGrid;
let lowerGrid;
var timeRange = null;
var posts = [];
var allFriends = [];
var inactiveFriendsList = [];
var likers = [];
var selectedInactiveUsers = [];
var boxes = [];
var friendFromActivity = [];
const url = "https://fb-tool-node.devtrust.biz/graphql";
document.addEventListener("DOMContentLoaded", function () {
  upperGrid = document.getElementById("upperGrid");
  lowerGrid = document.getElementById("lowerGrid");
  chrome.runtime.sendMessage({ action: "friendLists" });

  chrome.runtime.onMessage.addListener(async function (
    message,
    sender,
    sendResponse
  ) {
    if (message.action === "storeFriendListData") {
      const receivedGroupData = message.data?.edges;
      console.log(receivedGroupData,"recicenved")
      const creatFrndList = await createFriendsListItems(receivedGroupData);
    } else {
      console.log(
        "Are you sure you are logged with facebook/ no data found",
        "error",
        "red"
      );
    }
  });
});
async function createFriendsListItems(friends) {
  console.log(friends,"friends")
  if (!friends.length) {
    console.log(
      "Are you sure you are logged with facebook/ no data found",
      "error",
      "red"
    );
  }
  const blockApiCallResponse = await blockApiCall();
  try {
    const adminFacebookId = localStorage.getItem("cUser");
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        query: `
        query GetAllSafeListFriends($adminFacebookId: String) {
          getAllSafeListFriends(adminFacebookId: $adminFacebookId) {
            _id
            safeListuserId
            name
            image
            gender
            isDeleted
            adminFacebookId
          }
        }
                  `,
        variables: {
          adminFacebookId,
        },
      }),
    });

    if (response.ok) {
      const responseData = await response.json();
      const resultData = responseData.data?.getAllSafeListFriends;
      const blackListuserIds = blockApiCallResponse.map(
        (item) => item.blackListuserId
      );
      const safeListuserIds = resultData.map((item) => item.safeListuserId);
      const filteredFriends = friends.filter((friend) => {
        return !(
          blackListuserIds.includes(friend?.node.id) ||
          safeListuserIds.includes(friend?.node.id)
        );
      });
      console.log(filteredFriends, "fliterData");
      boxes = [...filteredFriends];
      createGridItems(upperGrid, boxes, "Add to Safe list");
      totalCount= boxes?.length;
      toast(`${totalCount} Friends Fetched`, "success", "green")
     
      // manageList(filteredFriends);
    } else {
      throw new Error("Network response was not ok.");
    }
  } catch (error) {
    console.error("Error:", error);
  }
}
async function blockApiCall() {
  const url = "https://fb-tool-node.devtrust.biz/graphql";
  const adminFacebookId = localStorage.getItem("cUser");
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      query: `
        query GetAllBlackListFriends($adminFacebookId: String) {
          getAllBlackListFriends(adminFacebookId: $adminFacebookId) {
            _id
            blackListuserId
            name
            image
            gender
            isDeleted
            adminFacebookId
          }
        }
                  `,
      variables: {
        adminFacebookId,
      },
    }),
  });

  if (response.ok) {
    const responseData = await response.json();
    const resultData = responseData.data?.getAllBlackListFriends;
    return resultData;
  }
}

async function addToSaflistFunc(selectedInactiveUsers) {
  console.log(selectedInactiveUsers, "selectedInactiveUsers");
  const selectedFriends = selectedInactiveUsers.map((value) => {
    return {
      id: value?.node?.id,
      name: value?.node?.name,
      gender: value?.node?.gender,
      image: value?.node?.profile_picture.uri,
      adminFacebookId: localStorage.getItem("cUser"),
    };
  });
  if (selectedFriends.length <= 0) {
    return false;
  }
  const url = "https://fb-tool-node.devtrust.biz/graphql";
  const data = {
    input: selectedFriends,
  };

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        query: `
          mutation CreateSafelistFriends($input: [safeUsersInupt]) {
              createSafelistFriends(input: $input) {
                _id
                safeListuserId
                name
                image
                gender
                adminFacebookId
              }
            }
          `,
        variables: data,
      }),
    });

    if (response.ok) {
      const responseData = await response.json();
      const resultData = await responseData.data;

      if (resultData?.createSafelistFriends?.length) {
        console.log("User saved in Safelist", "success", "#00FF4C");
        window.location.reload();
      } else {
        toast("Something went wrong", "error", "red");
      }
    } else {
      throw new Error("Network response was not ok.");
    }
  } catch (error) {
    console.error("Error:", error);
  }
}
window.onload = async function () {
  const url = "https://fb-tool-node.devtrust.biz/graphql";
  const adminFacebookId = localStorage.getItem("cUser");
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        query: `
        query GetAllSafeListFriends($adminFacebookId: String) {
          getAllSafeListFriends(adminFacebookId: $adminFacebookId) {
            _id
            safeListuserId
            name
            image
            gender
            isDeleted
            adminFacebookId
          }
        }
                `,
        variables: {
          adminFacebookId,
        },
      }),
    });

    if (response.ok) {
      const responseData = await response.json();
      const resultData = responseData.data;
      if (resultData?.getAllSafeListFriends?.length) {
        console.log(resultData?.getAllSafeListFriends,"resultData?.getAllSafeListFriends")
        FriendsListItems(resultData.getAllSafeListFriends);
      }
    } else {
      throw new Error("Network response was not ok.");
    }
  } catch (error) {
    console.error("Error:", error);
  }
};

$(document).ready(function () {
  $("#selectAllCheckbox").on("click", function () {
    const isChecked = $(this).prop("checked");
    $(".group-checkbox").prop("checked", isChecked);
    var selectedIds = $(".group-checkbox:checked")
      .map(function () {
        return this.id;
      })
      .get();

    removeSafeList(selectedIds);
  });

  $("#removeFromSafeList").on("click", function () {
    const selectedIds = getSelectedCheckboxIds();
    removeSafeList(selectedIds);
  });
});
function updateSafeList() {
  const selectedIds = getSelectedCheckboxIds();
}

function getSelectedCheckboxIds() {
  return $(".group-checkbox:checked")
    .map(function () {
      return this.id;
    })
    .get();
}

function removeSafeList(selectedIds) {
  const newSelectedIds = selectedIds.filter((id) => {
    return id !== "";
  });

  document
    .getElementById("removeFromSafeList")
    .addEventListener("click", async () => {
      if (!newSelectedIds.length) {
        toast("Please add the user", "error", "red");
        setTimeout(() => {}, 2000);
      }
      const url = "https://fb-tool-node.devtrust.biz/graphql";
      const data = {
        ids: newSelectedIds,
      };
      try {
        const response = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            query: `
                        mutation RemoveFromSafelist($ids: [String]) {
                            removeFromSafelist(ids: $ids) {
                                _id
                                safeListuserId
                                name
                                image
                                gender
                                isDeleted
                            }
                        }
                    `,
            variables: data,
          }),
        });

        if (response.ok) {
          const responseData = await response.json();
          const resultData = responseData.data;
          if (resultData?.removeFromSafelist?.length) {
            // alert("Data deleted successfully");
            toast("Data deleted successfully", "success", "#00FF4C");
            window.location.reload();
            return false;
          }
        } else {
          throw new Error("Network response was not ok.");
        }
      } catch (error) {
        console.error("Error:", error);
        // Handle errors here
      }
    });
}

function FriendsListItems(friends) {
  console.log(friends,"friends")
  createGridItems(upperGrid, friends, "Add to Safe list");
}

function createGridItems(container, data, buttonName) {
  container.innerHTML = "";
 

  data.forEach((values) => {
    const gridItemHTML = `
    <div class="dropdown">
      <div class="user-grid-item d-flex flex-row dropdown dropdown-toggle" data-toggle="modal" data-target="#profileModal" data-id="${
        values?.node?.id
      }"  data-bs-toggle="dropdown" id="dropdownMenuButtonLight"> 
      
        <div class="image">
            <img src="${
              values?.node?.profile_picture.uri
            }" style="border-radius: 50%;" />
        </div>
        <div class="user-info d-flex flex-wrap">
            <div class="name px-2 d-flex flex-wrap" style=" white-space: pre-line;
            text-align: start;"> ${values?.node?.name}</div>
        </div>
      </div>
      <div class="dropdown-menu" aria-labelledby="dropdownMenuButtonLight">
        <a class="dropdown-item" href="${
          values?.node?.url
        }" target="_blank"> View Profile  </a>
        <p class="dropdown-item add-to-safelist-btn"  data-id="${
          values?.node?.id
        }">${buttonName ? buttonName : "Add to Safe list"}</p>
      </div> 
    </div>
    `;
    // Append HTML string to container
    container.innerHTML += gridItemHTML;
  });
  // Add event listeners for "Add to Safe list" buttons
  if (buttonName == "Add to Safe list") {
    const addToSafelistButtons = container.querySelectorAll(
      ".add-to-safelist-btn"
    );
    addToSafelistButtons.forEach((button) => {
      button.addEventListener("click", (e) =>
     
       {  
        e.preventDefault();
        console.log(button,"button")
        addToSafelistClickHandler(button, data)}
      );
    });
  } else {
    const addToSafelistButtons = container.querySelectorAll(
      ".add-to-safelist-btn"
    );
    addToSafelistButtons.forEach((button) => {
      button.addEventListener("click", () =>
        removeToSafelistClickHandler(button, data)
      );
    });
  }
}
function addToSafelistClickHandler(button, data) {
  console.log("fsadfsadfasdf");
  const userId = button.dataset.id;

  // Find the corresponding user in the data array
  const userIndex = data.findIndex((values) => values?.node?.id === userId);
  console.log(userIndex,"userIndex")
  if (userIndex !== -1) {
    // Remove the user from the boxes array
    const removedUser = boxes.splice(userIndex, 1)[0];

    // Check if the user is not already in the selectedInactiveUsers array
    if (!selectedInactiveUsers.some((u) => u.node.id === userId)) {
      // Push the removed user to the selectedInactiveUsers array
      selectedInactiveUsers.push({ ...removedUser });
    }
  }

  createGridItems(upperGrid, boxes, "Add to Safe list");
  createGridItems(lowerGrid, selectedInactiveUsers, "Remove to Safe list");
}
function removeToSafelistClickHandler(button, data) {
  const userId = button.dataset.id;

  // Find the corresponding user in the selectedInactiveUsers array
  const userIndex = selectedInactiveUsers.findIndex(
    (u) => u.node.id === userId
  );

  if (userIndex !== -1) {
    // Remove the user from the selectedInactiveUsers array
    const removedUser = selectedInactiveUsers.splice(userIndex, 1)[0];

    // Check if the user is not already in the boxes array
    if (!boxes.some((values) => values?.node?.id === userId)) {
      // Add the removed user back to the boxes array
      boxes.push({ ...removedUser });
    }
  }

  createGridItems(upperGrid, boxes, "Add to Safe list");
  createGridItems(lowerGrid, selectedInactiveUsers, "Remove to Safe list");
}

$("#select-all-btn").click(function () {
  selectedInactiveUsers = [...boxes, ...selectedInactiveUsers];
  boxes = [];
  createGridItems(upperGrid, boxes);
  createGridItems(lowerGrid, selectedInactiveUsers);
});

$("#de-select-all-btn").click(function () {
  boxes = [...boxes, ...selectedInactiveUsers];
  selectedInactiveUsers = [];
  createGridItems(upperGrid, boxes);
  createGridItems(lowerGrid, selectedInactiveUsers);
});

$("#searchByName").on("input", function () {
  const searchTerm = $(this)?.val()?.toLowerCase();

  const searchedFriends = boxes.filter((friend) =>
    friend?.node?.name?.toLowerCase().includes(searchTerm)
  );

  createGridItems(upperGrid, searchedFriends, "Add to Safe list");
});

document.addEventListener("DOMContentLoaded", (event) => {
  document
    .getElementById("remove-friend-popup")
    .addEventListener("click", () => {
      if (selectedInactiveUsers?.length < 1) {
        alert("please add the list");
      } else {
        addToSaflistFunc(selectedInactiveUsers);
      }
    });
});



function toast(heading, icon, color) {
  $.toast({
    text: "",
    heading: heading,
    icon: icon,
    showHideTransition: "fade",
    allowToastClose: true,
    hideAfter: 3000,
    stack: 5,
    position: "top-right",

    textAlign: "left",
    loader: true,
    loaderBg: color,
    beforeShow: function () {},
    afterShown: function () {},
    beforeHide: function () {},
    afterHidden: function () {},
  });
}
