document.addEventListener("DOMContentLoaded", () => {
  document
    .getElementById("startButton")
    .addEventListener("click", startGroupFetch);
});

function startGroupFetch() {
  chrome.runtime.sendMessage({ action: "fetchGroups" });
}

let selectedValues = [];
// $(document).ready(function () {
const groupsArray = []; // Array to store all groups
let dataTable; // Variable to store DataTable instance

// function createGroupListItems(groups) {
//   const groupsData = groups;
//   // Extract relevant information and create an array of objects
//   const currentGroupsArray = groupsData.map((group) => {
//     return {
//       id: group.node.id,
//       name: group.node.name,
//       profilePictureUri: group.node.profile_picture.uri,
//       groupAddress: group.node.group_address,
//       viewerLastVisitedTime: group.node.viewer_last_visited_time,
//       canViewerSeeSoleAdminTreatment: group.node.can_viewer_see_sole_admin_treatment,
//       isViewerMember: group.node.is_viewer_member,
//     };
//   });
//   console.log("currentGroupsArray", currentGroupsArray);

// Function to create a list item for each group
// function createGroupListItems(groups) {
//   console.log("groups", groups);
//   const table = document.getElementById("allGroupsListing");
//   table.innerHTML = "";

//   groups.forEach((group) => {
//     const { node } = group;
//     const listItem = document.createElement("tr");

//     listItem.innerHTML = `
//     <td>
//       <div class="image_td">
//         <img src="${node.profile_picture.uri}">
//         <label>${node.name}</label>
//       </div>
//     </td>

//       <div class="form-check">
//         <input type="checkbox" class="group-checkbox" data-group-id="${
//           node.id
//         }" data-group-name="${node.name}">
//       </div>
//     </td>
//   `;
//     table.appendChild(listItem);
//   });
// }

// Initialize an array to store selected group IDs
// let selectedGroupIds = [];

// function createGroupListItems(groups) {
//   console.log("groups", groups);
//   const table = document.getElementById("allGroupsListing");
//   table.innerHTML = "";

//   groups.forEach((group) => {
//     const { node } = group;
//     const listItem = document.createElement("tr");

//     listItem.innerHTML = `
//       <td>
//         <div class="image_td">
//           <img src="${node.profile_picture.uri}" style="border-radius: 20px">
//           <label>${node.name}</label>
//         </div>
//       </td>
//       <td>
//         <div class="button-container mx-4">
//           <button class="select-button btn  btn-sm" data-group-id="${node.id}" data-group-name="${node.name}" style="color: black; background-color: #dbdad7;">
//             ${selectedGroupIds.includes(node.id) ? 'Deselect' : 'Select'}
//           </button>
//         </div>
//       </td>
//     `;
//     table.appendChild(listItem);
//   });

//   // Add event listeners to the buttons
//   const selectButtons = document.querySelectorAll(".select-button");
//   selectButtons.forEach((button) => {
//     button.addEventListener("click", () => {
//       toggleSelectState(button);
//       updateSelectedGroupIds();
//     });
//   });
// }

// function toggleSelectState(button) {
//   const groupId = button.getAttribute("data-group-id");
//   const groupName = button.getAttribute("data-group-name");

//   if (selectedGroupIds.includes(groupId)) {
//     // Deselect
//     console.log(`Deselected group: ${groupName} (ID: ${groupId})`);
//     selectedGroupIds = selectedGroupIds.filter(id => id !== groupId);
//   } else {
//     // Select
//     console.log(`Selected group: ${groupName} (ID: ${groupId})`);
//     selectedGroupIds.push(groupId);
//   }

//   // Update button text
//   button.textContent = selectedGroupIds.includes(groupId) ? 'Deselect' : 'Select';
// }

// function updateSelectedGroupIds() {
//   console.log("Selected Group IDs:", selectedGroupIds);
// }
let selectedGroupIds = [];
let groupsData;
function createGroupListItems(groups) {
  groupsData = groups;
  const tableBody = document.getElementById("allGroupsListing");
  tableBody.innerHTML = "";

  groups.forEach((group) => {
    const { node } = group;

    // Check if the group name matches the search input
    const searchInput = document
      .getElementById("searchInput")
      .value.toLowerCase();
    if (node.name.toLowerCase().includes(searchInput)) {
      const listItem = document.createElement("tr");

      listItem.innerHTML = `
        <td>
          <div class="image_td">
            <img src="${node.profile_picture.uri}"  style="border-radius: 20px">
            <label>${node.name}</label>
          </div>
        </td>
        <td>
          <div class="button-container">
            <button class="select-button btn  btn-sm" data-group-id="${
              node.id
            }" data-group-name="${
        node.name
      }" style="color: black; background-color: #dbdad7; font-size:small; width: 70px;">
              ${selectedGroupIds.includes(node.id) ? "Deselect" : "Select"}
            </button>
          </div>
        </td>
      `;
      tableBody.appendChild(listItem);
    }
  });

  // Add event listeners to the buttons
  const selectButtons = document.querySelectorAll(".select-button");
  selectButtons.forEach((button) => {
    button.addEventListener("click", () => {
      toggleSelectState(button);
      updateSelectedGroupIds();
    });
  });
}

function toggleSelectState(button) {
  const groupId = button.getAttribute("data-group-id");
  const groupName = button.getAttribute("data-group-name");
  const groupData = groupsData.find((group) => group.node.id === groupId);
  console.log(groupData, "groupdata");
  // const existingIndex = selectedGroups.findIndex(
  //   (selectedGroup) => selectedGroup.id === groupId
  // );
  if (selectedGroupIds.includes(groupId)) {
    // Deselect
    console.log(`Deselected group: ${groupName} (ID: ${groupId})`);
    selectedGroupIds = selectedGroupIds.filter((id) => id !== groupId);
  } else {
    // Select
    console.log(`Selected group: ${groupName} (ID: ${groupId})`);
    selectedGroupIds.push(groupId);
  }

  // Update button text
  button.textContent = selectedGroupIds.includes(groupId)
    ? "Deselect"
    : "Select";
}

function updateSelectedGroupIds() {
  console.log("Selected Group IDs:", selectedGroupIds);
}

// Add event listener for search input changes
const searchInput = document.getElementById("searchInput");
searchInput.addEventListener("input", () => {
  // Update the group list when the search input changes
  createGroupListItems(groupsData); // Replace 'groupsData' with your actual data source
});
var selectedTimeValue = document.getElementById("customTimeDelay").value;
document
  .getElementById("customTimeDelay")
  .addEventListener("change", function () {
    // Get the selected value
    selectedTimeValue = this.value;

    // Log the selected value for demonstration purposes (you can handle the value as needed)
    console.log(selectedTimeValue);
  });

// // Destroy existing DataTable
// if (dataTable) {
//   dataTable.destroy();
//   $("#example").empty(); // Remove the table from the DOM
// }

// // Add a "Select All" checkbox to the header
// $("#example thead tr").prepend(
//   '<th><input type="checkbox" id="selectAll"></th>'
// );

// // Create DataTable
// dataTable = $("#example").DataTable({
//   data: currentGroupsArray,
//   columns: [
//     {
//       data: null,
//       render: function (data, type, row, meta) {
//         // Add a checkbox for each row
//         return (
//           '<input type="checkbox" class="groupCheckbox" data-id="' +
//           data.id +
//           '">'
//         );
//       },
//     },
//     { data: "id" },
//     {
//       data: null,
//       render: function (data, type, row) {
//         return (
//           '<img src="' +
//           data.profilePictureUri +
//           '" width="60px" height="60px" />'
//         );
//       },
//       orderable: false,
//     },
//     { data: "name" },
//     { data: "viewerLastVisitedTime" },
//   ],
// });

// // Handle "Select All" checkbox change event
// $("#selectAll").on("change", function () {
//   selectedValues = $(this).prop("checked")
//     ? currentGroupsArray.map((group) => ({ id: group.id, name: group.name }))
//     : [];
//   console.log("Selected Values:", selectedValues);
//   $(".groupCheckbox").prop("checked", $(this).prop("checked"));
// });

// // Handle individual checkbox change event
// $("#example").on("change", ".groupCheckbox", function () {
//   selectedValues = $(".groupCheckbox:checked")
//     .map(function () {
//       const currentId = $(this).data("id");
//       const currentGroup = currentGroupsArray.find(
//         (group) => group.id == currentId
//       );

//       // Check if a matching group is found
//       if (currentGroup) {
//         return { id: currentId, name: currentGroup.name };
//       } else {
//         // Handle the case where the group is not found (optional)
//         console.error("Group not found for ID:", currentId);
//         return null; // or handle it according to your requirements
//       }
//     })
//     .get();

//   console.log("Selected Values:", selectedValues);
// });

// // Update the global array with the current data
// groupsArray.length = 0;
// Array.prototype.push.apply(groupsArray, currentGroupsArray);
// // }

document
  .getElementById("removeGroupsButton")
  .addEventListener("click", function (e) {
    e.preventDefault();
    if (selectedGroupIds.length < 1) {
      toast("Please select the groups", "error", "red");
    }else{
      toast("Please wait while removing your groups", "success", "yellow");
      chrome.runtime.sendMessage({
        action: "deleteGroups",
        data: { selectedGroupIds, delay: selectedTimeValue },
      });
    }
    selectedGroupIds=[]

    $("#loadingModal").show();
    setTimeout(() => {
      $("#loadingModal").hide();
      // window.location.reload();
    }, selectedGroupIds?.length * 5 * 1000);
  });

chrome.runtime.onMessage.addListener(async function (
  message,
  sender,
  sendResponse
) {
  console.log(message, "message");
  if ((await message.action) === "storeGroupData") {
    const receivedGroupData = await message.data?.edges;
    if(receivedGroupData){
      toast("Data fetched succesfully", "success", "green");
    }
    createGroupListItems(receivedGroupData);
  }
});

function toast(heading, icon, color) {
  $.toast({
    text: "",
    heading: heading,
    icon: icon,
    showHideTransition: "fade",
    allowToastClose: true,
    hideAfter: 3000,
    stack: 5,
    position: "top-right",

    textAlign: "left",
    loader: true,
    loaderBg: color,
    beforeShow: function () {},
    afterShown: function () {},
    beforeHide: function () {},
    afterHidden: function () {},
  });
}
