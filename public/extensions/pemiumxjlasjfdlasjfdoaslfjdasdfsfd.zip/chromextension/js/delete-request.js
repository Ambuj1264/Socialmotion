
var removeSelector = document.getElementById("removeSelector");
var findDataOfSelectionOfProcess = removeSelector.value;
var requestSelectionForNumber;

if (!((document.getElementById("removeSelector")?.value) == 3)) {
  document.getElementById("numberOfFriends").style.display = "none";
}

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("removeSelector").addEventListener("change", (event) => {
     findDataOfSelectionOfProcess = event.target.value;
    const numberOfFriendsElement = document.getElementById("numberOfFriends");
    console.log(numberOfFriendsElement, "numberofFriendsElements")
    if (findDataOfSelectionOfProcess == "3") {
      numberOfFriendsElement.style.display = "block";
    } else {
      numberOfFriendsElement.style.display = "none";
    }
  });
});

document.getElementById("start").addEventListener("click", dataValidate);
document.getElementById("stop").addEventListener("click", () => {
  sendReq("stop", null);
});

// Function to send a request to a specific tab
// function sendReq(event, data) {
//   console.log(data,"data")
//   chrome.storage.local.set({ ["task"]: "delete" });
//   chrome.tabs.create(
//     { url: "https://www.facebook.com/friends/requests" },
//     (tab) => {
//       // Once the tab is updated & fully loaded, we will scrape the localStorage
//       chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
//         if (tabId === tab.id && changeInfo.status === "complete") {
//           chrome.tabs.sendMessage(tab.id, { event: "delete", data: data });
//         }
//       });
//     }
//   );
// }
function checkRequestForFriendRequest() {

  chrome.storage.local.set({ ["task"]: "scrapeFriendRequestData" });

  // Calculate the centered position
  const screenWidth = screen.availWidth;
  const screenHeight = screen.availHeight;
  const popupWidth = 750;
  const popupHeight = 700; // Adjust the height as needed

  const left = Math.round((screenWidth - popupWidth) / 2);
  const top = Math.round((screenHeight - popupHeight) / 2);


  chrome.windows.create({
    url: "https://m.facebook.com/friends/center/requests/all",
    type: "popup",
    width: popupWidth,
    height: popupHeight,
    left: left,
    top: top,
  }, window => {
    // Once the window is created, we will scrape the localStorage
    chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
      if (window.tabs && window.tabs[0] && tabId === window.tabs[0].id && changeInfo.status === 'complete') {
        chrome.tabs.sendMessage(tabId, { event: "scrapeFriendRequestData",data:"JAYSHREERAM" });
        chrome.tabs.onUpdated.removeListener(listener); // Remove the listener after it's triggered
        // chrome.storage.local.get("friendRequestData", function (result) {
          chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            if (message.event === "friendRequestData") {
              const friendRequestData = message.data;
              console.log(friendRequestData, "friendRequestData");
              localStorage.setItem("friendRequestData",friendRequestData)
              // Do something with the scraped data (e.g., store it in storage.local)
              chrome.storage.local.set({ friendRequestData: friendRequestData? friendRequestData: 0 });
              var pendingRequest = document.getElementById("pendingRequest");

          
              function extractNumberFromString(inputString) {
                // Use regular expression to extract numbers
                const matches = inputString?.match(/\d+/);
              
                // Check if there are matches and return the first one, otherwise return 0
                return matches ? parseInt(matches[0], 10) : 0;
              }
             var requestData=   extractNumberFromString(friendRequestData?.friendRequestCount);
             if (pendingRequest) {
            
              pendingRequest.innerText = requestData;
            } else {
              console.error("Element with id 'pendingRequest' not found or is not an element that can have innerText.");
            }
            }
          });
          // var friendRequestData =  localStorage.getItem("friendRequestData")?.friendRequestData
          // Make sure pendingRequest is defined and is an element that can have innerText
         
        // });
    
      }
    });
  });
}


// Function to handle the received data
function handleFriendRequestData(data) {
  // Do something with the received data
  console.log("Received friendRequestData in main.js:", data);
}



  document.getElementById("refresh-btn-for-delete-request").addEventListener("click", () => {
    checkRequestForFriendRequest();
  });
function sendReq(event, data) {
console.log(data,"data,================")
  chrome.storage.local.set({ ["task"]: "delete" });

  // Calculate the centered position
  const screenWidth = screen.availWidth;
  const screenHeight = screen.availHeight;
  const popupWidth = 750;
  const popupHeight = 700;

  const left = Math.round((screenWidth - popupWidth) / 2);
  const top = Math.round((screenHeight - popupHeight) / 2);
  console.log(data,"data")
  if(data?.workType==2){
    chrome.windows.create({
      url: "https://m.facebook.com/friends/center/requests/all",
      type: "popup",
      width: popupWidth,
      height: popupHeight,
      left: left,
      top: top,
    }, window => {
      // Once the window is created, we will scrape the localStorage
      chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
        if (window.tabs && window.tabs[0] && tabId === window.tabs[0].id && changeInfo.status === 'complete') {
          chrome.tabs.sendMessage(tabId, { event: "delete", data: data });
          chrome.tabs.onUpdated.removeListener(listener); // Remove the listener after it's triggered
        }
      });
    });
  }
  else{
    chrome.windows.create({
      url: "https://www.facebook.com/friends/requests",
      type: "popup",
      width: popupWidth,
      height: popupHeight,
      left: left,
      top: top,
    }, window => {
      // Once the window is created, we will scrape the localStorage
      chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
        if (window.tabs && window.tabs[0] && tabId === window.tabs[0].id && changeInfo.status === 'complete') {
          chrome.tabs.sendMessage(tabId, { event: "delete", data: data });
          chrome.tabs.onUpdated.removeListener(listener); // Remove the listener after it's triggered
        }
      });
    });
  }
  
}

// Attach input event listeners to all input and select elements
document.querySelectorAll("input, select").forEach((ele) => {
  ele.addEventListener("input", handleInputChange);
});

function handleInputChange(e) {
  const { id, value, checked } = e.target;
  let savingVal = id === "isOnbetweenFriends" ? checked : value;

  if (id === "betweenFriends") {
    document.getElementById("betweenReqShow").innerText = value;
  }

  chrome.storage.local.set({ [id]: savingVal });
}


// Function to update the display based on the checkbox state
function updateBetweenFriendsDisplay(isOn) {
  const displayStyle = isOn ? "flex" : "none";
  document.getElementById("betweenFriendsDiv").style.display = displayStyle;
  document.getElementById("isOnbetweenFriends").checked = !!isOn;
}

// Validate data before sending the request
function dataValidate() {
  var errors = [];
  const fields = ["numberOfFriendsss"];
  fields.forEach((field) => {
    if (!document.getElementById(field).value ) {
      errors = [];
      errors.push(`Field is required`);
    }
    else if((document.getElementById(field)?.value<1)){
      errors=[];
      errors.push(`Number of Request is less than 1`);
    }
    else if((document.getElementById(field)?.value>1000)){
      errors=[];
      errors.push(`Maximum 1000 request allowed`);
    }
  });

  console.log(errors.length,"errors.lenghth")
  if (errors.length) {
    document.getElementById("showError").innerText = errors.join(", ");
  } else {
    document.getElementById("showError").innerText = "";
    sendReq("start", gatherFormData());
  }
}

function gatherFormData() {
  return {
    task: "delete", // or dynamically get the task
    friends: document.getElementById("numberOfFriendsss").value,
    minDelay: 10,
    maxDelay: 15,
    isOnbetweenFriends: false,
    betweenFriends: 0,
    betweenDelay: 0,
    workType: findDataOfSelectionOfProcess
  };
}



function navigate(url) {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.update(tabs[0].id, { url });
  });
}
