// post_select.js
if (window.location.href.includes('post_select=select')) {
    document.addEventListener('DOMContentLoaded', function () {
        scrollToFeed();
        console.log('Executing code in the context of post_select=select');

        async function scrollToFeed() {
            // await sleep(1000);
            const feedSelector = document.querySelectorAll(".feed")[0];
            // console.log("feedselector", feedSelector);
            let offsetHeight = await feedSelector?.offsetTop;
            if (!offsetHeight) {
                await sleep(1000);
                scrollToFeed();
            }
            else {
                // console.log(`Scroll to ${offsetHeight}`);
                // console.log(`Scroll to 2 : ${feedSelector.offsetHeight}`);
                window.scrollTo({
                    top: offsetHeight,
                    behavior: "smooth",
                });
                addSelectButton();
            }
        }


        async function addSelectButton() {
            // console.log("btn select");
            let feedSelector = "._7k7.storyStream._2v9s";
            let postParent = "article[class='_55wo _5rgr _5gh8 async_like']";

            // Find all matching posts and append a button to each of them
            $(`.feed > ${feedSelector} > ${postParent} .story_body_container header`).each(function () {
                let selectPostBtn = document.createElement('button');
                selectPostBtn.innerHTML = 'Select Post';
                selectPostBtn.classList.add('btn', 'btn-outline-primary');
                selectPostBtn.style.height = "34px";
                selectPostBtn.style.position = "relative";
                selectPostBtn.style.top = "18px";
                selectPostBtn.style.border = "none";


                // Append the button to the current post
                $(this).append(selectPostBtn);

                // Add an event listener to the button
                selectPostBtn.addEventListener('click', function () {
                    let postUrl = $(this).closest('.story_body_container').find('[aria-label="Open story"]')[0].href;
                    console.log('click event', postUrl);
                    // Send the url data to the extension
                    chrome.runtime.sendMessage({ action: 'sendInputText', data: postUrl });
                });
            });
        }

    })
    function sleep(t) {
        return new Promise((e) => setTimeout(e, t));
    }
}

