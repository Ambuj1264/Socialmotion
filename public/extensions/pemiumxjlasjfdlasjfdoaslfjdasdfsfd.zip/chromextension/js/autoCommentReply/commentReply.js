let replys = [];
let popupWindowId = null;
function saveDefaultSettings(e) {

    // var sleep_after = $('#sleep_after').val();
    // var sleep_for = $('#sleep_for').val();
    // var offer_link = $('#offer_link').val();
    console.log('Saving default settings')
    var seconds = $('#seconds').val();
    // var max_reply = $('#max_reply').val();

    // var sleep_after = 150;
    // var sleep_for = 60;
    // var offer_link = $('#offer_link').val();
    // var seconds = 10;
    // var max_reply = 100;
    console.log(seconds);

    chrome.storage.sync.set({
        // 'offer_link': offer_link,
        'seconds': seconds,
        // 'sleep_after': sleep_after,
        // 'sleep_for': sleep_for,
        // 'max_reply': max_reply
    }, function () {
        console.log('Default Settings saved');
    });
}


$(document).ready(function(){
    $("#reply-popup").click(function(){
      $("#reply_modal").modal();
    });
    $("#filter-popup").click(function(){
        $("#filter_modal").modal();
      });
  });



document.addEventListener("DOMContentLoaded", () => {
    
    /////* Show Reply Texts onLoad */////
    var reply_bytes = '';

    function replyBytes(bytes) {
        reply_bytes = bytes;
    }
    // gets the number of bytes used in sync storage area
    chrome.storage.sync.getBytesInUse(['replys'], replyBytes);
    chrome.storage.sync.get('replys', items => {
        replys = items.replys || [];
        if (reply_bytes != 0) {
            const replys = items.replys;
            Object.keys(replys).forEach(key => {
                var reply = replys[key];
                var reg = /'/g;
                var newstr = "";
                var datareply = reply.replace(reg, newstr);

                $(".saved_replys").prepend("<p class='saved_tags'  data-url='" + datareply + "'>" +
                    reply +
                    " <button class='btn btn-sm btn-default float-right remove_reply' style='padding: 1px 4px;'><small style='padding: 2px'>x</small></button>" +
                    "</p>");
            });

            if (!replys.length) {
                $(".saved_replys").prepend('<p class="text-center text-danger nothing_text">Please add some replies</p>');

            }
        } else {
            $(".saved_replys").prepend('<p class="text-center text-danger nothing_text">Please add some replies</p>');
        }
    });

    /////* Add New Reply Text */////
    $(document).on('click', '#submit_reply', function (e) {
        e.preventDefault();

        chrome.storage.sync.getBytesInUse(['replys'], replyBytes);
        chrome.storage.sync.get('replys', items => {
            // let replys = [];
            replys = [];
            if (reply_bytes != 0) {
                replys = items.replys;
                //console.log(replys);
            }
            let reply_input = $('#reply_text');
            if (reply_input.val().length > 1) {
                let reply = reply_input.val().replace(/\r?\n/g, '<br />');
                replys.push(reply);
                chrome.storage.sync.set({ replys: replys });
                reply_input.val('');
                var reg = /'/g;
                var newstr = "";
                var datareply = reply.replace(reg, newstr);

                $(".saved_replys").find('.nothing_text').remove();
                $(".saved_replys").prepend("<p class='saved_tags'  data-reply='" + datareply + "'>" +
                    reply +
                    " <button class='btn btn-sm btn-default float-right remove_reply' style='padding: 1px 4px;'><small style='padding: 2px'>x</small></button>" +
                    "</p>");
            }
        });
    });

    /////* Remove Reply Text */////
    $(document).on('click', '.remove_reply', function (e) {

        chrome.storage.sync.getBytesInUse(['replys'], replyBytes);
        chrome.storage.sync.get('replys', items => {
            // let replys = [];
            replys = [];
            if (reply_bytes != 0) {
                replys = items.replys;
                let reply = $(this).closest('p');
                replys.splice(replys.indexOf(reply.data('reply')), 1);
                reply.remove();
                chrome.storage.sync.set({ replys: replys });

                if (!replys.length) {
                    $(".saved_replys").prepend('<p class="text-center text-danger nothing_text">Please add some replies</p>');
                }
            }
        });

    });


    /////* Show Reply Filters onLoad */////
    var reply_filter_bytes = '';

    function replyFilterBytes(bytes) {
        reply_filter_bytes = bytes;
    }

    // gets the number of bytes used in sync storage area
    chrome.storage.sync.getBytesInUse(['reply_filters'], replyFilterBytes);
    chrome.storage.sync.get('reply_filters', items => {

        if (reply_filter_bytes != 0) {
            const reply_filters = items.reply_filters;
            Object.keys(reply_filters).forEach(key => {
                console.log(reply_filters);
                var reply_filter = reply_filters[key];
                $(".saved_reply_filters").prepend("<p class='saved_tags'  data-reply_filter='" + reply_filter + "'>" +
                    reply_filter +
                    " <button class='btn btn-sm btn-default float-right remove_reply_filter' style='padding: 1px 4px;'><small style='padding: 2px'>x</small></button>" +
                    "</p>");
            });

            if (!reply_filters.length) {
                $(".saved_reply_filters").prepend('<p class="text-center text-danger nothing_text">No Filter Text added yet</p>');

            }
        } else {
            $(".saved_reply_filters").prepend('<p class="text-center text-danger nothing_text">No Filter Text added yet</p>');
        }
    });


    /////* Add New Reply Filter */////
    $(document).on('click', '#submit_reply_filter', function (e) {
        e.preventDefault();

        chrome.storage.sync.getBytesInUse(['reply_filters'], replyFilterBytes);
        chrome.storage.sync.get('reply_filters', items => {
            let reply_filters = [];
            if (reply_filter_bytes != 0) {
                reply_filters = items.reply_filters;
                console.log(reply_filters);
            }
            let reply_filter_input = $('#reply_filter');
            if (reply_filter_input.val().length > 1) {
                let reply_filter = reply_filter_input.val();
                reply_filters.push(reply_filter);
                chrome.storage.sync.set({ reply_filters: reply_filters });
                reply_filter_input.val('');

                $(".saved_reply_filters").find('.nothing_text').remove();
                $(".saved_reply_filters").prepend("<p class='saved_tags'  data-reply_filter='" + reply_filter + "'>" +
                    reply_filter +
                    " <button class='btn btn-sm btn-default float-right remove_reply_filter' style='padding: 1px 4px;'><small style='padding: 2px'>x</small></button>" +
                    "</p>");
            }
        });
    });

    /////* Remove Reply Filter */////
    $(document).on('click', '.remove_reply_filter', function (e) {

        chrome.storage.sync.getBytesInUse(['reply_filters'], replyFilterBytes);
        chrome.storage.sync.get('reply_filters', items => {
            let reply_filters = [];
            if (reply_filter_bytes != 0) {
                reply_filters = items.reply_filters;
                let reply_filter = $(this).closest('p');
                reply_filters.splice(reply_filters.indexOf(reply_filter.data('reply_filter')), 1);
                reply_filter.remove();
                chrome.storage.sync.set({ reply_filters: reply_filters });

                if (!reply_filters.length) {
                    $(".saved_reply_filters").prepend('<p class="text-center text-danger nothing_text">No Filter Text added yet</p>');

                }
            }
        });

    });





    // select post btn click
    document.getElementById('selectPostBtn').addEventListener('click', function () {
        // alert('Select Post button clicked!');

        // chrome.tabs.create({ url: "https://m.facebook.com/" }, function (tab) {
        //     chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab2) {
        //         if (changeInfo.status === 'complete' && tabId === tab.id) {
        //             chrome.scripting.executeScript({
        //                 target: { tabId, allFrames: true },
        //                 files: ['js/autoCommentReply/post_select.js'],
        //             });
        //         }
        //     });

        // })
        chrome.windows.create({
            type: 'popup',
            url: 'https://m.facebook.com/profile.php?post_select=select',
            width: 900,
            height: 700,
            left: Math.round(screen.width / 2 - 350),
            top: Math.round(screen.height / 2 - 350)
        }, function (popupWindow) {
            popupWindowId = popupWindow.id
            // console.log('popup', popupWindow);
            // Execute the content script in the new popup window
            // chrome.tabs.executeScript(popupWindow.tabs[0].id, {
            //     allFrames: true,
            //     file: 'js/autoCommentReply/post_select.js',
            // });
            // chrome.scripting.executeScript({
            //     target: { tabId : popupWindow.tabs[0].id, allFrames: true },
            //     files: ['js/autoCommentReply/post_select.js'],
            // });
        });

    });

    // document.getElementById("start-auto-comment").addEventListener("click", () => {
    //     let postUrl = "https://www.facebook.com/permalink.php?story_fbid=pfbid02c7HGXp8vHpuwxvTEqhANCYNgsH2mWk8K9woMqWN9ss1SyDTNVTLsmptMBeKTDm5Ql&id=61554226856258"

    //     chrome.tabs.create({ url: postUrl }, (tab) => {
    //         // console.log("tab------", tab.id);
    //         chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
    //             if (tabId === tab.id && changeInfo.status === "complete") {
    //                 // run on content.js
    //                 chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    //                     chrome.tabs.sendMessage(tabId, {
    //                         action: "startCommentReply",
    //                     });
    //                 });
    //                 // remove listener
    //                 chrome.tabs.onUpdated.removeListener(listener);
    //             }
    //         });

    //     });
    // });

    $(document).on('click', '#start-auto-comment', function (e) {
        console.log("Start auto comment");
        // let save_default = $('#save_default').is(':checked');
        let post_url = $('#post_id').val();
        // console.log(post_url);
        // post_url = "https://m.facebook.com/story.php?story_fbid=pfbid0YZe5ceWZSeZqu7d4xYEdwoRxFYH2VY1Jf7zZe1MkCN356QK8n4k93jwFi9gZ5ojnl&id=61554226856258&eav=AfZ9F9EzQfKdkEowt1B9hWUdY752vwwzjzbocc7Q8d-sUBhz-N7On5213X0wJ9c2WYU&m_entstream_source=timeline&paipv=0"

        // post_url = "https://m.facebook.com/permalink.php?story_fbid=pfbid0YUd6y62YArJPJTMG5K8xz2wgGTfaQNemJb7Bhkm162DpTY1yUqtTR2zQW72UnmZDl&id=61554226856258"
        // console.log(post_url);
        if (post_url.indexOf('m.facebook.com') < 0) {
            alert('Invalid post url!');
            return;
        }

        if (replys.length < 1) {
            alert('Please add a reply');
            return;
        }
        // console.log(replys)

        if (post_url.indexOf('?') > -1) {
            post_url = post_url + "&cf_do_comments=1";
        } else {
            post_url = post_url + "?cf_do_comments=1";
        }

        //if (save_default){
        saveDefaultSettings();
        // }else{
        //
        // }
        chrome.tabs.create({ url: post_url }, function (tab) {
            chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab2) {
                if (changeInfo.status === 'complete' && tabId === tab.id) {
                    // chrome.tabs.executeScript(tab.id, { file: "./comments_script.js" },
                    //     function (result) {
                    //         // Process |result| here (or maybe do nothing at all).
                    //         console.log('result', result);
                    //         chrome.tabs.onUpdated.removeListener((a, b) => {
                    //             //console.log('mana',a,b)
                    //         });
                    //     }
                    // );

                    chrome.scripting.executeScript({
                        target: { tabId, allFrames: true },
                        files: ['js/autoCommentReply/comments_script.js'],
                    });
                }
            });
            // executeScripts(tab.id, [
            //     {file: "js/comments_script.js"},
            // ])
        })

    });



    chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
        if (request.action == "commentReplyComplete") {
            // Handle the data received from content.js
            console.log("Comment reply complete. Number of posts comment:", request.data.numberOfPosts);
        }
        if (request.action === 'sendInputText') {
            let postUrl = request.data;
            // Process the input text as needed
            console.log('Received input text:', postUrl);
            $('#post_id').val(postUrl)
            // Close the popup window using its ID
            if (popupWindowId) {
                chrome.windows.remove(popupWindowId);
                popupWindowId = null; // Reset the popup window ID
            }
        }
    });

});