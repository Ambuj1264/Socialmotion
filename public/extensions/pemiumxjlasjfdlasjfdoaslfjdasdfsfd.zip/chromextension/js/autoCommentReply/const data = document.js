const findTheRightKey = document.querySelector('div[id="u_j_1_mO"] ._6vpk')?.innerText;


const parentDiv = document.querySelector('div[id="u_j_1_mO"] button[value="Delete"]');
console.log(parentDiv,"parentDiv")
const data = parentDiv?.click();

