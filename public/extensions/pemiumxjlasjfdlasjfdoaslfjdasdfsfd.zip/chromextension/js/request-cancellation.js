

document.getElementById("start")?.addEventListener("click", dataValidate);

// Function to send a request to a specific tab
function sendReq(event, data) {
  chrome.storage.local.set({ ["task"]: "cancel" });

  // Calculate the centered position
  const screenWidth = screen.availWidth;
  const screenHeight = screen.availHeight;
  const popupWidth = 750;
  const popupHeight = 800; // Adjust the height as needed

  const left = Math.round((screenWidth - popupWidth) / 2);
  const top = Math.round((screenHeight - popupHeight) / 2);
  console.log(data, "data")
  chrome.windows.create({
    url: "https://www.facebook.com/friends/requests?type=sentreq",
    type: "popup",
    width: popupWidth,
    height: popupHeight,
    left: left,
    top: top,
  }, window => {
    // Once the window is created, we will scrape the localStorage
    chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
      if (window.tabs && window.tabs[0] && tabId === window.tabs[0].id && changeInfo.status === 'complete') {
        chrome.tabs.sendMessage(tabId, { event: "cancel", data: data });
        chrome.tabs.onUpdated.removeListener(listener); // Remove the listener after it's triggered
      }
    });
  });
}

// Attach input event listeners to all input and select elements
document.querySelectorAll("input, select").forEach(ele => {
  ele.addEventListener("input", handleInputChange);
});

function handleInputChange(e) {
  const { id, value, checked } = e.target;
  let savingVal = (id === "isOnbetweenFriends") ? checked : value;

  if (id === "betweenFriends") {
    document.getElementById("betweenReqShow").innerText = value;
  }

  chrome.storage.local.set({ [id]: savingVal });
}

// Load stored data and update UI accordingly
function loadData() {
  chrome.storage.local.get(null, (res) => {
    // Update elements with stored values or defaults
    const fields = ["friends"];
    fields.forEach(field => {
      const element = document.getElementById(field);
      if (element) {
        element.value = res[field] || "";
      }
    });
  });
}




// Validate data before sending the request
function dataValidate() {
  let errors = [];
  const fields = ["friends"];
  fields.forEach(field => {
    if (!document.getElementById(field)?.value) {
      errors.push(`Set ${field}`);
    }
    else if (document.getElementById(field)?.value < 1) {
      errors = []
      errors.push(`Minimum 1 allowed`);
    }
    else if (document.getElementById(field)?.value > 1000) {
      errors = []
      errors.push(`Maximum 1000 allowed`);
    }
  });

  if (errors.length) {
    document.getElementById("showError").innerText = errors.join(", ");
  } else {
    document.getElementById("showError").innerText = "";
    sendReq("start", gatherFormData());
  }
}

function gatherFormData() {
  return {
    task: "cancel", // or dynamically get the task
    friends: document.getElementById("friends")?.value,
    minDelay: 10,
    maxDelay: 20,
    isOnbetweenFriends: false,
    betweenFriends: 10,
    betweenDelay: 10,
    friendsType: document.getElementById("selectData")?.value
  };
}

// Initialize data on page load
document.addEventListener("DOMContentLoaded", loadData);

// Scroll function for arrow button
document?.getElementById("arrowBtn")?.addEventListener("click", () => {
  window.scroll(0, 5000);
});

function navigate(url) {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.update(tabs[0].id, { url });
  });
}