
document.getElementById('messageDeleted').addEventListener('click', function() {
    var inputElement = document.getElementById('messageDeleteCounter');

        var messageDeleteCount = Number(inputElement.value);
    // Send message to the background script
    chrome.runtime.sendMessage({ action: 'messageDeleted',data: messageDeleteCount});
  });

