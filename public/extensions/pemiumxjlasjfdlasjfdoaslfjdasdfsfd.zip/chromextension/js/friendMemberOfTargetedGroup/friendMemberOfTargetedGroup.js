let groupWindowId = null;
let targetKeywords = [];
let avoidKeywords = [];

document.getElementById("fetch_groups").addEventListener("click", () => {
  chrome.runtime.sendMessage({ action: "fetchGroups" });
});

// Function to create a list item for each group
function createGroupListItems(groups) {
  console.log("groups", groups);
  const table = document.getElementById("grouptBodyData");
  table.innerHTML = "";

  groups.forEach((group) => {
    const { node } = group;
    const listItem = document.createElement("tr");

    listItem.innerHTML = `
      <td>
        <div class="image_td">
          <a class="invite-btn" style="text-decoration: none;" target="_blank">
            <img style="text-decoration: none;" src="${
              node.profile_picture.uri
            }">&nbsp;
            <label style="text-decoration: none;">${node.name}</label>
          </a>
        </div>
      </td>
      <td>${new Date(
        node.viewer_last_visited_time * 1000
      ).toLocaleString()}</td>
      <td>${node.id}</td>
      <td>
        <div class="form-check">
          <button type="button" class="btn btn-light" style="font-size: 12px;" data-group-id="${
            node.id
          }" id="${node.id}">Friend Members</button>
        </div>
      </td>
    `;

    table.appendChild(listItem);

    // // Add an event listener for the invite button in each row
    // const inviteButton = listItem.querySelector(".invite-btn");
    // // console.log(inviteButton, "inviteButton");
    // if (inviteButton) {
    //   inviteButton.addEventListener("click", () => {
    //     // Send a message to the content script to simulate a click on the invite button
    //     chrome.tabs.query(
    //       { active: true, currentWindow: true },
    //       function (tabs) {
    //         chrome.tabs.sendMessage(tabs[0].id, {
    //           action: "inviteOwnGroup",
    //           groupId: node.id,
    //         });
    //       }
    //     );
    //   });
    // }

    // Add an event listener for the "Select" button
    const selectButton = listItem.querySelector(".btn-light");
    // console.log(selectButton, "selectButton");
    if (selectButton) {
      selectButton.addEventListener("click", () => {
        // Handle the button click here
        selectButtonClick(node.id);
      });
    }
  });
}

// Function to handle "Select" button click
function selectButtonClick(groupId) {
  let numberOfRequests = Number($("#numberOfRequests").val());
  let thingsInCommonEnabled = $("#thingsInCommon").prop("checked");
  if (!numberOfRequests) {
    toast("Please enter Number of Requests", "error", "red");
    return;
  }
  chrome.storage.sync.set({
    friendMemberTGNoOfRequest: numberOfRequests,
    friendMemberTGTargetKeywords: targetKeywords,
    friendMemberTGAvoidKeywords: avoidKeywords,
  });

  console.log(
    "submitted",
    numberOfRequests,
    "tk",
    targetKeywords,
    "ak",
    avoidKeywords,
    thingsInCommonEnabled
  );

  if (thingsInCommonEnabled) {
    chrome.windows.create(
      {
        type: "popup",
        url: `https://www.facebook.com/groups/${groupId}/members/things_in_common?member_targetedGroup=request`,
        width: 1200,
        height: 800,
        left: Math.round(screen.width / 2 - 600),
        top: Math.round(screen.height / 2 - 400),
      },
      function (popupWindow) {
        groupWindowId = popupWindow.id;
      }
    );
  } else {
    chrome.windows.create(
      {
        type: "popup",
        url: `https://www.facebook.com/groups/${groupId}/members?member_targetedGroup=request`,
        width: 1200,
        height: 800,
        left: Math.round(screen.width / 2 - 600),
        top: Math.round(screen.height / 2 - 400),
      },
      function (popupWindow) {
        groupWindowId = popupWindow.id;
      }
    );
  }

  // https://www.facebook.com/groups/572194013718362/members
  // https://www.facebook.com/groups/572194013718362/members/things_in_common
}

const targetInputEnter = () => {
  let targetInput = $("#target-input").val();
  if (!targetInput) {
    toast("Please Input Target Keyword!", "error", "red");
    return;
  }
  targetKeywords.push(targetInput);
  $("#target-input").val("");
  renderTargetKeywords();
  console.log("Enter target input", targetKeywords);
};

const avoidInputEnter = () => {
  let avoidInput = $("#avoid-input").val();
  if (!avoidInput) {
    toast("Please Input Avoid Keyword!", "error", "red");
    return;
  }
  avoidKeywords.push(avoidInput);
  $("#avoid-input").val("");
  renderAvoidKeywords();
  console.log("Enter avoid input", avoidInput);
};

const renderTargetKeywords = () => {
    console.log("Target Keywords",targetKeywords);
  const targetKeywordsBox = document.getElementById("target-keywords");

  const targetKeywordList = targetKeywords
    .map(
      (value, index) => `
              <span class="py-2">
                  ${value} 
                  <button class="btn btn-danger btn-sm mx-2 remove-target" data-index="${index}" style="font-size:xx-small"> X </button>
              </span>
          `
    )
    .join("");

  targetKeywordsBox.innerHTML = targetKeywordList;
  document.querySelectorAll(".remove-target").forEach((button) => {
    button.addEventListener("click", () => {
      const index = button.getAttribute("data-index");
      removeTargetKeyword(index);
    });
  });
};

function removeTargetKeyword(index) {
  targetKeywords = targetKeywords.filter(
    (val, ind) => ind !== parseInt(index, 10)
  );
  renderTargetKeywords();
}

const renderAvoidKeywords = () => {
  const avoidKeywordsBox = document.getElementById("avoid-keywords");

  const avoidKeywordList = avoidKeywords
    .map(
      (value, index) => `
              <span class="py-2">
                  ${value} 
                  <button class="btn btn-danger btn-sm mx-2 remove-avoid" data-index="${index}" style="font-size:xx-small"> X </button>
              </span>
          `
    )
    .join("");

  avoidKeywordsBox.innerHTML = avoidKeywordList;
  document.querySelectorAll(".remove-avoid").forEach((button) => {
    button.addEventListener("click", () => {
      const index = button.getAttribute("data-index");
      removeAvoidKeyword(index);
    });
  });
};

function removeAvoidKeyword(index) {
  avoidKeywords = avoidKeywords.filter(
    (val, ind) => ind !== parseInt(index, 10)
  );
  renderAvoidKeywords();
}

$(document).ready(function () {
  $("#target-input").keyup(function (event) {
    if (event.key === "Enter") {
      targetInputEnter();
    }
  });
  $("#avoid-input").keyup(function (event) {
    if (event.key === "Enter") {
      avoidInputEnter();
    }
  });

  $("#clearForm").click(()=>{
    targetKeywords = [];
    avoidKeywords = [];
    renderTargetKeywords();
    renderAvoidKeywords();
  })
});

function sleep(t) {
  return new Promise((e) => setTimeout(e, t));
}

function toast(heading, icon, color) {
  $.toast({
    text: "",
    heading: heading,
    icon: icon,
    showHideTransition: "fade",
    allowToastClose: true,
    hideAfter: 3000,
    stack: 5,
    position: "top-right",

    textAlign: "left",
    loader: true,
    loaderBg: color,
    beforeShow: function () {},
    afterShown: function () {},
    beforeHide: function () {},
    afterHidden: function () {},
  });
}

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  console.log(message, "message");
  if (message.action === "storeGroupData") {
    const receivedGroupData = message.data?.edges;
    createGroupListItems(receivedGroupData);
  }
  else if (message.action === "closeFriendMemberOfTargetedGroup"){
    chrome.windows.remove(groupWindowId);
  }
});

