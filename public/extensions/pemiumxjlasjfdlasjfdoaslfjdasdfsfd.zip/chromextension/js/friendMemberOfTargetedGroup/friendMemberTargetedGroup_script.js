// console.log("Starting Post Liker...")
if (window.location.href.includes("member_targetedGroup=request")) {
  var active_status = false;
  let countCompleted = 0;
  let targetKeywordList = [];
  let avoidKeywordList = [];
  let noOfFriendsToRequest = null;
  let countSearchFriends = 0;
  let all_searched_btns = [];
  let searchFinished = false;
  let countFailedRequests = 0;

  chrome.storage.sync.get(null, (items) => {
    // console.log("items", items);
    noOfFriendsToRequest = items.friendMemberTGNoOfRequest;
    avoidKeywordList = items.friendMemberTGAvoidKeywords || [];
    targetKeywordList = items.friendMemberTGTargetKeywords || [];
  });

  // Add the listener
  // chrome.runtime.onMessage.addListener(messageListener);

  $(document).ready(async function () {
    insertControlsHtml();
    $(".cf_stop_btn").hide();
    $(".cf_start_btn").hide();
    $(".cf_cancel_btn").hide();
    $(".cf_start_btn").on("click", function () {
      startProcess();
    });
    $(".cf_stop_btn").on("click", function () {
      stopProcess();
    });
    $(".cf_cancel_btn").on("click", function () {
      cancelProcess();
    });

    all_searched_btns = await searchFriends();
    $(".cf_start_btn").show();
    $(".cf_cancel_btn").show();

    console.log("all selected btns", all_searched_btns);
  });

  function insertControlsHtml() {
    let cont_html = `    <style>
          #cf_controls{
              position: fixed;
              top: 50px;
              right: 100px;
              background: #eee;
              padding: 10px 15px;
              border-radius: 5px;
              box-shadow: 1px 2px 10px rgba(0,0,0,1);
              width: 500px;
              z-index: 999;
              display: flex;
              flex-direction: column;
              align-items: center;
              padding-top: 15px;
              padding-bottom: 15px;
          }
          .cf_text{
              font-size: larger;
              margin-bottom: 10px;
              font-weight: 500;
          }
          .cf_progressInfo{
              font-size: medium;
              margin-bottom: 10px;
              color: green;
          }
          .cf_btn {
            padding: 5px;
            border-radius: 5px;
          }
      </style>
       <div id="cf_controls">
          <div class="header">
              <h3>fb-tool Controls</h3>
              <hr>
          </div>
          <div class="body">
              <div class="buttons">
                  <button class="btn btn-outline-primary cf_btn cf_start_btn">Start</button>
                  <button class="btn btn-outline-primary cf_btn cf_stop_btn" style="display: none">Stop</button>
                  <button class="btn btn-outline-danger cf_btn cf_cancel_btn">Cancel</button>
              </div>
              <div><p class="status_string"></p></div>
          </div>
      </div>
  
    <div class="cf_overlay"></div>
    <div id="cf_controls" class="cf_progressBar">
      <div class="cf_finished">
  
      </div> 
      <div class="cf_text">Ready to start? Click the "Start" button.</div>
      <div class="cf_progressInfo">
        <span class="cf_done status_string">Waiting to begin...</span> 
      </div> 
      <div class="cf_btn_container">
      <button class="btn btn-outline-primary cf_btn cf_start_btn">Start</button>
      <button class="btn btn-outline-primary cf_btn cf_stop_btn">Pause</button>
      <button class="btn btn-outline-danger cf_btn cf_cancel_btn">Cancel</button>
  </div>
    </div>`;

    $(document.body).append(cont_html);
  }

  function updateStatusString() {
    let status_string = "";
    let main_text = "";
    console.log("status_string update count ", countCompleted);
    if (!all_searched_btns.length) {
      stopProcess();
      main_text =
        "Friend request send to " +
        countSearchFriends +
        " targeted Friends Completed.";
      status_string =
        "All Done!, " +
        countCompleted +
        " Friend Requests Success and " +
        countFailedRequests +
        " Failed Requests.";
    } else {
      //   main_text = getMaxReplies() + " comments currently loaded. Replying now...";
      main_text = "Total Number Of Friends: " + countSearchFriends;
      status_string =
        +countCompleted +
        " requests completed and " +
        countFailedRequests +
        " requests failed.";
    }

    $("#cf_controls .status_string").text(status_string);
    $(".cf_text").text(main_text);
  }

  function updateSearchString() {
    let status_string = "";
    let main_text = "";
    console.log("status_string update count ", countSearchFriends);
    if (countSearchFriends >= noOfFriendsToRequest || searchFinished) {
      main_text = "Search Completed.";
      status_string =
        countSearchFriends + " friends found out of " + noOfFriendsToRequest;
    } else {
      //   main_text = getMaxReplies() + " comments currently loaded. Replying now...";
      main_text = "Searching: ";
      status_string = +countSearchFriends + " Users Found";
    }

    $("#cf_controls .status_string").text(status_string);
    $(".cf_text").text(main_text);
  }

  async function startProcess() {
    console.log("startProcess called");

    $(".cf_start_btn").hide();
    $(".cf_stop_btn").show();
    $(".cf_text").text("Fb-Tools Started. Please wait...");

    active_status = true;
    // await sleep(minDelayOnPost * 1000);
    startAction();
  }
  function stopProcess() {
    console.log("stopProcess called");

    active_status = false;
    $(".cf_start_btn").text("Paused... Click to Resume").show();
    $(".cf_stop_btn").hide();
  }

  function cancelProcess() {
    //console.log('cancelProcess called');

    stopProcess();
    $(".cf_overlay").remove();
    $("#cf_controls").remove();

    chrome.runtime.sendMessage({ action: "closeFriendMemberOfTargetedGroup" });
  }
  const startAction = async () => {
    updateStatusString();
    await sleep(2000);

    if (active_status == true && all_searched_btns.length) {
      console.log(all_searched_btns.length, "active length");
      let currentBtn = all_searched_btns.shift();
      await sendFriendRequest(currentBtn);
      await startAction();
    }

    // if (active_status == true && countCompleted < countSearchFriends) {
    // }
  };

  const sendFriendRequest = async (addFriendBtn) => {
    // x1lliihq x6ikm8r x10wlt62 x1n2onr6 xlyipyv xuxw1ft   Add friend .text()
    console.log("sendFriendRequest called", $(addFriendBtn));
    scrollToBtn(addFriendBtn);
    await sleep(2000);
    $(addFriendBtn).click();
    await sleep(2000);
    // console.log("-------", $('div[role="dialog"]'));
    if ($('div[role="dialog"]').find('div[aria-label="Close"]')[0]) {
      $('div[role="dialog"]').find('div[aria-label="Close"]')[0].click();
      countFailedRequests++;
      updateStatusString();
      await sleep(1000);
    } else {
      countCompleted++;
      updateStatusString();
    }
  };

  const searchFriends = async () => {
    let btns = [];
    updateSearchString();
    console.log("searchFriends called");
    let addFriendsBtnSelector =
      "div[aria-label='Add friend']:not(.gone_through)";

    for (; countSearchFriends < noOfFriendsToRequest; ) {
      let initialScrollHeight = document.body.scrollHeight;
      if ($(addFriendsBtnSelector).length < 1) {
        // console.log("Please select", Number.MAX_SAFE_INTEGER);
        window.scrollTo({
          top: Number.MAX_SAFE_INTEGER,
          behavior: "smooth",
        });
        await sleep(2000);
        // Check if the scroll height has changed after waiting
        let currentScrollHeight = document.body.scrollHeight;

        if (currentScrollHeight === initialScrollHeight) {
          console.log("Page has reached the end");
          break;
        }
        await sleep(3000);
      }
      let currentBtn = $(addFriendsBtnSelector)[0];
      console.log("currentBtn: ", currentBtn);

      scrollForSearch();

      let filter = filterTargetFriends(currentBtn);

      if (filter) {
        currentBtn.classList.add("gone_through");
        currentBtn.classList.add("get_matched");
        btns.push(currentBtn);
        countSearchFriends += 1;
        updateSearchString();
      } else {
        currentBtn.classList.add("gone_through");
      }

      console.log("visited", btns.length);
      await sleep(2000);
    }

    searchFinished = true;
    updateSearchString();
    console.log("All visited", btns.length);
    console.log("--", btns);

    return btns;

    // let all_addFriends_btn = $(addFriendsBtnSelector);

    // console.log("searchFriends called", all_addFriends_btn);

    // for (let i = 0; i < all_addFriends_btn.length; i++) {
    //   let currentBtn = all_addFriends_btn[i];

    //   console.log("currentBtn: ", currentBtn);
    //   let filter = filterFriends(currentBtn);

    //   if (filter) {
    //     currentBtn.classList.add("gone_through");
    //     currentBtn.classList.add("get_matched");
    //     btns.push(currentBtn);
    //   } else {
    //     currentBtn.classList.add("gone_through");
    //   }

    //   scrollForSearch();
    //   console.log("visited", btns.length);
    //   await sleep(2000);
    // }
  };

  function filterTargetFriends(addFriendBtn) {
    if (
      (!targetKeywordList || !targetKeywordList.length) &&
      (!avoidKeywordList || !avoidKeywordList.length)
    ) {
      return true;
    }
    let description_text = $(addFriendBtn)
      .closest("div[role='listitem']")
      .find(
        ".x193iq5w.xeuugli.x13faqbe.x1vvkbs.x10flsy6.x1lliihq.x1s928wv.xhkezso.x1gmr53x.x1cpjm7i.x1fgarty.x1943h6x.x1tu3fi.x3x7a5m.x1pg5gke.xvq8zen.xo1l8bm.x12scifz.x1yc453h"
      )
      .text()
      .trim()
      .toLowerCase();

    console.log("dedescription_text", description_text);

    let pass_filter = false;

    if (targetKeywordList && targetKeywordList.length) {
      targetKeywordList.forEach(function (value, index) {
        let filter_text = value.trim().toLowerCase();

        if (description_text.indexOf(filter_text) > -1 && !pass_filter) {
          pass_filter = true;
          //$(reply_btn).closest(comment_selector).css({'background':'yellow'})
        }
      });
    }
    if (avoidKeywordList && avoidKeywordList.length && !pass_filter) {
      pass_filter = true;
      avoidKeywordList.forEach(function (value, index) {
        let filter_text = value.trim().toLowerCase();

        if (description_text.indexOf(filter_text) > -1) {
          pass_filter = false;
          //$(reply_btn).closest(comment_selector).css({'background':'yellow'})
        }
      });
    }

    return pass_filter;
  }

  async function scrollToBtn(targetedAddFriendBtn) {
    let offsetTopRow = await $(targetedAddFriendBtn).closest(
      "div[role='listitem']"
    )[0].offsetTop;
    let offsetHeightRow = await $(targetedAddFriendBtn).closest(
      "div[role='listitem']"
    )[0].offsetHeight;
    let offsetHeightSection = await $(targetedAddFriendBtn).closest(
      ".x1n2onr6.x1ja2u2z.x9f619.x78zum5.xdt5ytf.x2lah0s.x193iq5w.xx6bls6.x1jx94hy"
    )[0].offsetTop;

    window.scrollTo({
      top: offsetTopRow + offsetHeightSection + offsetHeightRow,
      behavior: "smooth",
    });
  }

  const scrollForSearch = async () => {
    let targetedAddFriendBtn = $(
      "div[aria-label='Add friend']:not(.gone_through)"
    );
    if (!targetedAddFriendBtn) {
      // console.log("Please select", Number.MAX_SAFE_INTEGER);
      window.scrollTo({
        top: Number.MAX_SAFE_INTEGER,
        behavior: "smooth",
      });

      await sleep(2000);
      targetedAddFriendBtn = $(
        "div[aria-label='Add friend']:not(.gone_through)"
      );
    }

    let offsetTopRow = await $(targetedAddFriendBtn).closest(
      "div[role='listitem']"
    )[0].offsetTop;
    let offsetHeightRow = await $(targetedAddFriendBtn).closest(
      "div[role='listitem']"
    )[0].offsetHeight;
    let offsetHeightSection = await $(targetedAddFriendBtn).closest(
      ".x1n2onr6.x1ja2u2z.x9f619.x78zum5.xdt5ytf.x2lah0s.x193iq5w.xx6bls6.x1jx94hy"
    )[0].offsetTop;

    window.scrollTo({
      top: offsetTopRow + offsetHeightSection + offsetHeightRow,
      behavior: "smooth",
    });
  };

  function sleep(t) {
    return new Promise((e) => setTimeout(e, t));
  }
}
