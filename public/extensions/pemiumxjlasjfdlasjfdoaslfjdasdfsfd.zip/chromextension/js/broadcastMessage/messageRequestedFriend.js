let allRecentlyAdded = [];
let selectedFriends = [];
let flag = false;

const fetchRecentlyAddedFriends = () => {
    chrome.runtime.sendMessage({ action: "friendsFromActivity", data: "requestSendToUser" });
};

async function p(t, e, s = "json") {
    const a = await fetch(e || "https://www.facebook.com/api/graphql/", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        },
        mode: "cors",
        credentials: "include",
        body: t,
    });
    return "json" === s ? await a.json() : await a.text();
}
function sleep(t) {
    return new Promise((e) => setTimeout(e, t));
}

async function selectTimeRangeUsers() {
    flag = true;
    let selectedtimeRange = document.getElementById("selected-time-range").value;
    const timeRangeInDays = parseInt(selectedtimeRange, 10);

    const currentDate = new Date();
    const timeRangeDate = new Date(currentDate.getTime() - timeRangeInDays * 24 * 60 * 60 * 1000);
    const timeRange = Math.floor(timeRangeDate.getTime() / 1000);

    selectedFriends = allRecentlyAdded.filter(obj =>
        obj.time >= timeRange
    );
    // console.log(selectedFriends,"----.....");
    showSelectedFriends();
}

const showSelectedFriends = () => {
    // console.log(selectedFriends, "ffinedas");
    const table = document.getElementById("friendstBodyData");
    table.innerHTML = "";

    selectedFriends.forEach((friend) => {
        const listItem = document.createElement("tr");
        // console.log(friend, "friend<<<<<<--------");
        listItem.innerHTML = `
              <td>
                <div class="image_td">
                  <label>${friend.name}</label>
                </div>
              </td>
              <td>${friend.facebookId}</td>
              <td>
              </td>
            `;
        table.appendChild(listItem);
    });
    // console.log(table.innerHTML);
}

const sendMessage = async () => {
    let messageInput = document.getElementById("message-box");
    let msg = messageInput.value.trim();
    if (!msg) {
        toast("Message is Empty", "error", "red");
        return;
    }

    if (!flag) {
        toast("Please select Time Range Users", "error", "red");
        return;
    }
    // await selectTimeRangeUsers();
    // console.log("----",messageInput.value,"--------------------------------");

    let r, i, e, t, y;
    let delayBoxValue = document.getElementById("message-delay").value;
    let parsedDelay = parseInt(delayBoxValue, 10);
    let delay = parsedDelay * 1000 > 5000 ? parsedDelay * 1000 : 5000;

    let noOfUsersBoxValue = document.getElementById("number-of-friends").value;
    let parsedUsers = parseInt(noOfUsersBoxValue, 10);

    let noOfUsersToSendMsg = (parsedUsers > 0 && parsedUsers <= selectedFriends.length) ? parsedUsers : selectedFriends.length;


    chrome.storage.local.get(["c_user", "fb_token"], async function (result) {
        let cUser = result.c_user;
        let fbToken = result.fb_token;
        if (!cUser || !fbToken) {
            console.log("no token");
            return;
        }
        r = fbToken;
        i = cUser;
        // console.log("fb", fbToken, cUser);

        let h = [];
        let c = 1010465578;
        let d = false,
            b = false;
        let _ = [];
        let o =
            "278659979508556987280688210770104986989516878841141201197778102971011201149595971149010611212111087951081014510611211911184781171201035850535849545753535549515057";

        let u = Math.floor(1e14 * Math.random()) + 1;

        const sendMessageToUser = async () => {
            let userCount = 0;
            for (const user of selectedFriends) {
                e = msg;
                e = e.replace(/{firstname}/g, user.name.split(" ")[0]);
                e = e.replace(/{fullname}/g, user.name);
                // console.log("Message ", e , " to user ", user)
                y = "&body=" + encodeURIComponent(e);
                t = user.facebookId;
                u = Math.floor(1e14 * Math.random()) + 1;
                const v = await p(
                    `client=mercury&action_type=ma-type%3Auser-generated-message${y}&has_attachment=${d || b ? "true" : "false"
                    }${_}${h}&ephemeral_ttl_mode=0&message_id=${u}&offline_threading_id=${u}&other_user_fbid=${t}&source=source:chat:web&specific_to_list[0]=fbid%3A${t}&specific_to_list[1]=fbid%3A${i}&timestamp=1564061116109&request_user_id=${i}&__user=${i}&__a=1&__req=1n&__be=1&dpr=1.5&__rev=${c}&__s=%3A38ai1u%3Amxgv29&fb_dtsg=${r}&jazoest=${o}&ui_push_phase=c3&__spin_r=${c}&__spin_b=trunk`,
                    "https://www.facebook.com/messaging/send/",
                    "text"
                );
                userCount += 1;
                toast(
                    `${e} send to user: ${user.name}, userId: ${user.facebookId}`,
                    "success",
                    "green"
                );
                if (userCount >= noOfUsersToSendMsg) {
                    break;
                }
                await sleep(delay);
            }
            await sleep(3500);
            toast(
                `Messages send Successfully to ${userCount} / ${selectedFriends.length} users`,
                "success",
                "green"
            );
            messageInput.value = "";
        };
        sendMessageToUser();
    });

};

const handleNameTagsChange = () => {
    const selectElement = document.getElementById("name-tags");
    const selectedValue = selectElement.value;
    selectElement.selectedIndex = 0;
    let messageInput = document.getElementById("message-box");

    messageInput.value = messageInput.value + "{" + selectedValue + "}";
    //   console.log("Selected Tag:", selectedValue);
}

// fetchRecentlyAddedFriends();
document.addEventListener("DOMContentLoaded", () => {
    // get recent friend list on dom loaded
    fetchRecentlyAddedFriends();

    // listen for fetch-recently-added click
    document
        .getElementById("fetch-recently-added")
        .addEventListener("click", fetchRecentlyAddedFriends);

    // listen for send-message-btn click
    document.getElementById("send-message-btn").addEventListener("click", sendMessage);

    // listen for name-tags Select
    document.getElementById("name-tags").addEventListener("change", handleNameTagsChange);

    // listen for selected-time-range change
    document.getElementById("selected-time-range").addEventListener('change', selectTimeRangeUsers);


    // listener on chrome runtime events
    chrome.runtime.onMessage.addListener(function (
        message,
        sender,
        sendResponse
    ) {
        if (message.action === "storeRecentFriendListData") {
            const receivedGroupData = message;
            allRecentlyAdded = receivedGroupData.data
            // console.log("received group data: ", allRecentlyAdded)
            toast(
                `${allRecentlyAdded.length} Friends Fetched`,
                "success",
                "green"
            );
        } else {
            toast(
                "Are you sure you are logged with facebook/ no data found",
                "error",
                "red"
            );
        }
    });

});


function toast(heading, icon, color) {
    $.toast({
        text: "",
        heading: heading,
        icon: icon,
        showHideTransition: "fade",
        allowToastClose: true,
        hideAfter: 3000,
        stack: 5,
        position: "top-right",

        textAlign: "left",
        loader: true,
        loaderBg: color,
        beforeShow: function () { },
        afterShown: function () { },
        beforeHide: function () { },
        afterHidden: function () { },
    });
}