let broadcastList = [];
let selectElement;
let currentList = null;
let allFriendsList = [];

let allMessagesList = [];
let currentMessageList = null;
const url = "https://fb-tool-node.devtrust.biz/graphql";

let adminFacebookId;

chrome.storage.local.get(["c_user", "fb_token"], function (result) {
  let cUser = result.c_user;
  let fbToken = result.fb_token;

  if (!cUser || !fbToken) {
    console.log("Required data not found in storage");
    return;
  }
  adminFacebookId = cUser;
  // console.log("Admin", adminFacebookId)
  // localStorage.setItem("cUser", cUser);
  getBroadcastList();
  getBroadcastMessageList();
  // console.log("Affffffffmin")
});

const getBroadcastList = async () => {
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      query: `
      query GetBroadcastList($adminFacebookId: String!) {
        getBroadcastList(adminFacebookId: $adminFacebookId) {
          _id
          name
          users {
            facebookId
            name
            image
            gender
          }
          adminFacebookId
        }
      }
            `,
      variables: {
        adminFacebookId,
      },
    }),
  });

  if (response.ok) {
    const responseData = await response.json();
    const resultData = responseData.data;
    // console.log(resultData.getBroadcastList)
    broadcastList = resultData.getBroadcastList;

    let broadcastSelect = document.getElementById("broadcast-list");
    const existingOptions = Array.from(broadcastSelect.options).map(option => option.value);

    const newOptions = broadcastList.filter(broadcast => !existingOptions.includes(broadcast._id));

    // Append new options to the select dropdown
    newOptions.forEach((broadcast) => {
      const option = document.createElement("option");
      option.value = broadcast._id;
      option.textContent = broadcast.name;
      broadcastSelect.appendChild(option);
    });

    document
      .getElementById("broadcast-list")
      .addEventListener("change", (e) => {
        console.log("value changed", e.target.value);
        let currentVal = e.target.value;
        currentList = broadcastList.find((broadcast) => {
          return broadcast._id == currentVal;
        });
        console.log("currentList", currentList);
        FriendsListItems(currentList.users);
        AllFriendsListItems(allFriendsList);
        //   console.log("friends changed", currentListIndex);
      });
    if (currentList) {
      let currentVal = currentList._id;
      currentList = broadcastList.find((broadcast) => {
        return broadcast._id == currentVal;
      });

      FriendsListItems(currentList.users);
      AllFriendsListItems(allFriendsList);
    }
  } else {
    throw new Error("Network response was not ok.");
  }
};

const getBroadcastMessageList = async () => {
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      query: `
        query GetBroadcastMessageList($adminFacebookId: String!) {
          getBroadcastMessageList(adminFacebookId: $adminFacebookId) {
            _id
            name
            messages {
              _id
              content
            }
          }
        }
      `,
      variables: {
        adminFacebookId,
      },
    }),
  });

  if (response.ok) {
    const responseData = await response.json();
    const resultData = responseData.data;

    // Update the global variable
    allMessagesList = resultData.getBroadcastMessageList;

    // Find new options that are not already in the dropdown
    const selectDropdown = document.getElementById("all-message-lists");
    const existingOptions = Array.from(selectDropdown.options).map(option => option.value);

    const newOptions = allMessagesList.filter(messageList => !existingOptions.includes(messageList._id));

    // Append new options to the select dropdown
    newOptions.forEach((messageList) => {
      const option = document.createElement("option");
      option.value = messageList._id;
      option.textContent = messageList.name;
      selectDropdown.appendChild(option);
    });


  } else {
    throw new Error("Network response was not ok.");
  }
};

document.addEventListener("DOMContentLoaded", () => {
  // add broadcast list btn listener
  document
    .getElementById("broadcast-list-input-btn")
    .addEventListener("click", () => {
      const broadcastListInputValue = document.getElementById(
        "broadcast-list-input-box"
      ).value;
      if (!broadcastListInputValue) return;
      createBroadcastList(broadcastListInputValue);
    });

  // Remove From Broadcast List btn listener
  document
    .getElementById("removeFromBroadcastList")
    .addEventListener("click", (e) => {
      e.preventDefault();
      if (!currentList) return;
      const checkedBoxes = document.querySelectorAll(".broadcast-group-checkbox:checked");
      const selectedFriends = Array.from(checkedBoxes).map((checkbox) => {
        return {
          facebookId: checkbox.getAttribute("data-group-id"),
          name: checkbox.getAttribute("data-group-name"),
          gender: checkbox.getAttribute("data-group-gender"),
          image: checkbox.getAttribute("data-group-img"),
        };
      });
      if (selectedFriends.length <= 0) {
        toast("Please add the user", "error", "red");
        return false;
      }
      try {
        if (currentList && currentList._id) {
          removeUserFromBroadcast(currentList._id, selectedFriends);
        } else {
          console.log("List is not Selected", "error", "red");
        }
      } catch (error) {
        console.error("Error:", error);
      }
    });

  // Add Message to message list btn Listner
  document.getElementById("add-message-btn").addEventListener("click", () => {
    const messageInput = document.getElementById("message-input-box").value;
    if (!messageInput) {
      toast("Please Enter a message", "error", "red");
      return;
    }
    if (currentMessageList == null) {
      toast("Please add Messages to Message List", "error", "red");
      return;
    }
    addMessageToMessageList(currentMessageList._id, messageInput)
  });

  // Add Message List btn Listner
  document
    .getElementById("message-list-input-btn")
    .addEventListener("click", () => {
      const messageListInputValue = document.getElementById(
        "message-list-input-box"
      ).value;
      if (!messageListInputValue) return;
      createBroadcastMessageList(messageListInputValue);
    });

  // messageListDropDown change listeners
  document
    .getElementById("all-message-lists")
    .addEventListener("change", (e) => {
      // console.log("value changed", e.target.value);
      let currentVal = e.target.value;
      currentMessageList = allMessagesList.find((messagelist) => {
        return messagelist._id == currentVal;
      });
      console.log("currentMessageList", currentMessageList);
      setSelectedListMessage(currentMessageList.messages);
    });
});

const fetch_friends_list = () => {
  //   console.log("currentList-----", currentList);
  chrome.runtime.sendMessage({ action: "friendLists" });

  const url = "https://fb-tool-node.devtrust.biz/graphql";
  chrome.runtime.onMessage.addListener(function (
    message,
    sender,
    sendResponse
  ) {
    if (message.action === "storeFriendListData") {
      const receivedGroupData = message.data?.edges;

      // console.log("received group data: ", receivedGroupData)
      createFriendsListItems(receivedGroupData);
    } else {
      toast(
        "Are you sure you are logged with facebook/ no data found",
        "error",
        "red"
      );
    }
  });
  async function createFriendsListItems(friends) {
    if (!friends.length) {
      toast(
        "Are you sure you are logged with facebook/ no data found",
        "error",
        "red"
      );
    }
    const blockApiCallResponse = await blockApiCall();
    try {
      const blackListuserIds = blockApiCallResponse.map(
        (item) => item.blackListuserId
      );
      const filteredFriends = friends.filter((friend) => {
        return !blackListuserIds.includes(friend?.node.id);
      });
      console.log(filteredFriends, "filteredFriends");
      allFriendsList = filteredFriends;
      AllFriendsListItems(allFriendsList);
    } catch (error) {
      console.error("Error:", error);
    }
  }
  async function blockApiCall() {
    const url = "https://fb-tool-node.devtrust.biz/graphql";
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        query: `
        query GetAllBlackListFriends($adminFacebookId: String) {
          getAllBlackListFriends(adminFacebookId: $adminFacebookId) {
            _id
            blackListuserId
            name
            image
            gender
            isDeleted
            adminFacebookId
          }
        }
                  `,
        variables: {
          adminFacebookId,
        },
      }),
    });

    if (response.ok) {
      const responseData = await response.json();
      const resultData = responseData.data?.getAllBlackListFriends;
      return resultData;
    }
  }
};

const createBroadcastList = async (broadcastName) => {
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        query: `
        mutation CreateBroadcastList($input: createBroadcastInput) {
          createBroadcastList(input: $input) {
            _id
            name
            adminFacebookId
          }
        }
              `,

        variables: {
          input: {
            name: broadcastName,
            adminFacebookId,
          },
        },
      }),
    });
    if (response.ok) {
      await getBroadcastList();
      toast("Broadcast List Created", "success", "green");
    } else {
      toast("Network response was not ok.", "error", "red");
      throw new Error("Network response was not ok.");
    }
    document.getElementById("broadcast-list-input-box").value = "";
  } catch (error) {
    console.error("Error:", error);
  }
};

const createBroadcastMessageList = async (MessageListName) => {
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        query: `
        mutation CreateBroadcastMessageList($input: createBroadcastMessageListInput) {
          createBroadcastMessageList(input: $input) {
            _id
            name
          }
        }
              `,

        variables: {
          input: {
            name: MessageListName,
            adminFacebookId,
          },
        },
      }),
    });
    if (response.ok) {
      await getBroadcastMessageList();
      toast("Message List Created", "success", "green");
    } else {
      toast("Network response was not ok.", "error", "red");
      throw new Error("Network response was not ok.");
    }
    document.getElementById("message-list-input-box").value = "";
  } catch (error) {
    console.error("Error:", error);
  }
};

const addMessageToMessageList = async (messageListId, messageContent) => {
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        query: `
        mutation UpdateBroadcastMessageList($input: updateBroadcastMessageListInput) {
          updateBroadcastMessageList(input: $input) {
            _id
            name
            messages {
              _id
              content
            }
          }
        }
              `,
        variables: {
          input: {
            _id: messageListId,
            content: messageContent,
          },
        },
      }),
    });

    if (!response.ok) {
      throw new Error(`Failed to add Message. Status: ${response.status}`);
    }
    // await getBroadcastList();
    await getBroadcastMessageList();
    // console.log("all messages list",allMessagesList)
    const responseData = await response.json();
    const resultData = await responseData.data;
    // console.log("responce", resultData?.updateBroadcastMessageList)
    currentMessageList = resultData?.updateBroadcastMessageList
    // console.log("currentMessageList", currentMessageList)
    document.getElementById("message-input-box").value = ""
    setSelectedListMessage(currentMessageList.messages)
    toast("Message added successfully!", "success", "green");
  } catch (error) {
    console.error("Error adding users:", error.message);
  }
}

const removeMessageFromMessageList = async (messageListId, messageId) => {
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        query: `
        mutation RemoveFromBroadcastMessageList($input: removeFromBroadcastMessageListInput) {
          removeFromBroadcastMessageList(input: $input) {
            _id
            name
            messages {
              _id
              content
            }
          }
        }
              `,
        variables: {
          input: {
            _id: messageListId,
            messageId,
          },
        },
      }),
    });
    if (!response.ok) {
      throw new Error(`Failed to remove user. Status: ${response.status}`);
    }
    await getBroadcastMessageList();
    const responseData = await response.json();
    const resultData = await responseData.data;
    currentMessageList = resultData?.removeFromBroadcastMessageList
    setSelectedListMessage(currentMessageList.messages)
    toast("Message removed successfully!", "success", "green");
  } catch (error) {
    console.error("Error removing user:", error.message);
  }
}

const addUsersToBroadcast = async (broadcastId, usersArray) => {
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        query: `
        mutation UpdateBroadcastList($input: updateBroadcastInput) {
          updateBroadcastList(input: $input) {
            _id
            name
            users {
              facebookId
              name
              image
              gender
            }
            adminFacebookId
          }
        }
              `,
        variables: {
          input: {
            _id: broadcastId,
            users: usersArray,
          },
        },
      }),
    });

    if (!response.ok) {
      throw new Error(`Failed to add users. Status: ${response.status}`);
    }
    await getBroadcastList();
    FriendsListItems(currentList.users);
    AllFriendsListItems(allFriendsList);
    toast("Users added successfully!", "success", "green");
  } catch (error) {
    console.error("Error adding users:", error.message);
  }
};

const removeUserFromBroadcast = async (broadcastId, usersArray) => {
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        query: `
        mutation RemoveFromBroadcastList($input: removeFromBroadcastListInput) {
          removeFromBroadcastList(input: $input) {
            _id
            name
            users {
              facebookId
              name
              image
              gender
            }
            adminFacebookId
          }
        }
              `,
        variables: {
          input: {
            _id: broadcastId,
            users: usersArray,
          },
        },
      }),
    });
    if (!response.ok) {
      throw new Error(`Failed to remove user. Status: ${response.status}`);
    }
    await getBroadcastList();
    FriendsListItems(currentList.users);
    AllFriendsListItems(allFriendsList);
    toast("User removed successfully!", "success", "green");
  } catch (error) {
    console.error("Error removing user:", error.message);
  }
};

document.getElementById("fetch_friends_brodcast").addEventListener("click", () => {
  fetch_friends_list();

  document
    .getElementById("addToSaflist")
    .addEventListener("click", async function (e) {
      e.preventDefault();
      const checkedBoxes = document.querySelectorAll(".all-group-checkbox:checked");
      const selectedFriends = Array.from(checkedBoxes).map((checkbox) => {
        return {
          facebookId: checkbox.getAttribute("data-group-id"),
          name: checkbox.getAttribute("data-group-name"),
          gender: checkbox.getAttribute("data-group-gender"),
          image: checkbox.getAttribute("data-group-img"),
        };
      });
      if (selectedFriends.length <= 0) {
        toast("Please add the user", "error", "red");
        return false;
      }
      try {
        if (currentList && currentList._id) {
          addUsersToBroadcast(currentList._id, selectedFriends);
        } else {
          toast("List is not Selected", "error", "red");
        }
      } catch (error) {
        console.error("Error:", error);
      }
    });
});

async function p(t, e, s = "json") {
  const a = await fetch(e || "https://www.facebook.com/api/graphql/", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    },
    mode: "cors",
    credentials: "include",
    body: t,
  });
  return "json" === s ? await a.json() : await a.text();
}

// send message btn listner
document
  .getElementById("send-message-btn")
  .addEventListener("click", async function () {
    // console.log("click send");
    if (!currentMessageList || currentMessageList.messages.length < 1) {
      toast("Please add a message in message list", "error", "red");
      return;
    }
    if (!currentList || currentList.users.length < 1) {
      toast("Please add user", "error", "red");
      return;
    }
    let r, i, t, e, y;
    let delayBoxValue = document.getElementById("time-delay").value;
    let parsedDelay = parseInt(delayBoxValue, 10);
    let delay = parsedDelay * 1000 > 5000 ? parsedDelay * 1000 : 5000;

    let noOfUsersBoxValue = document.getElementById("number-of-users").value;
    let parsedUsers = parseInt(noOfUsersBoxValue, 10);
    // console.log("Number of users", parsedUsers);
    let noOfUsersToSendMsg = (parsedUsers > 0 && parsedUsers <= currentList.users.length) ? parsedUsers : currentList.users.length;

    // console.log("list users", currentList.users);

    chrome.storage.local.get(["c_user", "fb_token"], async function (result) {
      let cUser = result.c_user;
      let fbToken = result.fb_token;
      if (!cUser || !fbToken) {
        console.log("no token");
        return;
      }
      r = fbToken;
      i = cUser;
      // console.log("fb", fbToken, cUser);

      let h = [];
      // let t = 100007521065673;
      // let i = 100053653778137;
      let c = 1010465578;
      let d = false,
        b = false;
      let _ = [];
      // let r =
      //   "NAcO2U8bHPDRkFhbEY3DNTrxwMNfaexr__arZjpynW_le-jpwoTNuxg:25:1695571329";
      let o =
        "278659979508556987280688210770104986989516878841141201197778102971011201149595971149010611212111087951081014510611211911184781171201035850535849545753535549515057";
      // let e = "Hiiiiiiiiiiiiiiiiiiii";

      //   let t = 100092374720273;
      let u = Math.floor(1e14 * Math.random()) + 1;
      // console.log("y", y);
      // console.log("e", e);
      const sendMessage = async () => {
        let userCount = 0;
        for (const user of currentList.users) {
          const randomIndex = Math.floor(Math.random() * currentMessageList.messages.length);
          e = currentMessageList.messages[randomIndex].content
          y = "&body=" + encodeURIComponent(e);
          // console.log("e", e);
          t = user.facebookId;
          u = Math.floor(1e14 * Math.random()) + 1;
          const v = await p(
            `client=mercury&action_type=ma-type%3Auser-generated-message${y}&has_attachment=${d || b ? "true" : "false"
            }${_}${h}&ephemeral_ttl_mode=0&message_id=${u}&offline_threading_id=${u}&other_user_fbid=${t}&source=source:chat:web&specific_to_list[0]=fbid%3A${t}&specific_to_list[1]=fbid%3A${i}&timestamp=1564061116109&request_user_id=${i}&__user=${i}&__a=1&__req=1n&__be=1&dpr=1.5&__rev=${c}&__s=%3A38ai1u%3Amxgv29&fb_dtsg=${r}&jazoest=${o}&ui_push_phase=c3&__spin_r=${c}&__spin_b=trunk`,
            "https://www.facebook.com/messaging/send/",
            "text"
          );
          userCount += 1;
          toast(
            `${e} send to user: ${user.name}, userId: ${user.facebookId}`,
            "success",
            "green"
          );
          if (userCount >= noOfUsersToSendMsg) {
            break;
          }
          await sleep(delay);
        }
        toast(
          `Messages send Successfully to ${userCount} / ${currentList.users.length} users`,
          "success",
          "green"
        );
      };
      sendMessage();
    });
  });

function sleep(t) {
  return new Promise((e) => setTimeout(e, t));
}

function FriendsListItems(friends) {
  console.log(friends, "ffinedas");
  const table = document.getElementById("safeListBodyData");
  table.innerHTML = "";

  friends.forEach((friend) => {
    const listItem = document.createElement("tr");
    // console.log(friend, "friend<<<<<<--------");
    listItem.innerHTML = `
              <td>
                <div class="image_td">
                  <img src="${friend.image}" >
                  <label>${friend.name}</label>
                </div>
              </td>
              <td>${friend.gender ? friend.gender : "NA"}</td>
              <td>${friend.facebookId}</td>
              <td>
                <div class="form-check">
                  <input type="checkbox" id=${friend.facebookId
      } class="group-checkbox broadcast-group-checkbox" data-group-id="${friend.facebookId
      }" data-group-name="${friend.name}" data-group-img="${friend.image
      }" data-group-gender="${friend.gender}">
                </div>
              </td>
            `;
    table.appendChild(listItem);
  });
}

function AllFriendsListItems(friends) {
  console.log(friends, "ffinedas");

  const filteredFriends = friends.filter((friend) => {
    // console.log(friend?.node.id,"--------------")
    if (currentList && currentList.users) {
      return !currentList.users.filter(
        (user) => user.facebookId == friend?.node.id
      ).length;
    } else return true;
  });
  console.log(filteredFriends, "filteredFriends");

  const table = document.getElementById("friendstBodyData");
  table.innerHTML = "";

  filteredFriends.forEach((group) => {
    const { node } = group;
    const listItem = document.createElement("tr");

    listItem.innerHTML = `
    <td>
      <div class="image_td">
        <img src="${node.profile_picture.uri}">
        <label>${node.name}</label>
      </div>
    </td>
    <td>${node.gender}</td>
    <td>${node.id}</td>
    <td>
      <div class="form-check">
        <input type="checkbox" class="group-checkbox all-group-checkbox" data-group-id="${node.id}" data-group-name="${node.name}" data-group-img="${node.profile_picture.uri}" data-group-gender="${node.gender}">
      </div>
    </td>
  `;
    table.appendChild(listItem);
  });
}


function setSelectedListMessage(messages) {
  const messageListContainer = document.getElementById("message-list");
  // Create a new list element
  const messageList = document.createElement("ul");
  // Append each message as a list item
  messages.forEach((message) => {
    const listItem = document.createElement("li");
    listItem.innerHTML = `${message.content} <span class="delete-message-btn"> X </span>`;

    // Add event listener to the delete button
    const deleteButton = listItem.querySelector('.delete-message-btn');
    deleteButton.addEventListener('click', () => {
      removeMessageFromMessageList(currentMessageList._id, message._id);
      // console.log(`Delete button clicked for message with ID: ${currentMessageList._id}, ${message._id}`);
    });

    messageList.appendChild(listItem);
  });

  // Directly overwrite the content of the container with the new list
  messageListContainer.innerHTML = '';
  messageListContainer.appendChild(messageList);

}


function toast(heading, icon, color) {
  $.toast({
    text: "",
    heading: heading,
    icon: icon,
    showHideTransition: "fade",
    allowToastClose: true,
    hideAfter: 3000,
    stack: 5,
    position: "top-right",

    textAlign: "left",
    loader: true,
    loaderBg: color,
    beforeShow: function () { },
    afterShown: function () { },
    beforeHide: function () { },
    afterHidden: function () { },
  });
}
