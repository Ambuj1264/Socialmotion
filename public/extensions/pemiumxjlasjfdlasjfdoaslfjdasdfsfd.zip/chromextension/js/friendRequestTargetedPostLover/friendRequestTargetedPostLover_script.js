console.log("friendRequest Targeted Post Lover");

chrome.runtime.onMessage.addListener(frTagetedPlMessageListener);

function frTagetedPlMessageListener(message, sender, sendResponse) {
  if (message.action == "friendRequestTargetedPostLover") {
    console.log("friendRequest Targeted Post Lover");

    console.log("inner friendRequest Targeted Post Lover");
    // if(window.location.href == "abcd")

    active_status = false;
    sendRequestsCount = 0;
    // skipRequestsCount = 0;
    nonUsaCount = 0;
    nonMutualCount = 0;
    blaklistSkippedCount = 0;

    $(document).ready(() => {
      //   let posts = $("div[role='feed'] .x1yztbdb.x1n2onr6.xh8yej3.x1ja2u2z");
      //   // let posts = $("div[role='feed']").find(".x1yztbdb.x1n2onr6.xh8yej3.x1ja2u2z");

      //   console.log("friendRequest Post", posts);
      highLightLikersCount();

      let initialScrollHeight = document.body.scrollHeight;
      function checkScrollHeight() {
        const currentScrollHeight = document.body.scrollHeight;
        if (currentScrollHeight !== initialScrollHeight) {
          console.log("Scroll height has changed");
          console.log("New scroll height:", currentScrollHeight);
          initialScrollHeight = currentScrollHeight;
          highLightLikersCount();
        }
      }

      const observer = new MutationObserver(checkScrollHeight);
      const observerConfig = {
        attributes: true,
        attributeFilter: ["style"],
        subtree: true,
      };

      observer.observe(document.body, observerConfig);
    });

    const highLightLikersCount = async () => {
      // console.log("window.location",window.location.href)

      let posts = $(
        "div[role='feed'] .x1yztbdb.x1n2onr6.xh8yej3.x1ja2u2z:not(.gone-through)"
      );

      if (window.location.href === "https://www.facebook.com/") {
        posts = $(
          "div[role='main'] .x1yztbdb.x1n2onr6.xh8yej3.x1ja2u2z:not(.gone-through)"
        );
      } else if (window.location.href.includes("profile.php")) {
        posts = $(
          'div[class="x9f619 x1n2onr6 x1ja2u2z xeuugli xs83m0k x1xmf6yo x1emribx x1e56ztr x1i64zmx xjl7jj x19h7ccj xu9j1y6 x7ep2pv"] .x1yztbdb.x1n2onr6.xh8yej3.x1ja2u2z:not(.gone-through)'
        );
      }
      console.log("posts", posts);

      // number count border
      //   $(posts)
      //     .find(
      //       '.x6s0dn4.xi81zsa.x78zum5.x6prxxf.x13a6bvl.xvq8zen.xdj266r.xktsk01.xat24cr.x1d52u69.x889kno.x4uap5.x1a8lsjc.xkhd6sd.xdppsyt > div[class="x6s0dn4 x78zum5 x1iyjqo2 x6ikm8r x10wlt62"] > div > span[class="x4k7w5x x1h91t0o x1h9r5lt x1jfb8zj xv2umb2 x1beo9mf xaigb6o x12ejxvf x3igimt xarpa2k xedcshv x1lytzrv x1t2pt76 x7ja8zs x1qrby5j"]'
      //     )
      //     .addClass("likers-custom-animation");

      // Check if the first selector matches any elements
      const firstSelectorElements = $(posts).find(
        '.x6s0dn4.xi81zsa.x78zum5.x6prxxf.x13a6bvl.xvq8zen.xdj266r.xktsk01.xat24cr.x1d52u69.x889kno.x4uap5.x1a8lsjc.xkhd6sd.xdppsyt > div[class="x6s0dn4 x78zum5 x1iyjqo2 x6ikm8r x10wlt62"] > div > span[class="x4k7w5x x1h91t0o x1h9r5lt x1jfb8zj xv2umb2 x1beo9mf xaigb6o x12ejxvf x3igimt xarpa2k xedcshv x1lytzrv x1t2pt76 x7ja8zs x1qrby5j"]'
      );
      if (firstSelectorElements.length > 0) {
        firstSelectorElements
          .addClass("likers-custom-animation")
          .on("click", likersPopup);
      } else {
        // If the first selector doesn't match, apply the class using the second selector
        $(posts)
          .find(
            '.x6s0dn4.xi81zsa.x78zum5.x6prxxf.x13a6bvl.xvq8zen.xdj266r.xktsk01.xat24cr.x1d52u69.x889kno.x4uap5.x1a8lsjc.xkhd6sd.xdppsyt > div[class="x6s0dn4 x78zum5 x1iyjqo2 x6ikm8r x10wlt62"] > span:has(> div)'
          )
          .addClass("likers-custom-animation")
          .on("click", likersPopup);
      }

      console.log("friendRequest Post", posts);
      posts.addClass("gone-through");
    };

    const likersPopup = async () => {
      console.log("Element clicked");
      active_status = false;
      sendRequestsCount = 0;
      // skipRequestsCount = 0;
      nonUsaCount = 0;
      nonMutualCount = 0;
      blaklistSkippedCount = 0;

      await sleep(2000);
      insertStartStopHtml();

      $(".cf_start_btn").on("click", function () {
        startProcess();
      });
      $(".cf_stop_btn").on("click", function () {
        stopProcess();
      });

      // loadMoreLikers();
    };

    async function startProcess() {
      console.log("startProcess called");
      // $(".cf_start_btn").hide();
      // $(".cf_stop_btn").show();

      $(".cf_start_btn").prop("disabled", true);
      $(".cf_stop_btn").prop("disabled", false);

      $(".cf_text").text("Fb-Tools Started. Please wait...");
      active_status = true;

      startRequestAction();
    }
    function stopProcess() {
      console.log("stopProcess called");
      active_status = false;
      // $(".cf_start_btn").text("Paused... Click to Resume").show();
      // $(".cf_stop_btn").hide();
      $(".cf_start_btn").prop("disabled", false);
      $(".cf_stop_btn").prop("disabled", true);
    }

    const startRequestAction = async () => {
      // const allUsers = $('.x1n2onr6.xzkaem6 div[class="x78zum5 xdt5ytf x1iyjqo2 x1n2onr6"] ')
      let likeBtns = $(
        '.x1n2onr6.xzkaem6 div[aria-label="Add friend"]:not(.gone-through)'
      );
      if (!likeBtns.length) {
        // console.log('all users visited');
        // return;
        let initialScrollHeight = document.body.scrollHeight;
        loadMoreLikers();
        await sleep(2000);
        let currentScrollHeight = document.body.scrollHeight;

        if (currentScrollHeight === initialScrollHeight) {
          updateStatusString();
          console.log("Page has reached the end");
          stopProcess();
          return;
        }
        await sleep(2000);
        likeBtns = $(
          '.x1n2onr6.xzkaem6 div[aria-label="Add friend"]:not(.gone-through)'
        );
      }
      let currentBtn = likeBtns[0];

      await scrollToBtn(currentBtn);
      await sleep(3000);
      if (active_status === true) {
        await sendFriendRequest(currentBtn);
        await sleep(3000);
        await startRequestAction();
      }
    };

    function updateStatusString() {
      let main_text = "";
      let non_usa = "";
      let non_mutual = "";
      let blaklist_skipped = "";

      // console.log("status_string update count ", countCompleted);

      main_text = "Friend Requests Count : " + sendRequestsCount;
      non_usa = "Non-USA Skipped: " + nonUsaCount;
      non_mutual = "Non-Mutual Friends Skipped: " + nonMutualCount;
      blaklist_skipped = "Blacklist Friends Skipped: " + blaklistSkippedCount;

      $(".cf_text").text(main_text);
      $(".cf_non_usa_skiped").text(non_usa);
      $(".cf_non_mutual_skiped").text(non_mutual);
      $(".cf_blacklist_skiped").text(blaklist_skipped);
    }

    const sendFriendRequest = async (currentBtn) => {
      let mutualFilter = true;
      // console.log("before click", currentBtn);
      let mutualEnabled = $("#mutual-friend-check").prop("checked");
      if (mutualEnabled) {
        mutualFilter = await filterMutualFriends(currentBtn);
        // console.log("mutual filter", mutualFilter, mutualEnabled);
      }
      if (mutualFilter) {
        $(currentBtn).click();

        await sleep(2000);
        // console.log("-------", $('div[role="dialog"]'));
        if (
          $(
            '.x1n2onr6.x1vjfegm div[class="x9f619 x1n2onr6 x1ja2u2z"] div[role="dialog"]'
          )[0]
        ) {
          $(
            '.x1n2onr6.x1vjfegm div[class="x9f619 x1n2onr6 x1ja2u2z"] div[role="dialog"]'
          )
            .find('div[aria-label="Close"]')[0]
            .click();
          // skipRequestsCount++;
          blaklistSkippedCount++;
          updateStatusString();
          await sleep(1000);
        } else {
          sendRequestsCount++;
          updateStatusString();
        }
      } else {
        nonMutualCount++;
        updateStatusString();
      }
      // sendRequestsCount ++;
      // updateStatusString();
      $(currentBtn).addClass("gone-through");
      console.log("after click", currentBtn);
    };

    const insertStartStopHtml = () => {
      console.log("insert");

      // status popup
      let createPopupStatus = document.createElement("div");
      createPopupStatus.classList.add("facebook_liker_popup_status");
      createPopupStatus.innerHTML = `<div id="cf_control_status">
      <div class='cf_text'>Click Start to begin!</div>
      <div class='cf_non_usa_skiped cf_small_text'></div>
      <div class='cf_non_mutual_skiped cf_small_text'></div>
      <div class='cf_blacklist_skiped cf_small_text'></div>
    </div>
    `;
      $(
        'div[class="x9f619 x78zum5 xl56j7k x2lwn1j xeuugli x47corl x1qjc9v5 x1bwycvy x1e558r4 x150jy0e x1x97wu9 xbr3nou xqit15g x1bi8yb4"]'
      ).append(createPopupStatus);
      // status popup end

      let temp_btn_top = $(
        'div[class="x6s0dn4 x78zum5 x2lah0s x1qughib x879a55 x1n2onr6"] > div[class="x1swvt13 x1pi30zi"]'
      ).html();

      let cont_btn_html = `
        <style>
          span.cf_mutual_friend_text label {
            font-size: large;
            color: #559af9;
          }
          .facebook_liker_popup_status {
            position: absolute;
            bottom: 0;
            left: 0;
            padding: 20px 30px;
            background: #1d7afa;
            margin: 16px 21px;
            border-radius: 7px;
            color: white;
          }
          .facebook_liker_popup_status .cf_text{
            font-size: x-large;
            font-weight: 600;
          }
          .facebook_liker_popup_status .cf_small_text{
            font-size: larger;
            font-weight: 600;
          }
          .start-stop-btn-container {
            height: 45px;
            font-size: large;
            display: flex;
            align-items: center;
          }
          span.start-stop-btn {
              margin-left: 20px;
          }
          .cf_btn:disabled {
            height: 35px;
            width: 65px;
            margin-left: 2px;
            border-radius: 15px;
            color: white;
            background: #1d7afa;
            border: none;
            font-size: large;
            font-weight: 600;
            box-shadow: 0px 0px 4px 0px gray inset;
            cursor: auto;
          }
          .cf_btn {
            height: 35px;
            width: 65px;
            margin-left: 2px;
            border: none;
            box-shadow: 1px 2px 4px 1px gray;
            border-radius: 15px;
            font-size: large;
            font-weight: 600;
            cursor: pointer;
          }
        </style>
        <div class="start-stop-btn-container">
          <span class="cf_mutual_friend_text"> 
            <label>Mutual Friends Only? </label>
            <input type="checkbox" id="mutual-friend-check"/>
          <span>
          <span class="start-stop-btn">
            <button class="btn btn-outline-primary cf_btn cf_start_btn">Start</button>
            <button class="btn btn-outline-danger cf_btn cf_stop_btn" disabled>Stop</button>
          </span>
        </div>
      `;

      $(
        'div[class="x6s0dn4 x78zum5 x2lah0s x1qughib x879a55 x1n2onr6"] > div[class="x1swvt13 x1pi30zi"]'
      ).html(cont_btn_html + temp_btn_top);
    };

    const loadMoreLikers = () => {
      $(
        'div[class="xb57i2i x1q594ok x5lxg6s x78zum5 xdt5ytf x6ikm8r x1ja2u2z x1pq812k x1rohswg xfk6m8 x1yqm8si xjx87ck xx8ngbg xwo3gff x1n2onr6 x1oyok0e x1odjw0f x1e4zzel x1tbbn4q x1y1aw1k x4uap5 xwib8y2 xkhd6sd"]'
      )[0].scrollTo({
        top: Number.MAX_SAFE_INTEGER,
        behavior: "smooth",
      });
    };

    async function scrollToBtn(targetedAddFriendBtn) {
      let offsetTopRow = await $(targetedAddFriendBtn).closest(
        'div[data-visualcompletion="ignore-dynamic"]:has(> .x1lq5wgf.xgqcy7u.x30kzoy.x9jhf4c.x1lliihq)'
      )[0].offsetTop;
      let offsetHeightRow = await $(targetedAddFriendBtn).closest(
        'div[data-visualcompletion="ignore-dynamic"]:has(> .x1lq5wgf.xgqcy7u.x30kzoy.x9jhf4c.x1lliihq)'
      )[0].offsetHeight;

      let offsetHeightSection = await $(targetedAddFriendBtn).closest(
        'div[data-visualcompletion="ignore-dynamic"]'
      )[0].offsetTop;

      console.log("offsetHeightSection", offsetHeightSection);
      $(
        'div[class="xb57i2i x1q594ok x5lxg6s x78zum5 xdt5ytf x6ikm8r x1ja2u2z x1pq812k x1rohswg xfk6m8 x1yqm8si xjx87ck xx8ngbg xwo3gff x1n2onr6 x1oyok0e x1odjw0f x1e4zzel x1tbbn4q x1y1aw1k x4uap5 xwib8y2 xkhd6sd"]'
      )[0].scrollTo({
        top: offsetTopRow,
        behavior: "smooth",
      });
    }

    const filterMutualFriends = async (targetedAddFriendBtn) => {
      const container = $(targetedAddFriendBtn).closest(
        'div[data-visualcompletion="ignore-dynamic"]'
      );
      const mutualFriendsLabel = container.find(
        'div:contains("mutual friend")'
      );

      return mutualFriendsLabel.length > 0;
    };

    function sleep(t) {
      return new Promise((e) => setTimeout(e, t));
    }
  }
  // chrome.runtime.onMessage.removeListener(frTagetedPlMessageListener);
}

setTimeout(() => {
  chrome.runtime.onMessage.removeListener(frTagetedPlMessageListener);
}, 8000);
// likers popup div box
// $(".x1n2onr6.xzkaem6")

// $(document).ready(() => {
//   // Store the initial scroll height
//   let initialScrollHeight = document.body.scrollHeight;

//   // Function to check and log if scroll height changes
//   function checkScrollHeight() {
//     // Get the current scroll height
//     const currentScrollHeight = document.body.scrollHeight;

//     // Check if the scroll height has changed
//     if (currentScrollHeight !== initialScrollHeight) {
//       console.log("Scroll height has changed");
//       // Optionally, you can log the new scroll height as well
//       console.log("New scroll height:", currentScrollHeight);

//       // Update the initial scroll height for the next check
//       initialScrollHeight = currentScrollHeight;
//     }
//   }

//   // Create a MutationObserver to observe changes in the DOM
//   const observer = new MutationObserver(checkScrollHeight);

//   // Configure the observer to watch for changes in attributes (e.g., scrollHeight) of the body element
//   const observerConfig = {
//     attributes: true,
//     attributeFilter: ["style"],
//     subtree: true,
//   };

//   // Start observing the body element
//   observer.observe(document.body, observerConfig);

//   // To stop observing when needed (e.g., after a certain number of iterations or a specific timeout duration):
//   // observer.disconnect();
// });

// // Add the listener for friendRequestTargetedPostLover Message listener
// chrome.runtime.onMessage.addListener(frTagetedPlMessageListener);

// function frTagetedPlMessageListener(message, sender, sendResponse) {
//     if (message.action == 'friendRequestTargetedPostLover') {

//         console.log("friendRequest Targeted Post Lover");

//     }
//     chrome.runtime.onMessage.removeListener(frTagetedPlMessageListener);
// }
