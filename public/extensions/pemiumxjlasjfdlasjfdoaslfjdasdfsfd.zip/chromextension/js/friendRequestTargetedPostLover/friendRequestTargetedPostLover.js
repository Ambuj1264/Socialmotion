$(document).ready(function () {
  $("#livedInUsa").click(function (event) {
    //   console.log("bjhfskjd")
    if ($("#livedInUsa").prop("checked")) {
      $("#livedInUsaRecommendCheck").css("display", "flex");
    } else {
      $("#livedInUsaRecommendCheck").css("display", "none");
    }
  });

  $("#open_facebook_window").click(function (event) {
    chrome.windows.create(
      {
        type: "popup",
        url: `https://www.facebook.com/`,
        width: 1200,
        height: 800,
        left: Math.round(screen.width / 2 - 600),
        top: Math.round(screen.height / 2 - 400),
      },
      function (popupWindow) {
        setTimeout(() => {
          chrome.tabs.sendMessage(popupWindow.tabs[0].id, {
            action: "friendRequestTargetedPostLover",
            windowId: popupWindow.id
          });
        }, 5000)
      }
    );
  });
});

function sleep(t) {
  return new Promise((e) => setTimeout(e, t));
}

function toast(heading, icon, color) {
  $.toast({
    text: "",
    heading: heading,
    icon: icon,
    showHideTransition: "fade",
    allowToastClose: true,
    hideAfter: 3000,
    stack: 5,
    position: "top-right",

    textAlign: "left",
    loader: true,
    loaderBg: color,
    beforeShow: function () {},
    afterShown: function () {},
    beforeHide: function () {},
    afterHidden: function () {},
  });
}
