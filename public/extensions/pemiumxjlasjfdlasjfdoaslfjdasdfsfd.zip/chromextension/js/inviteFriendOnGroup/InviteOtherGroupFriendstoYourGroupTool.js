document.getElementById("fetch_groups").addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "fetchGroups" });
  });
  
// Function to create a list item for each group
function createGroupListItems(groups) {
  console.log("groups", groups);
  const table = document.getElementById("grouptBodyData");
  table.innerHTML = '';

  groups.forEach((group) => {
    const { node } = group;
    const listItem = document.createElement("tr");

    listItem.innerHTML = `
      <td>
        <div class="image_td">
          <a class="invite-btn" style="text-decoration: none;" target="_blank">
            <img style="text-decoration: none;" src="${node.profile_picture.uri}">&nbsp;
            <label style="text-decoration: none;">${node.name}</label>
          </a>
        </div>
      </td>
      <td>${new Date(node.viewer_last_visited_time * 1000).toLocaleString()}</td>
      <td>${node.id}</td>
      <td>
        <div class="form-check">
          <button type="button" class="btn btn-light" style="font-size: 12px;" data-group-id="${node.id}" id="${node.id}">Select</button>
        </div>
      </td>
    `;

    table.appendChild(listItem);

    // Add an event listener for the invite button in each row
    const inviteButton = listItem.querySelector('.invite-btn');
    // console.log(inviteButton, "inviteButton");
    if (inviteButton) {
      inviteButton.addEventListener('click', () => {
        // Send a message to the content script to simulate a click on the invite button
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
          chrome.tabs.sendMessage(tabs[0].id, { action: "inviteOwnGroup", groupId: node.id });
        }
        );
      });
    }

    // Add an event listener for the "Select" button
    const selectButton = listItem.querySelector('.btn-light');
    // console.log(selectButton, "selectButton");
    if (selectButton) {
      selectButton.addEventListener('click', () => {
        // Handle the button click here
        selectButtonClick(node.id);
      });
    }
  });
}

// open in new tab start

// Function to handle "Select" button click
function selectButtonClick(groupId) {
  // Your code to handle the button click goes here
  console.log(`Select button clicked for group ID: ${groupId}`);
  chrome.runtime.sendMessage({ action: "inviteOwnGroup", groupId: groupId });
  // You can perform additional actions or call functions based on the button click
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    console.log(tabs[0], "tab---------------------------")
    chrome.tabs.sendMessage(tabs[0].id, { action: "inviteOwnGroup", groupId: groupId });
  })
}

// open in new tab end



// // open in new window start

// // Function to handle "Select" button click
// function selectButtonClick(groupId) {
//   chrome.windows.create(
//     {
//       type: "popup",
//       url: `https://www.facebook.com/groups/${groupId}`,
//       width: 1200,
//       height: 800,
//       left: Math.round(screen.width / 2 - 600),
//       top: Math.round(screen.height / 2 - 400),
//     },
//     function (window) {
//       let newWindowId = window.id;
//       chrome.windows.onFocusChanged.addListener(function onFocusChangedListener(windowId) {
//         if (windowId === newWindowId) {
//           chrome.windows.onFocusChanged.removeListener(onFocusChangedListener);
//           setTimeout(()=>{
//             InviteOwnGroupContentScript(newWindowId, groupId);
//           },5000)
//         }
//       });
//     }
//   );
// }

// function InviteOwnGroupContentScript(windowId, message) {
//   chrome.tabs.query({ windowId: windowId, active: true }, function (tabs) {
//     if (tabs.length > 0) {
//       const tabId = tabs[0].id;
//       chrome.tabs.sendMessage(tabId, {
//         action: "InviteOwnGroupContentScript",
//         data: message,
//       });
//     } else {
//       console.error("No active tabs in the specified window.");
//     }
//   });
// }


// // open in new window end



    chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
      console.log(message,"message")
      if (message.action === "storeGroupData") {
        const receivedGroupData = message.data?.edges;
        createGroupListItems(receivedGroupData);
      }
    });
    
    

    
    
    