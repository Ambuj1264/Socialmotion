document.getElementById("fetch_groups").addEventListener("click", () => {
  chrome.runtime.sendMessage({ action: "fetchGroups" });
});

// Function to create a list item for each group
function createGroupListItems(groups) {
  console.log("groups", groups);
  const table = document.getElementById("grouptBodyData");
  table.innerHTML = '';

  groups.forEach((group) => {
    const { node } = group;
    const listItem = document.createElement("tr");

    listItem.innerHTML = `
      <td>
        <div class="image_td">
          <a class="invite-btn" style="text-decoration: none;" target="_blank">
            <img style="text-decoration: none;" src="${node.profile_picture.uri}">&nbsp;
            <label style="text-decoration: none;">${node.name}</label>
          </a>
        </div>
      </td>
      <td>${new Date(node.viewer_last_visited_time * 1000).toLocaleString()}</td>
      <td>${node.id}</td>
      <td>
        <div class="form-check">
          <a type="button" target="_blank" class="btn btn-light " data-group-id="${node.id}"  style="font-size: 12px;" href="https://www.facebook.com/groups/${node.id}">Select</a>
        </div>
      </td>
    `;
    // href="https://www.facebook.com/groups/${node.id}"
    table.appendChild(listItem);

    // Add an event listener for the invite button in each row
    const inviteButton = listItem.querySelector('.invite-btn');
    if (inviteButton) {
      inviteButton.addEventListener('click', () => {
        // Send a message to the content script to simulate a click on the invite button
        chrome.tabs.create({
          url: `https://www.facebook.com/groups/${node.id}`,
        });
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
          console.log(tabs[0],"tab---------------------------")
          chrome.tabs.sendMessage(tabs[0].id, { action: "simulateClickOnInviteButton", groupId: node.id });
        });
        
      });
    }
  });
}
  
  
//   document
//     .getElementById("removeGroupsButton")
//     .addEventListener("click", function (e) {
//       const checkedBoxes = document.querySelectorAll(".group-checkbox:checked");
//       const selectedGroups = Array.from(checkedBoxes).map((checkbox) => {
//         return {
//           id: checkbox.getAttribute("data-group-id"),
//           name: checkbox.getAttribute("data-group-name"),
//         };
//       });
//       chrome.runtime.sendMessage({
//         action: "deleteGroups",
//         data: selectedGroups,
//       });
//     });
  
  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    console.log(message,"message")
    if (message.action === "storeGroupData") {
      const receivedGroupData = message.data?.edges;
      createGroupListItems(receivedGroupData);
    }
  });
  
  
  
  
  