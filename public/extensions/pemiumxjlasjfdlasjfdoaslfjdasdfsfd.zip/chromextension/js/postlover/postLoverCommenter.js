if (window.location.href.includes('postLover_action=comment')) {
    let currentWindowId = null;
    let commentMsg = '';
    var active_status = false;

    // chrome.runtime.onMessage.addListener(messageListener);

    chrome.storage.sync.get(null, (items) => {
        let messagesArray = items.postLoverComments;
        let commentIndex = Math.floor(Math.random() * messagesArray.length);
        // console.log("Comment Index: ", commentIndex)
        console.log("items", items);
        commentMsg = messagesArray[commentIndex];
        currentWindowId = items.postLoverCommentWindowId;
    });

    $(document).ready(async function () {

        await insertControlsHtml();
        $(".cf_stop_btn").hide();
        $(".cf_start_btn").on("click", function () {
            startProcess();
        });
        $(".cf_stop_btn").on("click", function () {
            stopProcess();
        });
        $(".cf_cancel_btn").on("click", function () {
            cancelProcess();
        });
        await startProcess();
    });

    function updateStatusString() {
        let status_string = "";
        let main_text = "";
        stopProcess();
        main_text = "Post Lover Tool Comment Done.";
        status_string = "All Done!";

        $("#cf_controls .status_string").text(status_string);
        $(".cf_text").text(main_text);
    }

    // function messageListener(message, sender, sendResponse) {
    //     if (message.action == 'postLoverComment') {
    //         commentMsg = message.commentMsg;
    //         currentWindowId = message.windowId;

    //         // Now you can use numberOfPostId and minDelayOnPost in your content script logic
    //         console.log("Received values in content script:", commentMsg);
    //         // Remove the listener when you want to
    //         chrome.runtime.onMessage.removeListener(messageListener);
    //     }
    // }

    function insertControlsHtml() {
        let cont_html = `    <style>
          #cf_controls{
              position: fixed;
              top: 50px;
              right: 100px;
              background: #eee;
              padding: 10px 15px;
              border-radius: 5px;
              box-shadow: 1px 2px 10px rgba(0,0,0,1);
              width: 500px;
              z-index: 999;
              display: flex;
              flex-direction: column;
              align-items: center;
              padding-top: 15px;
              padding-bottom: 15px;
          }
          .cf_text{
              font-size: larger;
              margin-bottom: 10px;
              font-weight: 500;
          }
          .cf_progressInfo{
              font-size: medium;
              margin-bottom: 10px;
              color: green;
          }
      </style>
       <div id="cf_controls">
          <div class="header">
              <h3>fb-tool Controls</h3>
              <hr>
          </div>
          <div class="body">
              <div class="buttons">
                  <button class="btn btn-outline-primary cf_btn cf_start_btn">Start</button>
                  <button class="btn btn-outline-primary cf_btn cf_stop_btn" style="display: none">Stop</button>
                  <button class="btn btn-outline-danger cf_btn cf_cancel_btn">Cancel</button>
              </div>
              <div><p class="status_string"></p></div>
          </div>
      </div>
  
    <div class="cf_overlay"></div>
    <div id="cf_controls" class="cf_progressBar">
      <div class="cf_finished">
  
      </div> 
      <div class="cf_text">Ready to start? Click the "Start" button.</div>
      <div class="cf_progressInfo">
        <span class="cf_done status_string">Commenting On Post...</span> 
      </div> 
      <div class="cf_btn_container">
      <button class="btn btn-outline-primary cf_btn cf_start_btn">Start</button>
      <button class="btn btn-outline-primary cf_btn cf_stop_btn">Stop</button>
      <button class="btn btn-outline-danger cf_btn cf_cancel_btn">Cancel</button>
  </div>
    </div>`;

        $(document.body).append(cont_html);
    }

    function startProcess() {
        console.log("startProcess called");

        $(".cf_start_btn").hide();
        $(".cf_stop_btn").show();
        $(".cf_text").text("Post Lover Tool Started. Please wait...");

        active_status = true;
        startAction();
    }
    function stopProcess() {
        console.log("stopProcess called");

        active_status = false;
        // $(".cf_start_btn").text("Paused... Click to Resume").show();
        $(".cf_text").text("Post Lover Tool Stoped.");
        $(".cf_stop_btn").hide();
    }

    function cancelProcess() {
        //console.log('cancelProcess called');

        stopProcess();
        $(".cf_overlay").remove();
        $("#cf_controls").remove();
        chrome.runtime.sendMessage({ action: 'closePostLoverCommentWindow', data: { currentWindowId } });
    }

    const startAction = async () => {
        await sleep(2000);
        await postLoverComment();

    }
    const postLoverComment = async () => {
        await scrollToFeed();
        var input = document.getElementsByName("comment_text")[0];
        var submit = document.querySelector('button[type="submit"]');
        submit.disabled = false;
        document.querySelector("#composerInput").value = commentMsg
        $("#composerInput")[0].dispatchEvent(new Event("input"));
        input.value = commentMsg;
        console.log("comment msg", commentMsg);
        await sleep(3000);
        if (active_status == true) {
            submit.click();
            await sleep(1000);
            updateStatusString();
            console.log("wait 3 sec");
            await sleep(2000);

            console.log("Post Commenter opened successfully");
            chrome.runtime.sendMessage({ action: 'closePostLoverCommentWindow', data: { currentWindowId } });
        }
    }

    function sleep(t) {
        return new Promise((e) => setTimeout(e, t));
    }

    async function scrollToFeed() {
        let targetedLikeBtn = $("#composerInput")[0];
        console.log("scrollToFeed called", $(targetedLikeBtn).closest("._7om2._2pin._2pi8._4-vo"));
        let offsetHeight = await $(targetedLikeBtn).closest("._7om2._2pin._2pi8._4-vo")[0]
            .offsetTop;

        let postHeight = await $(targetedLikeBtn).closest("._7om2._2pin._2pi8._4-vo")[0]
            .offsetHeight;
        // console.log("Scroll height: ", offsetHeight)
        window.scrollTo({
            top: offsetHeight - 400,
            behavior: "smooth",
        });

    }

}
