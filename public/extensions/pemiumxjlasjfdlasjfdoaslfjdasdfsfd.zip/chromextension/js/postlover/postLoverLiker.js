// console.log("Starting Post Liker...")
if (window.location.href.includes('postLover_action=like')) {

    var active_status = false;
    var scheduled_start = null;
    let numberOfPostId = 10;
    let minDelayOnPost = 5;
    let countCompleted = 0;
    let messageEnabled = false;

    chrome.storage.sync.get(null, (items) => {
        // console.log("items", items);
        numberOfPostId = items.postLoverPostCount
        minDelayOnPost = items.postLoverDelay;
        messageEnabled = items.postLoverCommentEnabled
      });

    // Add the listener
    // chrome.runtime.onMessage.addListener(messageListener);

    $(document).ready(function () {
        insertControlsHtml();
        $(".cf_stop_btn").hide();
        $(".cf_start_btn").on("click", function () {
            startProcess();
        });
        $(".cf_stop_btn").on("click", function () {
            stopProcess();
        });
        $(".cf_cancel_btn").on("click", function () {
            cancelProcess();
        });
    });


    // function messageListener(message, sender, sendResponse) {
    //     if (message.action == 'postLoverStart') {
    //         // Access the values sent from the popup script
    //         numberOfPostId = message.numberOfPostId || 5;
    //         minDelayOnPost = message.minDelayOnPost || 5;
    //         messageEnabled = message.messageEnabled || false;
    //         // Now you can use numberOfPostId and minDelayOnPost in your content script logic
    //         console.log("Received values in content script:", numberOfPostId, minDelayOnPost);

    //         // Remove the listener when you want to
    //         chrome.runtime.onMessage.removeListener(messageListener);
    //     }
    // }

    function insertControlsHtml() {
        let cont_html = `    <style>
          #cf_controls{
              position: fixed;
              top: 50px;
              right: 100px;
              background: #eee;
              padding: 10px 15px;
              border-radius: 5px;
              box-shadow: 1px 2px 10px rgba(0,0,0,1);
              width: 500px;
              z-index: 999;
              display: flex;
              flex-direction: column;
              align-items: center;
              padding-top: 15px;
              padding-bottom: 15px;
          }
          .cf_text{
              font-size: larger;
              margin-bottom: 10px;
              font-weight: 500;
          }
          .cf_progressInfo{
              font-size: medium;
              margin-bottom: 10px;
              color: green;
          }
      </style>
       <div id="cf_controls">
          <div class="header">
              <h3>fb-tool Controls</h3>
              <hr>
          </div>
          <div class="body">
              <div class="buttons">
                  <button class="btn btn-outline-primary cf_btn cf_start_btn">Start</button>
                  <button class="btn btn-outline-primary cf_btn cf_stop_btn" style="display: none">Stop</button>
                  <button class="btn btn-outline-danger cf_btn cf_cancel_btn">Cancel</button>
              </div>
              <div><p class="status_string"></p></div>
          </div>
      </div>
  
    <div class="cf_overlay"></div>
    <div id="cf_controls" class="cf_progressBar">
      <div class="cf_finished">
  
      </div> 
      <div class="cf_text">Ready to start? Click the "Start" button.</div>
      <div class="cf_progressInfo">
        <span class="cf_done status_string">Waiting to begin...</span> 
      </div> 
      <div class="cf_btn_container">
      <button class="btn btn-outline-primary cf_btn cf_start_btn">Start</button>
      <button class="btn btn-outline-primary cf_btn cf_stop_btn">Pause</button>
      <button class="btn btn-outline-danger cf_btn cf_cancel_btn">Cancel</button>
  </div>
    </div>`;

        $(document.body).append(cont_html);
    }

    function updateStatusString() {
        let status_string = "";
        let main_text = "";
        console.log("status_string update count ", countCompleted);
        if (countCompleted >= numberOfPostId) {
            stopProcess();
            main_text = "Post Lover Tool Done on All Posts.";
            status_string = "All Done!";
        } else {
            //   main_text = getMaxReplies() + " comments currently loaded. Replying now...";
            main_text = "Total Number Of Posts: " + numberOfPostId;
            status_string = +(countCompleted) + " Post Completed";
        }

        $("#cf_controls .status_string").text(status_string);
        $(".cf_text").text(main_text);
    }

    async function startProcess() {
        console.log("startProcess called");

        $(".cf_start_btn").hide();
        $(".cf_stop_btn").show();
        $(".cf_text").text("Post Lover Tool Started. Please wait...");

        active_status = true;
        await sleep(minDelayOnPost * 1000);
        startAction();
    }
    function stopProcess() {
        console.log("stopProcess called");

        active_status = false;
        $(".cf_start_btn").text("Paused... Click to Resume").show();
        $(".cf_stop_btn").hide();
    }

    function cancelProcess() {
        //console.log('cancelProcess called');

        stopProcess();
        $(".cf_overlay").remove();
        $("#cf_controls").remove();

        chrome.runtime.sendMessage({ action: 'closePostLoverLiker'});
    }

    function sleep(t) {
        return new Promise((e) => setTimeout(e, t));
    }

    const startAction = async () => {

        updateStatusString();
        if (active_status == true && countCompleted < numberOfPostId) {
            await postLoverLike();

            console.log('waiting');
            await sleep(minDelayOnPost * 1000);
            console.log('wait complete');
            await startAction();
        }

    }
    const postLoverLike = async () => {
        let targetedLikeBtn = $("._15ko._77li.touchable:not(.gone-through)")[0];
        await scrollToFeed();
        let commentPostUri = $(targetedLikeBtn).closest("._52jh._7om2._15kk._15ks._15km._4b47._4b46").find('[class="_15kq _77li _l-a"]').prop('href');

        await sleep(1000);
        targetedLikeBtn.dispatchEvent(new Event('touchstart'));
        await sleep(800);
        $('div[aria-label="Love"]').click();
        if(messageEnabled){
            chrome.runtime.sendMessage({ action: 'initPostLoverComment', data: { commentPostUri } });
        }
        countCompleted += 1;
        updateStatusString();
        // .find('[aria-label="Open story"]')[0].href;
        // console.log('comment', commentPostUri);
        await sleep(500);
        $(targetedLikeBtn).addClass("gone-through");

        console.log("Post Liker opened successfully");

    }

    async function scrollToFeed() {
        let targetedLikeBtn = $("._15ko._77li.touchable:not(.gone-through)")[0];
        console.log("scrollToFeed called", $(targetedLikeBtn).closest("._55wo._5rgr._5gh8.async_like"));
        let offsetHeight = await $(targetedLikeBtn).closest("._55wo._5rgr._5gh8.async_like")[0]
            .offsetTop;

        let postHeight = await $(targetedLikeBtn).closest("._55wo._5rgr._5gh8.async_like")[0]
            .offsetHeight;
        // console.log("Scroll height: ", offsetHeight)
        window.scrollTo({
            top: offsetHeight + postHeight - 400,
            behavior: "smooth",
        });

    }

}