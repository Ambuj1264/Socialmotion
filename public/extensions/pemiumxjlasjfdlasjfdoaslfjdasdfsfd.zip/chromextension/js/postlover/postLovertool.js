let allCommentsArr = [];
let numberOfPostId = 0;
let minDelayOnPost = 0;
let likePopupWindowId;
let likeTabId;
let commentPopupWindowId;
let messageEnabled = false;
// document.addEventListener("DOMContentLoaded", () => {
//   // allComment();
//   // const createCommentSection = document.getElementById("commentArea");
//   // createCommentSection.style.display = "none";
//   // numberOfPostId = document.getElementById("numberOfPostId").value;
//   // minDelayOnPost = document.getElementById("minDelayOnPost").value;
// });


$(document).ready(function () {

  $("#beginService").click(function () {
    let numberOfPostId = Number($("#numberOfPostId").val());
    let minDelayOnPost = Number($("#minDelayOnPost").val());
    messageEnabled = $("#enableCommentCheckbox").prop("checked");
    if (!numberOfPostId || !minDelayOnPost) {
      toast("Please enter all Fields", "error", "red");
      return;
    }
    chrome.storage.sync.set({ 
      postLoverPostCount: numberOfPostId, 
      postLoverDelay: minDelayOnPost,
      postLoverCommentEnabled : messageEnabled
    });

    if (messageEnabled) {
      if (allCommentsArr.length < 1) {
        toast("Please Add Comments", "error", "red");
        return;
      }
      // console.log("messages", allCommentsArr);
      chrome.storage.sync.set({ postLoverComments: [...allCommentsArr] });
    }
    console.log(
      numberOfPostId,
      minDelayOnPost,
      "numberOfPostId && minDelayOnPost"
    );
    // console.log($("#enableCommentCheckbox").prop("checked"))
    chrome.windows.create({
      type: 'popup',
      url: 'https://m.facebook.com/?postLover_action=like',
      width: 900,
      height: 700,
      left: Math.round(screen.width / 2 - 350),
      top: Math.round(screen.height / 2 - 350)
    }, function (popupWindow) {
      likePopupWindowId = popupWindow.id

      // setTimeout(() => {
      //   console.log("wait end")
      //   likeTabId = popupWindow.tabs[0].id
      //   chrome.tabs.sendMessage(popupWindow.tabs[0].id, {
      //     action: "postLoverStart",
      //     numberOfPostId: numberOfPostId,
      //     minDelayOnPost: minDelayOnPost,
      //     messageEnabled: messageEnabled
      //   });
      // }, 3000)
    });

  })

});

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action == "initPostLoverComment") {
    let commentIndex = Math.floor(Math.random() * allCommentsArr.length);
    // console.log("Comment Index: ", commentIndex)
    let commentMsg = allCommentsArr[commentIndex] || "You Are Awesome";
    // console.log("Comment Message:", commentMsg)
    // Handle the data received from content.js
    // console.log("init comment : ", request.data);
    if (request.data.commentPostUri) {
      chrome.windows.create({
        type: 'popup',
        url: request.data.commentPostUri + '&postLover_action=comment',
        width: 900,
        height: 700,
        left: Math.round(screen.width / 2 - 150),
        top: Math.round(screen.height / 2 - 250)
      }, function (popupWindow) {
        chrome.storage.sync.set({ postLoverCommentWindowId: popupWindow.id });
        // setTimeout(() => {
        //   chrome.tabs.sendMessage(popupWindow.tabs[0].id, {
        //     action: "postLoverComment",
        //     commentMsg: commentMsg,
        //     windowId: popupWindow.id
        //   });
        // }, 3000)
      });
    }
  }
  if (request.action == "closePostLoverCommentWindow") {

    console.log("Comment reply complete. Number of posts comment", request.data)
    chrome.windows.remove(request.data.currentWindowId);
    // console.log("Comment reply complete. Number of posts comment", request.data)
  }
  if (request.action == "closePostLoverLiker") {
    chrome.windows.remove(likePopupWindowId);
  }

  // if (request.action === 'sendInputText') {
  //     let postUrl = request.data;
  //     // Process the input text as needed
  //     console.log('Received input text:', postUrl);
  //     $('#post_id').val(postUrl)
  //     // Close the popup window using its ID
  //     if (popupWindowId) {
  //         chrome.windows.remove(popupWindowId);
  //         popupWindowId = null; // Reset the popup window ID
  //     }
  // }
});



document.getElementById("commentAddId").addEventListener("click", () => {
  try {
    const createMessageComment = document.getElementById(
      "createMessageComment"
    ).value;
    if (!createMessageComment) {
      alert("Please provide the input");
    } else {
      allCommentsArr.push(createMessageComment);
      document.getElementById("createMessageComment").value = "";
      allComment();
      console.log(allCommentsArr, "allCommentsArr");
    }
  } catch (error) {
    console.log(error.message);
  }
});
let commentChecked = document
  .getElementById("enableCommentCheckbox")
  .addEventListener("change", () => {
    const createCommentSection = document.getElementById("commentArea");
    createCommentSection.style.display = enableCommentCheckbox.checked
      ? "flex"
      : "none";
  });


// dom input validation start
const numberOfPostIdInput = document.getElementById("numberOfPostId");
const numberOfPostIdError = document.getElementById("numberOfPostIdError");

numberOfPostIdInput.addEventListener("input", () => {
  const numberOfpost = numberOfPostIdInput.value;
  if (!numberOfpost || numberOfpost === "") {
    numberOfPostIdError.innerHTML = "Field is required";
  } else if (numberOfpost < 1) {
    numberOfPostIdError.innerHTML = "Number of post should be greater than 0";
  } else {
    numberOfPostIdError.innerHTML = ""; // Clear error message
  }
  numberOfPostId = numberOfpost;
});
const minDelayOnPostInput = document.getElementById("minDelayOnPost");
const minDelayOnPostError = document.getElementById("minDelayOnPostError");

minDelayOnPostInput.addEventListener("input", () => {
  const delay = minDelayOnPostInput.value;
  if (!delay || delay === "") {
    minDelayOnPostError.innerHTML = "Field is required";
  } else if (delay < 30) {
    minDelayOnPostError.innerHTML = "Delay should be greater than 30 sec";
  } else {
    minDelayOnPostError.innerHTML = ""; // Clear error message
  }
  minDelayOnPost = delay;
});
// dom input validation end



function allComment() {
  console.log("All comments")
  const allCommentBoxDiv = document.getElementById("allCommentBoxDiv");
  const allCommentBox = document.getElementById("allCommentBox");

  const allCommentList = allCommentsArr
    .map(
      (value, index) => `
        <li class="py-2">
            ${value} 
            <button class="btn btn-danger btn-sm mx-2" data-index="${index}" style="font-size:xx-small"> X </button>
        </li>
    `
    )
    .join(""); // Join the array elements into a single string

  // if (allCommentList) {
  allCommentBox.innerHTML = allCommentList;
  // Add event listeners to the dynamically created buttons
  document.querySelectorAll(".btn-danger").forEach((button) => {
    button.addEventListener("click", () => {
      const index = button.getAttribute("data-index");
      removeComment(index);
    });
  });
  // }
}

function removeComment(index) {
  allCommentsArr = allCommentsArr.filter(
    (val, ind) => ind !== parseInt(index, 10)
  );
  allComment();
}


function sleep(t) {
  return new Promise((e) => setTimeout(e, t));
}

function toast(heading, icon, color) {
  $.toast({
    text: "",
    heading: heading,
    icon: icon,
    showHideTransition: "fade",
    allowToastClose: true,
    hideAfter: 3000,
    stack: 5,
    position: "top-right",

    textAlign: "left",
    loader: true,
    loaderBg: color,
    beforeShow: function () { },
    afterShown: function () { },
    beforeHide: function () { },
    afterHidden: function () { },
  });
}