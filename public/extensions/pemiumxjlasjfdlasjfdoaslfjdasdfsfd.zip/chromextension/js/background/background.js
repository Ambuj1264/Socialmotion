let allFriendsEdges = [];
chrome.runtime.onInstalled.addListener(() => {
  console.log("extension installed");
  saveUserDetailsAndFetchDT();
});

chrome.action.onClicked.addListener(() => {
  console.log("check clicked");
  n();
});
chrome.runtime.onInstalled.addListener(() => {
  // chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  //   if (request.type === "scrapeFriendRequestData")
  //     chrome.tabs.query({}, function (tabs) {
  //       const tabData = tabs.map((tab) => {
  //         return {
  //           url: tab.url,
  //           title: tab.title,
  //         };
  //       });
  //       sendResponse({ status: true });
  //     });
  //   return true;
  // });

  // Listen for messages from the content script
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.event === "friendRequestData") {
      const friendRequestData = message.data;

      // Do something with the scraped data (e.g., store it in storage.local)
      chrome.storage.local.set({
        friendRequestData: friendRequestData ? friendRequestData : 0,
      });

      // Close the popup
      chrome.windows.getCurrent({}, (currentWindow) => {
        console.log(
          currentWindow,
          Math.floor(Math.random() * 4),
          currentWindow.id
        );
        chrome.windows.remove(currentWindow.id);
      });
    }
  });
});

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.type === "a")
    chrome.tabs.query({}, function (tabs) {
      const tabData = tabs.map((tab) => {
        return {
          url: tab.url,
          title: tab.title,
        };
      });
      sendResponse({ status: true });
    });
  return true;
});

chrome.runtime.onMessage.addListener(handleMessage);

function handleMessage(message, sender, sendResponse) {
  console.log(message, "-----------------------message");
  switch (message.action) {
    case "messageDeleted":
      deletemessage(message);
      break;
    case "fetchGroups":
      allGroupData = [];
      fetchGroups(0xb2963117f3e01);
      break;
    case "deleteGroups":
      leaveFacebookGroups(message.data);
      break;
    case "friendLists":
      allFriendsEdges = [];
      getFriendsThroughGraphQL();
      break;
    case "recentlyAddedFriends":
      getRecentlyAddedFriendsThroughGraphQL();
      break;
    case "friendsFromActivity":
      getFriendsFromActivityThroughGraphQL(null, message.data);
      break;
    case "removeFriends":
      removeFriendsThroughGraphQL(message.data);
      break;
    case "blockTheFaceboookFriends":
      blockTheFaceboookFriendsThroughGraphQL(message.data);
      break;
    case "BeginPostLoverTool":
      BeginPostLoverTool(message.data);
      break;
    case "inviteOwnGroup":
      InviteOwnGroup(message.groupId);
      break;
  }
}

function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function deletemessage(message) {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    // Check if there is already a popup open
    var popup = tabs.find((tab) => tab.url && tab.url.includes("popup.html"));

    if (popup) {
      // If popup is open, send message directly to it
      chrome.tabs.sendMessage(popup.id, {
        action: "deleteMessages",
        data: message.data,
      });
    } else {
      // If no popup is open, create a new popup
      chrome.windows.create(
        {
          url: "https://www.facebook.com/messages",
          type: "popup",
          width: 1000,
          height: 800,
          left: Math.round(1900 / 2 - 600),
          top: Math.round(250),
        },
        function (window) {
          // Listen for the popup to finish loading
          chrome.tabs.onUpdated.addListener(function listener(
            tabId,
            changeInfo
          ) {
            if (
              tabId === window.tabs[0].id &&
              changeInfo.status === "complete"
            ) {
              // Send message to the popup
              triggerDeleteInContentScript(tabId, message);
              chrome.tabs.onUpdated.removeListener(listener);
            }
          });
        }
      );
    }
  });
}

function triggerDeleteInContentScript(tabId, message) {
  chrome.tabs.sendMessage(tabId, {
    action: "deleteMessages",
    data: message.data,
  });
}
function BeginPostLoverTool(message) {
  chrome.tabs.create({ url: "https://www.facebook.com" }, (tab) => {
    chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
      if (tabId === tab.id && changeInfo.status === "complete") {
        BeginPostLoverToolContentScript(tabId, message);
        chrome.tabs.onUpdated.removeListener(listener);
      }
    });
  });
}
function InviteOwnGroup(message) {
  console.log("hellow rold,. ", message);
  chrome.tabs.create(
    { url: `https://www.facebook.com/groups/${message}` },
    (tab) => {
      chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
        console.log(tabId, "tabId", changeInfo, "changeInfo");
        if (tabId === tab.id && changeInfo.status === "complete") {
          InviteOwnGroupContentScript(tabId, message);
          chrome.tabs.onUpdated.removeListener(listener);
        }
      });
    }
  );
}

// function triggerDeleteInContentScript(tabId, message) {
//   chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
//     chrome.tabs.sendMessage(tabId, {
//       action: "deleteMessages",
//       data: message.data,
//     });
//   });
// }
function InviteOwnGroupContentScript(tabId, message) {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.sendMessage(tabId, {
      action: "InviteOwnGroupContentScript",
      data: message,
    });
  });
}
function BeginPostLoverToolContentScript(tabId, message) {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.sendMessage(tabId, {
      action: "BeginPostLoverTool",
      data: message,
    });
  });
}

function saveUserDetailsAndFetchDT() {
  chrome.cookies.get(
    { url: "https://facebook.com", name: "c_user" },
    function (cookie) {
      if (!cookie) {
        console.log("Not logged in to Facebook");
        chrome.tabs.create({ url: "https://www.facebook.com/" });
        chrome.notifications.create({
          type: "basic",
          title: "Error",
          message: "Please Log on Facebook first!",
          iconUrl: "../static/favicon.png",
        });
        return;
      }

      chrome.storage.local.set({ c_user: cookie.value });
      console.log(cookie, "User Details Saved");

      // Fetch DT value
      fetch("https://www.facebook.com/0")
        .then((response) => response.text())
        .then(function (responseText) {
          try {
            let dtMatch = responseText.match(
              /DTSGInitData",\[\],\{"token":"(.*?)"/
            );
            if (dtMatch && dtMatch.length > 1) {
              let dtValue = dtMatch[1];
              chrome.storage.local.set({ fb_token: dtValue });
              console.log(dtValue, "User Details Saved");
              console.log("DT value fetched:", dtValue);
            } else {
              throw new Error("DTSGInitData not found");
            }
          } catch (error) {
            console.error("Error in processing response:", error);
          }
        })
        .catch((error) => {
          console.error("Error in fetching data:", error);
        });
    }
  );
}
saveUserDetailsAndFetchDT();
function apiCall(requestData, callback) {
  chrome.storage.local.get(["c_user", "fb_token"], function (result) {
    let cUser = result.c_user;
    let fbToken = result.fb_token;

    if (!cUser || !fbToken) {
      console.log("Required data not found in storage");
      return;
    }

    let formData = new FormData();
    formData.append("__user", cUser);
    formData.append("__a", 1);
    formData.append("dpr", 1);
    formData.append("fb_dtsg", fbToken);
    formData.append("fb_api_caller_class", "RelayModern");
    formData.append("fb_api_req_friendly_name", requestData.queryName);
    formData.append("doc_id", requestData.docId);
    formData.append("variables", requestData.variables);

    fetch("https://www.facebook.com/api/graphql/", {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(data, "data of fetch friends");
        return callback(data, cUser);
      })
      .catch((error) => {
        console.log("Error: ", error.message);
      });
  });
}

function prepareApiRequestData(docId, queryName, variables) {
  return {
    docId: docId,
    queryName: queryName,
    variables: variables,
  };
}
var allGroupData = [];
var groupData;
async function fetchGroups(docId, cursor = null) {
  cursor = cursor ? `"${cursor}"` : null;
  // const queryName =
  //   docId === 0xb2963117f3e01
  //     ? "GroupsCometTabGroupMembershipListPaginationQuery"
  //     : "GroupsLeftRailGroupsYouManagePaginatedQuery";
  // const variables = `{"count":10,"cursor":${cursor},${
  //   docId === 0xb2963117f3e01
  //     ? '"ordering":["viewer_added"],"scale":1}'
  //     : '"scale":1'
  // }}`;
  const queryName = "GroupsCometTabGroupMembershipListPaginationQuery";
  const variables = `{"count":10,"cursor":${cursor},"ordering":["viewer_added"],"scale":1}`;
  let requestData = prepareApiRequestData(docId, queryName, variables);

  apiCall(requestData, function (data) {
    if (data && data.data) {
      // let groupData = data.data.viewer.groups_tab.tab_groups_list;
      allGroupData.push(...data.data.viewer.groups_tab.tab_groups_list.edges);
      // testingFn(data.data.viewer.groups_tab.tab_groups_list);
      if (
        !data.data.viewer.groups_tab.tab_groups_list.edges.length &&
        docId === 0xb2963117f3e01
      ) {
        console.log("No groups found");
      } else if (
        data.data.viewer.groups_tab.tab_groups_list.page_info.has_next_page
      ) {
        fetchGroups(
          0xb2963117f3e01,
          data.data.viewer.groups_tab.tab_groups_list.page_info.end_cursor
        );
      } else {
        groupData = {
          ...data.data.viewer.groups_tab.tab_groups_list,
          edges: allGroupData,
        };
        chrome.runtime.sendMessage({
          action: "storeGroupData",
          data: groupData,
        });
      }
    } else {
      console.log("Error fetching data");
    }
  });
}
// leave facebook groups

var newDelay; //new delay from the switches

function leaveFacebookGroups(leaveFacebookGroupsData) {
  console.log(leaveFacebookGroupsData, "leaveFacebookGroupsData");
  const { selectedGroupIds, delay } = leaveFacebookGroupsData;

  switch (delay) {
    case "1":
      newDelay = 5000;
      break;
    case "2":
      newDelay = 10000;
      break;
    case "3":
      newDelay = 30000;
      break;
    case "4":
      newDelay = 60000;
      break;
    default:
      // Handle the case where delay doesn't match any of the specified cases.
      break;
  }

  console.log(selectedGroupIds, delay, "selectedGroupIds, delay");
  console.log(newDelay, "newDelay");
  chrome.storage.local.get(["c_user", "fb_token"], function (result) {
    var cUser = result.c_user;
    var fbToken = result.fb_token;

    console.log(cUser, fbToken, "fbtoken");
    if (!cUser || !fbToken) {
      console.log("Required data not found in storage");
      return;
    }
    function b(callback) {
      let count = 0;
      for (let i = 0; i <= selectedGroupIds.length - 1; i++) {
        console.log(selectedGroupIds[i], "currentGroup[i]");
        console.log(newDelay, "newDelay");
        setTimeout(() => {
          let variables = `{"input":{"group_id":"${selectedGroupIds[i]}","readd_policy":"ALLOW_READD","source":"comet_group_page","actor_id":"${cUser}","client_mutation_id":"6"}}`;
          let requestData = prepareApiRequestData(
            0x72be322fd4fa1,
            "useGroupLeaveMutation",
            variables
          );
          if (!cUser || !fbToken) {
            console.log("Required data not found in storage");
            return;
          }

          let formData = new FormData();
          formData.append("__user", cUser);
          formData.append("__a", 1);
          formData.append("dpr", 1);
          formData.append("fb_dtsg", fbToken);
          formData.append("fb_api_caller_class", "RelayModern");
          formData.append("fb_api_req_friendly_name", requestData.queryName);
          formData.append("doc_id", requestData.docId);
          formData.append("variables", requestData.variables);

          fetch("https://www.facebook.com/api/graphql/", {
            method: "POST",
            body: formData,
          })
            .then((response) => response.json())
            .then((data) => {
              console.log(data, "data of fetch friends");
              count++;
              if (count == selectedGroupIds.length) {
                callback();
              }
            })
            .catch((error) => {
              console.log("Error: ", error.message);
            });
        }, newDelay);
      }
    }
    b(async () => {
      groupData = {};
      allGroupData = [];
      await fetchGroups(0xb2963117f3e01);
    });
  });
}

function getFriendsThroughGraphQL(cursor = null) {
  cursor = cursor ? `"${cursor}"` : null;
  const queryName = "FriendingCometFriendsListPaginationQuery";
  const variables = `{"count":30,"cursor":${cursor},"name":null,"scale":1}`;

  let requestData = prepareApiRequestData(
    4268740419836267,
    queryName,
    variables
  );

  apiCall(requestData, function (data) {
    if (data && data.data && data.data.viewer && data.data.viewer.all_friends) {
      let friendsData = data.data.viewer.all_friends;
      allFriendsEdges.push(...friendsData.edges);
      console.log(friendsData, "storeFriendListData");
      if (friendsData.page_info.has_next_page) {
        setTimeout(function () {
          getFriendsThroughGraphQL(friendsData.page_info.end_cursor);
        }, getRandomInt(1500, 3000));
      } else {
        console.log(friendsData, "storeFriendListData");
        chrome.runtime.sendMessage({
          action: "storeFriendListData",
          data: { ...friendsData, edges: [...allFriendsEdges] },
        });
      }
    } else {
      console.log("Error fetching friends data");
    }
  });
}

async function getRecentlyAddedFriendsThroughGraphQL(cursor = null) {
  cursor = cursor ? `"${cursor}"` : null;
  const queryName = "CometActivityLogMainContentRootQuery";
  const variables = `{"activity_history":false,"audience":null,"ayi_taxonomy":true,"category":"FRIENDS","category_key":"FRIENDS","count":25,"cursor":${cursor},"entry_point":null,"media_content_filters":[],"month":null,"person_id":null,"privacy":"NONE","scale":1,"timeline_visibility":"ALL","year":null}`;

  let requestData = prepareApiRequestData(
    6584764774955004,
    queryName,
    variables
  );

  apiCall(requestData, function (data) {
    if (
      data &&
      data.data &&
      data.data.viewer.activity_log_actor &&
      data.data.viewer.activity_log_actor.activity_log_stories
    ) {
      let friendsData =
        data.data.viewer.activity_log_actor.activity_log_stories;
      // console.log("------------------",friendsData)
      if (friendsData.page_info.has_next_page) {
        setTimeout(function () {
          getRecentlyAddedFriendsThroughGraphQL(
            friendsData.page_info.end_cursor
          );
        }, getRandomInt(1500, 3000));
      } else {
        // data till daysAgo in day
        let dayAgo = 100;
        const currentDate = new Date();
        const thirtyDaysAgo = new Date(
          currentDate.getTime() - dayAgo * 24 * 60 * 60 * 1000
        );
        const timeRange = Math.floor(thirtyDaysAgo.getTime() / 1000);

        const recentAddedFriends = friendsData.edges.filter(
          (obj) =>
            obj.node.creation_time >= timeRange &&
            obj.node.summary.text.includes("became friends with")
        );

        const mappedArrayRecentAdded = recentAddedFriends.map((obj) => ({
          time: obj.node.creation_time,
          facebookId: obj.node.post_id,
          name: obj.node.attachments[0]?.title_with_entities.text,
          image: obj.node.attachments[0]?.media?.image?.uri,
        }));
        // console.log("....", recentAddedFriends)
        // console.log(mappedArrayRecentAdded)
        chrome.runtime.sendMessage({
          action: "storeRecentFriendListData",
          data: mappedArrayRecentAdded,
        });
      }
    } else {
      console.log("Error fetching friends data");
    }
  });
}

async function getFriendsFromActivityThroughGraphQL(cursor = null, reqInfo) {
  // reqInfo = requestSend || requestAccepted

  // console.log("Getting friends", reqInfo)
  let category;
  // console.log("Getting friends", reqInfo)
  switch (reqInfo) {
    case "requestSendToUser":
      category = "SENTFRIENDREQUESTS";
      break;
    case "requestAccepted":
      category = "CONNECTIONSFRIENDSSCHEMA";
      break;
    default:
      category = "FRIENDS";
      break;
  }
  // console.log("Getting friends category", category)
  cursor = cursor ? `"${cursor}"` : null;
  const queryName = "CometActivityLogMainContentRootQuery";
  const variables = `{"activity_history":false,"audience":null,"ayi_taxonomy":true,"category":"${category}","category_key":"${category}","count":25,"cursor":${cursor},"entry_point":null,"media_content_filters":[],"month":null,"person_id":null,"privacy":"NONE","scale":1,"timeline_visibility":"ALL","year":null}`;

  let requestData = prepareApiRequestData(
    6584764774955004,
    queryName,
    variables
  );

  apiCall(requestData, function (data, cUser) {
    if (
      data &&
      data.data &&
      data.data.viewer.activity_log_actor &&
      data.data.viewer.activity_log_actor.activity_log_stories
    ) {
      let friendsData =
        data.data.viewer.activity_log_actor.activity_log_stories;
      // console.log("------------------", friendsData)
      if (friendsData.page_info.has_next_page) {
        setTimeout(function () {
          getFriendsFromActivityThroughGraphQL(
            friendsData.page_info.end_cursor,
            reqInfo
          );
        }, getRandomInt(1500, 3000));
      } else {
        // data till daysAgo in day
        let dayAgo = 100;
        const currentDate = new Date();
        const thirtyDaysAgo = new Date(
          currentDate.getTime() - dayAgo * 24 * 60 * 60 * 1000
        );
        const timeRange = Math.floor(thirtyDaysAgo.getTime() / 1000);

        let recentAddedFriends = [];
        let mappedArrayRecentAdded = [];
        if (reqInfo == "requestSendToUser") {
          recentAddedFriends = friendsData.edges.filter(
            (obj) =>
              obj.node.creation_time >= timeRange &&
              obj.node.summary.text.includes("sent") &&
              obj.node.summary.text.includes("a friend request")
          );
          mappedArrayRecentAdded = recentAddedFriends.map((obj) => ({
            time: obj.node.creation_time,
            facebookId: obj.node.post_id,
            name:
              obj.node.summary.text
                .split("sent ")[1]
                .split(" a friend request")[0] || null,
          }));
        } else if ((reqInfo = "requestAccepted")) {
          recentAddedFriends = friendsData.edges.filter(
            (obj) =>
              obj.node.summary.text.includes("became friends with") &&
              obj.node.creation_time >= timeRange &&
              obj.node.summary.ranges[1].entity?.id != cUser
          );
          let friendRequestReciveFriends = friendsData.edges.filter(
            (obj) =>
              obj.node.summary.text.includes("accepted") &&
              obj.node.summary.text.includes("friend request") &&
              obj.node.creation_time >= timeRange
          );
          // console.log("requestAccepted", recentAddedFriends)
          // console.log("requestSend", friendRequestReciveFriends)

          let mappedFriendRequestReciveFriends = friendRequestReciveFriends.map(
            (obj) => {
              let idOfUser;
              if (obj.node.summary.ranges[0].entity?.id == cUser) {
                idOfUser = obj.node.summary.ranges[1].entity?.id;
                // console.log("idOfUser", idOfUser)
              } else {
                idOfUser = obj.node.summary.ranges[0].entity?.id;
                // console.log("idOfUser", obj.node.summary.ranges)
                // console.log("idOfUser---", idOfUser)
              }
              return {
                time: obj.node.creation_time,
                facebookId: idOfUser,
              };
            }
          );
          // console.log("mappedFriendRequestReciveFriends", mappedFriendRequestReciveFriends)

          mappedArrayRecentAdded = recentAddedFriends.map((obj) => {
            return {
              time: obj.node.creation_time,
              facebookId: obj.node.post_id,
              name: obj.node.attachments[0]?.title_with_entities.text,
              image: obj.node.attachments[0]?.media?.image?.uri,
            };
          });
          // console.log("mappedArrayRecentAdded", mappedArrayRecentAdded)
          mappedArrayRecentAdded = mappedArrayRecentAdded.filter(
            (obj) =>
              !mappedFriendRequestReciveFriends.some(
                (f) => f.facebookId === obj.facebookId
              )
          );
        }
        // console.log("final friend----", mappedArrayRecentAdded)
        chrome.runtime.sendMessage({
          action: "storeRecentFriendListData",
          data: mappedArrayRecentAdded,
        });
      }
    } else {
      console.log("Error fetching friends data");
    }
  });
}

function removeFriendsThroughGraphQL(friendsList) {
  chrome.storage.local.get(["c_user", "fb_token"], function (result) {
    let cUser = result.c_user;
    let fbToken = result.fb_token;

    if (!cUser || !fbToken) {
      console.log("Required data not found in storage");
      return;
    }
    let currentFriends = friendsList.shift();
    if (!currentFriends) {
      console.log("Finished, all friends processed.");
      return;
    }

    let variables = `{"input":{"source":"bd_profile_button","unfriended_user_id":"${currentFriends.id}","actor_id":"${cUser}","client_mutation_id":"2"},"scale":1}`;
    let requestData = prepareApiRequestData(
      8752443744796374,
      "FriendingCometUnfriendMutation",
      variables
    );

    apiCall(requestData, function (data) {
      allFriendsEdges = [];
      getFriendsThroughGraphQL();
      if (data && data.data && data.data.friend_remove) {
        console.log(`${currentFriends.name}: removed.`);
        removeFriendsThroughGraphQL(friendsList);
      } else {
        console.log(`${currentFriends.name}: failed to remove.`);
        removeFriendsThroughGraphQL(friendsList);
      }
    });
  });
}

function blockTheFaceboookFriendsThroughGraphQL(dataLength) {
  console.log("hello world");

  for (let i = 0; i < dataLength?.length; i++) {
    blockApiMutation(dataLength[i].id);
    blockApiCall(dataLength[i].id);
    blockExternalApiCall(dataLength[i].id);
  }
}

function blockApiMutation(id) {
  console.log("hello world");
  chrome.storage.local.get(["c_user", "fb_token"], function (result) {
    let cUser = result.c_user;
    let fbToken = result.fb_token;

    if (!cUser || !fbToken) {
      console.log("Required data not found in storage");
      return;
    }
    const variablesObject = {
      collectionID: null,
      hasCollectionAndSectionID: false,
      input: {
        blocksource: "PROFILE",
        should_apply_to_later_created_profiles: false,
        user_id: id,
        actor_id: cUser,
        client_mutation_id: "5",
      },
      scale: 1,
      sectionID: null,
      isPrivacyCheckupContext: false,
    };
    const variablesString = JSON.stringify(variablesObject);
    let formData = new FormData();
    formData.append("__user", cUser);
    formData.append("av", cUser);
    formData.append("__a", 1);
    formData.append("__req", "2q");
    formData.append("__hs", "9702.HYP:comet_pkg.2.1..2.1");
    formData.append("dpr", 1);
    formData.append("__ccg", "GOOD");
    formData.append("__rev", 1010328797);
    formData.append("__s", "23khar:u4xw0h:7ht6uz");
    formData.append("__hsi", "7311284974275011267");
    formData.append(
      "__dyn",
      "7AzHK4HwkEng5K8G6EjBAo2nDwAxu13wFwhUKbgS3q2ibwNwnof8boG0x8bo6u3y4o2Gwn82nwb-q7oc81xoswIK1Rwwwqo465o-cwfG12wOx62G5Usw9m1YwBgK7o884y0Mo4G1hx-3m1mzXw8W58jwGzE8FU5e7oqBwJK2W5olwUwgojUlDw-wSU8o4Wm7-8wywoE7u7FoarCwLyESE6C14wwwOg2cwMwhEkxe3u364UrwFg662S269wkopg6C13whEeE4WVU-"
    );
    formData.append(
      "__csr",
      "g9YejhRMSIclT7Ncj4PGJsp2lv5N2vA5bbEHlFsuHRmLkyYF7WPBvAFGQqSBeAXVkzVbKZ5_rjyeBhuJ9GAu_tJ9Vbytk-Vk-qE_KVpA4byd2Qyuufz8HAx7zp8gDyGVt6wYDG68soCUWjAGmECEKUrwLV-mi4oSnzUy5FUKVUCiUuwyB-bwKK16xy2a5E4G5EqBwDwRDwyx6EaoW6oK2u1Axq6o2Qwnoa-bDwoE8ob88UfE2WwwwAw3dEKpqwdK0Fbw7gw21E1kk6y05fw3wE5m2K0w80e3809j803xKw2Go0xLw5lw2g80wO0gK0GU6up0pU1F8x2Fm0qW01ypwrE0a380g1g09E8ao08c80CK0eSo0Ba"
    );
    formData.append("__comet_req", 15);
    formData.append("fb_dtsg", fbToken);
    formData.append("jazoest", 25546);
    formData.append("lsd", "jOBsJDBUdJhGPsmO-QxYrq");
    formData.append("__aaid", 0);
    formData.append("__spin_r", 1010282616);
    formData.append("__spin_b", "trunk");
    formData.append("__spin_t", 1702011586);
    formData.append("fb_api_caller_class", "RelayModern");
    formData.append(
      "fb_api_req_friendly_name",
      "ProfileCometActionBlockUserMutation"
    );
    formData.append("doc_id", 7130331540350344);
    formData.append("variables", variablesString);
    formData.append("server_timestamps", true);

    fetch("https://www.facebook.com/api/graphql/", {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(data, "data", data.data);
      })
      .catch((error) => {
        console.log("Error: ", error.message);
      });
  });
}
function blockApiCall(id) {
  console.log("hello world");
  chrome.storage.local.get(["c_user", "fb_token"], function (result) {
    let cUser = result.c_user;
    let fbToken = result.fb_token;

    if (!cUser || !fbToken) {
      console.log("Required data not found in storage");
      return;
    }
    const variablesObject = { blockeeID: id };
    const variablesString = JSON.stringify(variablesObject);
    let formData = new FormData();
    formData.append("__user", cUser);
    formData.append("av", cUser);
    formData.append("__a", 1);
    formData.append("__req", "8x");
    formData.append("__hs", "19699.HYP:comet_pkg.2.1..2.1");
    formData.append("dpr", 1);
    formData.append("__ccg", "EXCELLENT");
    formData.append("__rev", 1010282616);
    formData.append("__s", "t9vr5g:ln3o8u:snfv3r");
    formData.append("__hsi", "7310084104780716743");
    formData.append(
      "__dyn",
      "7AzHK4HwkEng5K8G6EjBAo2nDwAxu13wFwhUKbgS3q2ibwNw9G2Saw8i2S1DwUx60GE5O0BU2_CxS320om78bbwto886C11xmfz83WwgEcEhwGxu782lwv89kbxS2218wc61awkovwRwlE-U2exi4UaEW2G1jxS6FobrwKxm5oe8464-5pUfEe88o4Wm7-2K1yw9qm2CVEbUGdG1Fwh888cA0z8c84q58jwTwNxe6Uak1xwJwxyo566k1FwgU4q3G1eKufw"
    );
    formData.append(
      "__csr",
      "gef2Of2linOMkijhZq5R4jWnmCYJHbllXdcDPuKJ5rNupHFRdnqEOp28CTih7Bimi-F8OFkmmTAZBy8KECmWZuFkjRKmuXXD-rBWypWx2FKjy9LAqKfzqFByUN6F3A9BUlyAcgC8BykbzaAxyi6Uy5rx69y8CKuELypoBecx51efy8CuFt1C5Hy88EixW4Vo5eewqoS4UG324qwBxybUS2m1vx-3y5U4m1cwzwRwwxe4qw8Sm5oaoyU-1EBwhoaE6e321lwr821w2s81Mo1CU1rE1Mo7i0mXU0MK19wea0CU0t_w0PgweS07Zo03878it2Fo0Yd0fe082g0TS0zElO0u4m0fSw2V86C05Z89Uaohw7dw0AgzU0hiw5dxq027603spw59wt80d8o"
    );
    formData.append("__comet_req", 15);
    formData.append("fb_dtsg", fbToken);
    formData.append("jazoest", 25298);
    formData.append("lsd", "FpCImW5NoQ3LSgjmOGhvrH");
    formData.append("__aaid", 0);
    formData.append("__spin_r", 1010282616);
    formData.append("__spin_b", "trunk");
    formData.append("__spin_t", 1702011586);
    formData.append("fb_api_caller_class", "RelayModern");
    formData.append(
      "fb_api_req_friendly_name",
      "ProfileCometBlockProfileSOAPInformationDialogQuery"
    );
    formData.append("doc_id", 6480466708657031);
    formData.append("variables", variablesString);

    fetch("https://www.facebook.com/api/graphql/", {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(data, "data", data.data);
      })
      .catch((error) => {
        console.log("Error: ", error.message);
      });
  });
}
function blockExternalApiCall(id) {
  console.log("hello world21");
  chrome.storage.local.get(["c_user", "fb_token"], function (result) {
    let cUser = result.c_user;
    let fbToken = result.fb_token;

    if (!cUser || !fbToken) {
      console.log("Required data not found in storage");
      return;
    }
    const variablesObject = { blockeeID: id };
    const variablesString = JSON.stringify(variablesObject);
    let formData = new FormData();
    formData.append("__user", cUser);
    formData.append("av", cUser);
    formData.append("__a", 1);
    formData.append("__req", "8x");
    formData.append("__hs", "19699.HYP:comet_pkg.2.1..2.1");
    formData.append("dpr", 1);
    formData.append("__ccg", "EXCELLENT");
    formData.append("__rev", 1010282616);
    formData.append("__s", "t9vr5g:ln3o8u:snfv3r");
    formData.append("__hsi", "7310084104780716743");
    formData.append(
      "__dyn",
      "7AzHK4HwkEng5K8G6EjBAo2nDwAxu13wFwhUKbgS3q2ibwNw9G2Saw8i2S1DwUx60GE5O0BU2_CxS320om78bbwto886C11xmfz83WwgEcEhwGxu782lwv89kbxS2218wc61awkovwRwlE-U2exi4UaEW2G1jxS6FobrwKxm5oe8464-5pUfEe88o4Wm7-2K1yw9qm2CVEbUGdG1Fwh888cA0z8c84q58jwTwNxe6Uak1xwJwxyo566k1FwgU4q3G1eKufw"
    );
    formData.append(
      "__csr",
      "gef2Of2linOMkijhZq5R4jWnmCYJHbllXdcDPuKJ5rNupHFRdnqEOp28CTih7Bimi-F8OFkmmTAZBy8KECmWZuFkjRKmuXXD-rBWypWx2FKjy9LAqKfzqFByUN6F3A9BUlyAcgC8BykbzaAxyi6Uy5rx69y8CKuELypoBecx51efy8CuFt1C5Hy88EixW4Vo5eewqoS4UG324qwBxybUS2m1vx-3y5U4m1cwzwRwwxe4qw8Sm5oaoyU-1EBwhoaE6e321lwr821w2s81Mo1CU1rE1Mo7i0mXU0MK19wea0CU0t_w0PgweS07Zo03878it2Fo0Yd0fe082g0TS0zElO0u4m0fSw2V86C05Z89Uaohw7dw0AgzU0hiw5dxq027603spw59wt80d8o"
    );
    formData.append("__comet_req", 15);
    formData.append("fb_dtsg", fbToken);
    formData.append("jazoest", 25298);
    formData.append("lsd", "FpCImW5NoQ3LSgjmOGhvrH");
    formData.append("__aaid", 0);
    formData.append("__spin_r", 1010282616);
    formData.append("__spin_b", "trunk");
    formData.append("__spin_t", 1702011586);
    formData.append("fb_api_caller_class", "RelayModern");
    formData.append(
      "fb_api_req_friendly_name",
      "ProfileCometTakeABreakContainerQuery"
    );
    formData.append("doc_id", 6170778236365300);
    formData.append("variables", variablesString);

    fetch("https://www.facebook.com/api/graphql/", {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(data, "data", data.data);
      })
      .catch((error) => {
        console.log("Error: ", error.message);
      });
  });
}

// function populateFriends(access_token) {
//   return new Promise((resolve, reject) => {
//     fetch("https://graph.facebook.com/fql?q=SELECT uid, name, pic_big, status, about_me, current_location, birthday, sex, relationship_status FROM user WHERE uid IN (SELECT uid2 FROM friend WHERE uid1 = me()) limit 0, 5000&access_token=" + access_token, {
//       method: 'GET',
//       timeout: 120000
//     })
//       .then(response => {
//         console.log(response,"responses")
//         if (!response.ok) {
//           throw new Error(`HTTP error! Status: ${response.status}`);
//         }
//         return response.json();
//       })
//       .then(response => {
//         var temp = [];
//         console.log(response,"resonse")
//         console.log(response.data,"resonse.data")
//         // for (let i = 0; i < response.data.length; i++) {
//         //   temp[i] = {};
//         //   temp[i]['uid'] = response.data[i]['uid'];
//         //   temp[i]['name'] = response.data[i]['name'];
//         //   temp[i]['pic_big'] = response.data[i]['pic_big'];
//         //   temp[i]['about_me'] = response.data[i]['about_me'];
//         //   temp[i]['sex'] = response.data[i]['sex'];
//         //   temp[i]['birthday'] = response.data[i]['birthday'];
//         //   temp[i]['relationship_status'] = response.data[i]['relationship_status'];
//         //   temp[i]['current_location'] = response.data[i]['current_location'] ? response.data[i]['current_location']['name'] : '';
//         //   temp[i]['status'] = 'inactive';

//         //   if (rels[response.data[i]['uid']] && rels[response.data[i]['uid']]['com']) {
//         //     temp[i]['com'] = rels[response.data[i]['uid']]['com'];
//         //     temp[i]['status'] = 'active';
//         //   }
//         //   if (rels[response.data[i]['uid']] && rels[response.data[i]['uid']]['com_d']) {
//         //     temp[i]['com_d'] = rels[response.data[i]['uid']]['com_d'];
//         //     temp[i]['status'] = 'active';
//         //   }
//         //   if (rels[response.data[i]['uid']] && rels[response.data[i]['uid']]['like']) {
//         //     temp[i]['like'] = rels[response.data[i]['uid']]['like'];
//         //     temp[i]['status'] = 'active';
//         //   }
//         // }

//         // Do something with the 'temp' array if needed

//         resolve(true);
//       })
//       .catch(error => {
//         reject(error);
//       });
//   });
// }
