document.getElementById("fetch_friends").addEventListener("click", () => {
  chrome.runtime.sendMessage({ action: "friendLists" });
});
const url = "https://fb-tool-node.devtrust.biz/graphql";
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.action === "storeFriendListData") {
    const receivedGroupData = message.data?.edges;
    createFriendsListItems(receivedGroupData);
  }
});

// async function createFriendsListItems(friends) {
//   if (!friends.length) {
//     toast(
//       "Are you sure you are logged with facebook/ no data found",
//       "error",
//       "red"
//     );
//   }

//   try {
//     const url = "https://fb-tool-node.devtrust.biz/graphql";
//     const adminFacebookId = localStorage.getItem("cUser");
//     const response = await fetch(url, { 
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json",
//       },
//       body: JSON.stringify({
//         query: `
//         query GetAllBlackListFriends($adminFacebookId: String) {
//           getAllBlackListFriends(adminFacebookId: $adminFacebookId) {
//             _id
//             blackListuserId
//             name
//             image
//             gender
//             isDeleted
//             adminFacebookId
//           }
//         }
//                   `,
//         variables: {
//           adminFacebookId,
//         },
//       }),
//     });

//     if (response.ok) {
//       const responseData = await response.json();
//       const resultData = responseData.data?.getAllBlackListFriends;
//       console.log("resout ", responseData)
//       const filteredFriends = friends.filter((friend) => {
//         return !resultData.some(
//           (dataItem) => dataItem?.blackListuserId === friend?.node.id
//         );
//       });
//       const table = document.getElementById("friendstBodyData");
//       table.innerHTML = "";
//       filteredFriends.forEach((group) => {
//         const { node } = group;
//         const listItem = document.createElement("tr");

//         listItem.innerHTML = `
//         <td>
//           <div class="image_td">
//             <img src="${node.profile_picture.uri}">
//             <label>${node.name}</label>
//           </div>
//         </td>
//         <td>${node.gender}</td>
//         <td>${node.id}</td>
//         <td>
//           <div class="form-check">
//             <input type="checkbox" class="group-checkbox" data-group-id="${node.id}" data-group-name="${node.name}" data-group-img="${node.profile_picture.uri}" data-group-gender="${node.gender}">
//           </div>
//         </td>
//       `;
//         table.appendChild(listItem);
//       });
//     } else {
//       throw new Error("Network response was not ok.");
//     }
//   } catch (error) {
//     console.error("Error:", error);
//   }
// }
async function createFriendsListItems(friends) {
  if (!friends.length) {
    toast(
      "Are you sure you are logged with facebook/ no data found",
      "error",
      "red"
    );
  }
  const blockApiCallResponse= await blockApiCall();
  try {
    const url = "https://fb-tool-node.devtrust.biz/graphql";
    const adminFacebookId = localStorage.getItem("cUser");
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        query: `
      query GetAllSafeListFriends($adminFacebookId: String) {
        getAllSafeListFriends(adminFacebookId: $adminFacebookId) {
          _id
          safeListuserId
          name
          image
          gender
          isDeleted
          adminFacebookId
        }
      }
                `,
        variables: {
          adminFacebookId,
        },
      }),
    });

    if (response.ok) {
      const responseData = await response.json();
      const resultData = responseData.data?.getAllSafeListFriends;
      // const filteredFriends = friends.filter((friend) => {
      //   return !resultData.some(
      //     (dataItem) => dataItem?.safeListuserId === friend?.node.id
      //   );
      // });

    // Extract blackListuserIds from blockApiCallResponse
    const blackListuserIds = blockApiCallResponse.map(
      (item) => item.blackListuserId
    );
    const safeListuserIds = resultData.map(
      (item) => item.safeListuserId
    );
    console.log(blackListuserIds,"blackListuserIds")

    // Filter out friends whose id matches any blackListuserId
    const filteredFriends = friends.filter((friend) => {
      return !(blackListuserIds.includes(friend?.node.id) || safeListuserIds.includes(friend?.node.id))
    })
    console.log(filteredFriends,"filteredFriends")

      const table = document.getElementById("friendstBodyData");
      table.innerHTML = "";
      filteredFriends.forEach((group) => {
        const { node } = group;
        const listItem = document.createElement("tr");

        listItem.innerHTML = `
      <td>
        <div class="image_td">
          <img src="${node.profile_picture.uri}">
          <label>${node.name}</label>
        </div>
      </td>
      <td>${node.gender}</td>
      <td>${node.id}</td>
      <td>
        <div class="form-check">
          <input type="checkbox" class="group-checkbox" data-group-id="${node.id}" data-group-name="${node.name}" data-group-img="${node.profile_picture.uri}" data-group-gender="${node.gender}">
        </div>
      </td>
    `;
        table.appendChild(listItem);
      });
    } else {
      throw new Error("Network response was not ok.");
    }
  } catch (error) {
    console.error("Error:", error);
  }
}
async function blockApiCall(){
  const url = "https://fb-tool-node.devtrust.biz/graphql";
  const adminFacebookId = localStorage.getItem("cUser");
  const response = await fetch(url, { 
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      query: `
      query GetAllBlackListFriends($adminFacebookId: String) {
        getAllBlackListFriends(adminFacebookId: $adminFacebookId) {
          _id
          blackListuserId
          name
          image
          gender
          isDeleted
          adminFacebookId
        }
      }
                `,
      variables: {
        adminFacebookId,
      },
    }),
  });

  if (response.ok) {
    const responseData = await response.json();
    const resultData = responseData.data?.getAllBlackListFriends;
  
    return resultData;
}
}
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.action === "storeFriendListData") {
    const receivedGroupData = message.data?.edges;
    createFriendsListItems(receivedGroupData);
  }
});

// block the permanent friends
// document
//   .getElementById("removeFriendsButton")
//   .addEventListener("click", function (e) {
//     const checkedBoxes = document.querySelectorAll(".group-checkbox:checked");
//     const selectedGroups = Array.from(checkedBoxes).map((checkbox) => {
//       return {
//         id: checkbox.getAttribute("data-group-id"),
//         name: checkbox.getAttribute("data-group-name"),
//       };
//     });
//     if (selectedGroups.length) {
//       chrome.runtime.sendMessage({
//         action: "blockTheFaceboookFriends",
//         data: selectedGroups,
//       });
//       window.location.reload();
//     } else {
//       alert("Please add the user");
//     }
//   });

document
  .getElementById("addToBlackList")
  .addEventListener("click", async function (e) {
    const checkedBoxes = document.querySelectorAll(".group-checkbox:checked");
    const selectedFriends = Array.from(checkedBoxes).map((checkbox) => {
      return {
        id: checkbox.getAttribute("data-group-id"),
        name: checkbox.getAttribute("data-group-name"),
        gender: checkbox.getAttribute("data-group-gender"),
        image: checkbox.getAttribute("data-group-img"),
        adminFacebookId: localStorage.getItem("cUser"),
      };
    });
    if (selectedFriends.length <= 0) {
      alert("Please add the user");
      return false;
    }
    const url = "https://fb-tool-node.devtrust.biz/graphql";
    const data = {
      input: selectedFriends,
    };
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          query: `
            mutation CreateBlockListFriends($input: [blacklistUserInput]) {
              createBlockListFriends(input: $input) {
                _id
                name
                image
                gender
                isDeleted
                adminFacebookId
                blackListuserId
              }
            }
                    `,
          variables: data,
        }),
      });

      if (response.ok) {
        const responseData = await response.json();
        const resultData = responseData.data;
        if (resultData?.createBlockListFriends?.length) {
          alert("Data added successfully");
          window.location.reload();
          return false;
        }
      } else {
        throw new Error("Network response was not ok.");
      }
    } catch (error) {
      console.error("Error:", error);
      // Handle errors here
    }
  });

window.onload = async function () {
  const url = "https://fb-tool-node.devtrust.biz/graphql";
  const adminFacebookId = localStorage.getItem("cUser");
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        query: `
          query GetAllBlackListFriends($adminFacebookId: String) {
            getAllBlackListFriends(adminFacebookId: $adminFacebookId) {
              _id
              blackListuserId
              name
              image
              gender
              isDeleted
              adminFacebookId
            }
          }
                  `,
        variables: {
          adminFacebookId,
        },
      }),
    });

    if (response.ok) {
      const responseData = await response.json();
      const resultData = responseData.data;
      if (resultData?.getAllBlackListFriends?.length) {
        BlackListItems(resultData.getAllBlackListFriends);
      }
    } else {
      throw new Error("Network response was not ok.");
    }
  } catch (error) {
    console.error("Error:", error);
  }
};

function BlackListItems(friends) {
  const table = document.getElementById("friendstBodyDataForBlackListUser");
  table.innerHTML = "";

  friends.forEach((friend) => {
    const listItem = document.createElement("tr");

    listItem.innerHTML = `
            <td>
              <div class="image_td">
                <img src="${friend.image}" >
                <label>${friend.name}</label>
              </div>
            </td>
            <td>${friend.gender ? friend.gender : "NA"}</td>
            <td>${friend.blackListuserId}</td>
              </div>
            </td>
          `;
    table.appendChild(listItem);
  });
}
