var timeRange = null;
var posts = [];
var allFriends = [];
var inactiveFriendsList = [];
var likers = [];
var selectedInactiveUsers = [];
var boxes = [];
var friendFromActivity = [];

$(document).ready(function () {
    // $("#select-time-to-fetch").css("display", "none");
    // $("#inactive-users").css("display", "block");
    // $("#selected_users").css("display", "block");

    allFriends = [];
    fetchAllFriends();

    const upperGrid = document.getElementById("upperGrid");
    const lowerGrid = document.getElementById("lowerGrid");

    $(".time-box").click(function () {
        $(".time-box").removeClass("time-box-active");
        $(this).addClass("time-box-active");

        timeRange = $(this).data('value');
        // console.log(timeRange);
        // $("#select-time-to-fetch").css("display", "none");
        // $("#inactive-users").css("display", "block");
        // $("#selected_users").css("display", "block");
    });

    $("#start-scan").click(function () {
        if (!timeRange) {
            toast("Please select a time range", "error", "red");
            return;
        }
        $("#loadingModal").modal("show");
        $("#loadingCount").text("Loading Posts...");
        fetchInactiveFriends(timeRange);
        // fetchUserPosts();
    })

    $("#remove-friend-popup").click(function () {
        if (selectedInactiveUsers.length < 1) {
            toast("Please Select Users To Remove", "error", "red");
            return;
        }
        $("#remove_friend_modal").modal();
    });

    $("#remove-selected").click(removeSelected);

    $("#select-all-btn").click(function () {
        // console.log("select-all-btn");
        selectedInactiveUsers = [...boxes, ...selectedInactiveUsers];
        boxes = [];
        createGridItems(upperGrid, boxes);
        createGridItems(lowerGrid, selectedInactiveUsers);
    });

    $("#de-select-all-btn").click(function () {
        // console.log("de-select-all-btn");
        boxes = [...boxes, ...selectedInactiveUsers];
        selectedInactiveUsers = [];
        createGridItems(upperGrid, boxes);
        createGridItems(lowerGrid, selectedInactiveUsers);
    });

    $(".sort-radio").click(sortAndRenderFriends);

    $("#searchByName").on("input", function () {
        const searchTerm = $(this).val().toLowerCase();
        const searchedFriends = boxes.filter(friend => friend.name.toLowerCase().includes(searchTerm));

        console.log("searchedFriends", searchedFriends);
        createGridItems(upperGrid, searchedFriends);
    });
});

const sortAndRenderFriends = async () => {
    try {
        let sortValue = $(".sort-radio:checked").val();
        // console.log("sort-radio", sortValue);

        if (sortValue === "oldToNew") {
            boxes.sort((a, b) => a.time - b.time);
        } else {
            boxes.sort((a, b) => b.time - a.time);
        }
        // console.log("sortedFriends", allFriends);
        createGridItems(upperGrid, boxes);
    } catch (error) {
        console.error("Error sorting and rendering friends:", error);
    }
};

const removeSelected = async () => {
    try {
        let notRemoved = [];
        if (selectedInactiveUsers.length < 1) {
            toast("Please Select Users To Remove", "error", "red");
            return;
        }

        let userCountToRemove = Number($("#amount-friends").val());
        let pauseTime = Number($("#pause-time").val());

        if (userCountToRemove < 1) {
            userCountToRemove = selectedInactiveUsers.length;
        }
        if (pauseTime < 1) {
            pauseTime = 0;
        }
        let pauseInterval = pauseTime * 60 * 1000;

        console.log("userCountToRemove", userCountToRemove, typeof userCountToRemove, "pause", pauseTime, typeof pauseTime);

        $("#loadingCount").text("0 out of 0 friends removed");
        $("#loadingModal").modal("show");

        const { c_user, fb_token } = await chrome.storage.local.get(["c_user", "fb_token"]);

        if (!c_user || !fb_token) {
            toast("Login to Facebook first", "error", "red");
            console.log("Required data not found in storage");
            return;
        }

        await sleep(1000);

        for (let index = 0; index < selectedInactiveUsers.length; index++) {
            const currentFriends = selectedInactiveUsers[index];

            const variables = `{"input":{"source":"bd_profile_button","unfriended_user_id":"${currentFriends.facebookId}","actor_id":"${c_user}","client_mutation_id":"2"},"scale":1}`;
            const requestData = prepareApiRequestData(8752443744796374, "FriendingCometUnfriendMutation", variables);

            $("#loadingCount").text(`${index + 1} out of ${selectedInactiveUsers.length} friends removed`);


            // Perform API request using requestData to remove user
            await sleep(2000);
            const data =await apiCall(requestData);
            console.log("----",data.data);
            if (data && data.data && data.data.friend_remove) {
                console.log(`${currentFriends.name}: removed.`);
                toast(`${currentFriends.name}: removed.`, "success", "green")
            } else {
                console.log(`${currentFriends.name}: failed to remove.`);
                toast(`${currentFriends.name}: failed to remove.`, "error", "red")
                notRemoved.push(currentFriends)
            }


            if ((selectedInactiveUsers.length > index + 1) && (index + 1) % userCountToRemove === 0) {
                let secondsLeft = pauseInterval / 1000; // Convert milliseconds to seconds
                let interval = setInterval(() => {
                    let minutes = Math.floor(secondsLeft / 60);
                    let seconds = secondsLeft % 60;

                    // Display the countdown
                    $("#countDown").text(`${minutes}:${seconds < 10 ? '0' : ''}${seconds}`);
                    secondsLeft--;
                    // Check if the countdown is complete
                    if (secondsLeft < 0) {
                        clearInterval(interval);
                        $("#countDown").text(""); // Clear the countdown display
                    }
                }, 1000);
                console.log("countDown start------")

                await sleep(pauseInterval + 1000);

                console.log("countDown end------")
                clearInterval(interval);
            }
        }

        console.log("removing selected", selectedInactiveUsers);
        selectedInactiveUsers = [...notRemoved];

        createGridItems(lowerGrid, selectedInactiveUsers);
        $("#loadingModal").modal("hide");
    } catch (error) {
        console.error("Error removing selected users:", error);
        // Handle the error, e.g., show an error toast
    }
};

function removeFriendsThroughGraphQL(friendsList) {
    chrome.storage.local.get(["c_user", "fb_token"], function (result) {
        let cUser = result.c_user;
        let fbToken = result.fb_token;

        if (!cUser || !fbToken) {
            console.log("Required data not found in storage");
            return;
        }
        let currentFriends = friendsList.shift();
        if (!currentFriends) {
            console.log("Finished, all friends processed.");
            return;
        }

        let variables = `{"input":{"source":"bd_profile_button","unfriended_user_id":"${currentFriends.id}","actor_id":"${cUser}","client_mutation_id":"2"},"scale":1}`;
        let requestData = prepareApiRequestData(
            8752443744796374,
            "FriendingCometUnfriendMutation",
            variables
        );

        //   apiCall(requestData, function (data) {
        //     getFriendsThroughGraphQL();
        //     if (data && data.data && data.data.friend_remove) {
        //       console.log(`${currentFriends.name}: removed.`);
        //       removeFriendsThroughGraphQL(friendsList);
        //     } else {
        //       console.log(`${currentFriends.name}: failed to remove.`);
        //       removeFriendsThroughGraphQL(friendsList);
        //     }
        //   });
    });
}

const fetchAllFriends = async (cursor = null) => {
    $("#loadingModal").modal("show");
    $("#loadingCount").text("Fetching all Users...");

    cursor = cursor ? `"${cursor}"` : null;
    const queryName = "FriendingCometFriendsListPaginationQuery";
    const variables = `{"count":30,"cursor":${cursor},"name":null,"scale":1}`;

    let requestData = prepareApiRequestData(
        4268740419836267,
        queryName,
        variables
    );

    try {
        const data = await apiCall(requestData);
        if (data && data.data && data.data.viewer && data.data.viewer.all_friends) {
            let friendsData = data.data.viewer.all_friends;

            console.log(friendsData);
            const mappedArrayAllFriends = await friendsData.edges.map(obj => ({
                name: obj.node.name,
                facebookId: obj.node.id,
                profileImage: obj.node.profile_picture.uri,
            }));
            allFriends.push(...mappedArrayAllFriends);
            if (friendsData.page_info.has_next_page) {
                await sleep(getRandomInt(1500, 3000));
                await fetchAllFriends(friendsData.page_info.end_cursor);
            } else {
                // allFriends.push(...friendsData.edges);

                friendFromActivity = [];
                await fetchFromActivity();

                $("#loadingModal").modal("hide");
                console.log("All Friends", allFriends);
            }
        } else {
            console.log("Error fetching friends data");
        }
    } catch (error) {
        console.error("An error occurred during fetchAllFriends:", error.message);
    }
};

const filterInactiveFriends = async (allFriends, likers) => {
    inactiveFriendsList = allFriends.filter(friendsData => (
        !likers.some(liker => liker.facebookId === friendsData.facebookId)
    ));
    // console.log("filteredFriends", inactiveFriendsList);
}

const fetchInactiveFriends = async (days) => {
    posts = [];
    likers = [];
    // console.log("Fetching",days);
    await fetchUserPosts();
    if (!posts.length){
        $("#loadingModal").modal("hide");
        toast("No posts in this timeline", "success", "green");
        return;
    }
    await sleep(500);
    await usersFromPosts();

    // console.log("Fetching posts", posts);
    // console.log("Fetching likers", likers);

    $("#loadingCount").text(`Analysing Inactive Friends`);
    // await sleep(6000);
    console.log("Fetched-----", likers);
    await sleep(1000);
    await filterInactiveFriends(allFriends, likers);
    await sleep(1000);
    manageList();
    $("#loadingModal").modal("hide");

    if (inactiveFriendsList.length > 0) {
        $("#select-time-to-fetch").css("display", "none");
        $("#inactive-users").css("display", "block");
        $("#selected_users").css("display", "block");
    }
    else {
        toast('No Inactive Users', "success", "green");
    }
};

// Function to create grid items
function createGridItems(container, data) {
    container.innerHTML = ""; // Clear existing content

    data.forEach((box) => {
        // Create HTML string for each grid item
        const gridItemHTML = `
    <div class="user-grid-item">
        <div class="image">
        <image src="${box.profileImage}"/>
        </div>
        <div class="user-info">
            <div class="name">${box.name}</div>
            <div class="facebookId">${box.facebookId}</div>
        </div>
    </div>
  `;

        // Append HTML string to container
        container.innerHTML += gridItemHTML;
    });
}

function manageList() {
    boxes = [...inactiveFriendsList]

    // Add click event listener to both upper and lower grids
    upperGrid.addEventListener("click", handleGridItemClick);
    lowerGrid.addEventListener("click", handleGridItemClick);

    // Function to handle grid item click
    function handleGridItemClick(event) {
        const target = event.target;
        const gridItem = target.closest(".user-grid-item");

        if (gridItem) {
            const boxFacebookId =
                gridItem.querySelector(".facebookId")?.textContent;

            if (boxFacebookId) {
                const selectedBoxIndex = boxes.findIndex(
                    (box) => box.facebookId === boxFacebookId
                );
                const selectedInactiveBoxIndex = selectedInactiveUsers.findIndex(
                    (box) => box.facebookId === boxFacebookId
                );

                if (selectedBoxIndex !== -1) {
                    const selectedBox = boxes[selectedBoxIndex];
                    selectedInactiveUsers.push(selectedBox);
                    boxes.splice(selectedBoxIndex, 1); // Remove from the array
                } else if (selectedInactiveBoxIndex !== -1) {
                    const selectedBox = selectedInactiveUsers[selectedInactiveBoxIndex];
                    boxes.push(selectedBox);
                    selectedInactiveUsers.splice(selectedInactiveBoxIndex, 1); // Remove from the array
                }

                createGridItems(upperGrid, boxes);
                createGridItems(lowerGrid, selectedInactiveUsers);
            }
        }
    }

    // Initial rendering
    createGridItems(upperGrid, boxes);
    createGridItems(lowerGrid, selectedInactiveUsers);

};

const usersFromPosts = async () => {
    let postCount = 1;
    for (const post of posts) {
        $("#loadingCount").text(`${postCount} Post Scanning`);
        postCount++;
        await fetchLikers(null, post);
        await sleep(1000);
        await fetchCommenters(null, post);
        await sleep(3000);
    }

};

const fetchCommenters = async (cursor = null, post) => {
    cursor = cursor ? `"${cursor}"` : null;
    const queryName = "CometUFIReactionsDialogQuery";
    const variables = `{"commentsAfterCount":-1,"commentsAfterCursor":${cursor},"commentsBeforeCount":null,"commentsBeforeCursor":null,"commentsIntentToken":null,"feedLocation":"DEDICATED_COMMENTING_SURFACE","focusCommentID":null,"scale":1,"useDefaultActor":false,"id":"${post.feedback_target_id}"}`;

    let requestData = prepareApiRequestData(
        `7114405888582562`,
        queryName,
        variables
    );

    try {
        const data = await apiCall(requestData);
        if (data && data.data && data.data.node && data.data.node.comment_rendering_instance_for_feed_location) {
            let postData = data.data.node.comment_rendering_instance_for_feed_location.comments;
            console.log("------------------comments----", postData);

            const mappedArrayCommenters = await postData.edges.map(obj => ({
                name: obj.node.user.name,
                facebookId: obj.node.user.id,
                profileImage: obj.node.user.profile_picture.uri,
            }));

            await mappedArrayCommenters.forEach((commenter) => {
                const existingLiker = likers.find((existing) => existing.facebookId === commenter.facebookId);

                if (!existingLiker) {
                    likers.push(commenter);
                }
            });

            if (postData.page_info.has_next_page) {
                console.log("-----------------again---------------");
                await sleep(getRandomInt(1500, 3000));
                await fetchCommenters(postData.page_info.end_cursor, post);
            } else {
                console.log("users array", postData);
            }
        } else {
            console.log("Error fetching friends data");
        }
    } catch (error) {
        console.error("An error occurred during fetchCommenters:", error.message);
    }
};

const fetchLikers = async (cursor = null, post) => {
    cursor = cursor ? `"${cursor}"` : null;
    const queryName = "CometUFIReactionsDialogQuery";
    const variables = `{"feedbackTargetID":"${post.feedback_target_id}","cursor":${cursor},"scale":1}`;

    let requestData = prepareApiRequestData(
        `6099931570107234`,
        queryName,
        variables
    );

    try {
        const data = await apiCall(requestData);
        console.log(data.data.node.reactors);
        if (data && data.data && data.data.node && data.data.node.reactors) {
            let postData = data.data.node.reactors;
            console.log("------------------", postData);

            const mappedArrayLikers = postData.edges.map(obj => ({
                name: obj.node.name,
                facebookId: obj.node.id,
                profileImage: obj.node.profile_picture.uri,
            }));

            await mappedArrayLikers.forEach((liker) => {
                const existingLiker = likers.find((existing) => existing.facebookId === liker.facebookId);

                if (!existingLiker) {
                    likers.push(liker);
                }
            });

            if (postData.page_info.has_next_page) {
                await sleep(getRandomInt(1500, 3000));
                await fetchLikers(postData.page_info.end_cursor, post);
            } else {
                console.log("Likers", likers);
            }
        } else {
            console.log("Error fetching like data");
        }
    } catch (error) {
        console.error("An error occurred during fetchLikers:", error.message);
    }
};

const fetchUserPosts = async (cursor = null) => {
    cursor = cursor ? `"${cursor}"` : null;
    const queryName = "CometActivityLogBulkActionMutation";
    const variables = `{"category":"MANAGEPOSTSPHOTOSANDVIDEOS","category_key":"MANAGEPOSTSPHOTOSANDVIDEOS","count":25,"cursor":null,"id":"100001353248830"}`;

    let requestData = prepareApiRequestData(
        `2761528123917382`,
        queryName,
        variables
    );

    try {
        const data = await apiCall(requestData);
        if (data && data.data && data.data.viewer.activity_log_actor && data.data.viewer.activity_log_actor.activity_log_stories) {
            let postData = data.data.viewer.activity_log_actor.activity_log_stories;
            console.log("------------------", postData);

            const dayAgo = timeRange || 7;
            console.log("------------------", dayAgo);
            const currentDate = new Date();
            const thirtyDaysAgo = new Date(currentDate.getTime() - dayAgo * 24 * 60 * 60 * 1000);
            const timeInterval = Math.floor(thirtyDaysAgo.getTime() / 1000);

            const recentAddedFriends = postData.edges.filter(obj =>
                obj.node.creation_time >= timeInterval
            );

            const mappedArrayRecentAdded = recentAddedFriends.map(obj => ({
                time: obj.node.creation_time,
                postId: decodeAndExtractLastValue(obj.node.id),
                feedback_target_id: obj.node.feedback_context.feedback_target.id
            }));

            posts.push(...mappedArrayRecentAdded);

            if (postData.page_info.has_next_page) {
                setTimeout(function () {
                    fetchUserPosts(postData.page_info.end_cursor);
                }, getRandomInt(1500, 3000));
            } else {
                console.log("posts", posts);

            }
        } else {
            console.log("Error fetching friends data");
        }
    } catch (error) {
        console.error("An error occurred during fetchUserPosts:", error.message);
    }
};

async function apiCall(requestData) {
    try {
        const { c_user, fb_token } = await chrome.storage.local.get(["c_user", "fb_token"]);
        if (!c_user || !fb_token) {
            throw new Error("Required data not found in storage");
        }

        const formData = new FormData();
        formData.append("__user", c_user);
        formData.append("__a", 1);
        formData.append("dpr", 1);
        formData.append("fb_dtsg", fb_token);
        formData.append("fb_api_caller_class", "RelayModern");
        formData.append("fb_api_req_friendly_name", requestData.queryName);
        formData.append("doc_id", requestData.docId);
        formData.append("variables", requestData.variables);

        const response = await fetch("https://www.facebook.com/api/graphql/", {
            method: "POST",
            body: formData,
        });

        const data = await response.json();
        console.log(data, "data of fetch friends");
        return data;
    } catch (error) {
        console.error("An error occurred during API call:", error.message);
        throw error; // Rethrow the error for further handling if necessary
    }
}

function decodeAndExtractLastValue(encodedString) {
    var decodedString = atob(encodedString);
    var parts = decodedString.split(':');
    var lastValue = parts[parts.length - 1];

    return lastValue;
}

function prepareApiRequestData(docId, queryName, variables) {
    return {
        docId: docId,
        queryName: queryName,
        variables: variables,
    };
}

function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function sleep(t) {
    return new Promise((e) => setTimeout(e, t));
}

function toast(heading, icon, color) {
    $.toast({
        text: "",
        heading: heading,
        icon: icon,
        showHideTransition: "fade",
        allowToastClose: true,
        hideAfter: 3000,
        stack: 5,
        position: "top-right",

        textAlign: "left",
        loader: true,
        loaderBg: color,
        beforeShow: function () { },
        afterShown: function () { },
        beforeHide: function () { },
        afterHidden: function () { },
    });
}

async function fetchFromActivity(cursor = null) {
    cursor = cursor ? `"${cursor}"` : null;
    const queryName = "CometActivityLogMainContentRootQuery";
    const variables = `{"activity_history":false,"audience":null,"ayi_taxonomy":true,"category":"FRIENDS","category_key":"FRIENDS","count":25,"cursor":${cursor},"entry_point":null,"media_content_filters":[],"month":null,"person_id":null,"privacy":"NONE","scale":1,"timeline_visibility":"ALL","year":null}`;

    const requestData = prepareApiRequestData(6584764774955004, queryName, variables);
    const data = await apiCall(requestData);

    if (data?.data?.viewer?.activity_log_actor?.activity_log_stories) {
        const friendsData = data.data.viewer.activity_log_actor.activity_log_stories;

        const recentAddedFriends = friendsData.edges.filter(obj =>
            obj.node.summary.text.includes("became friends with")
        );

        const mappedArrayRecentAdded = recentAddedFriends.map(obj => ({
            time: obj.node.creation_time,
            facebookId: obj.node.post_id,
            name: obj.node.attachments[0]?.title_with_entities.text
        }));

        friendFromActivity.push(...mappedArrayRecentAdded);

        if (friendsData.page_info.has_next_page) {
            setTimeout(() => fetchFromActivity(friendsData.page_info.end_cursor), getRandomInt(1500, 3000));
        } else {
            console.log("All friends fetched from activity");

            allFriends = await updateFriendsWithTime(allFriends, friendFromActivity);
            // console.log("friends", allFriends , "friendsfrom activity", friendFromActivity);
        }
    } else {
        console.log("Error fetching friends data");
    }
}

function updateFriendsWithTime(friends, friendWithTime) {
    return friends.map(friend => {
        const matchingFriend = friendWithTime.find(fwt => fwt.facebookId === friend.facebookId);
        if (matchingFriend) {
            return { ...friend, time: matchingFriend.time };
        }
        return friend;
    });
}

