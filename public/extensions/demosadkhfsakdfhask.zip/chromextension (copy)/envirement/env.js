const GRAPHQL_BASE_URL = "https://fb-tool-node.devtrust.biz/graphql"
 export { GRAPHQL_BASE_URL};