chrome.tabs.create({
    url: `chrome-extension://${chrome.runtime.id}/html/index.html`,
  });