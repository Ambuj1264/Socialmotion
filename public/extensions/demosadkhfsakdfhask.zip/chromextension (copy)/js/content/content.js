let timer;
let isStop = false;

let message = {
  authMsg: "This extension to continuously working .",
  finished: "Finished",
  stopped: "Stopped",
  spam: '"Stopped Friends Adding" Facebook has detected your activity as spam, You can try again later',
  noFriends: "No Requests/Friends",
};

if (window.location.href.includes("type=sentreq")) {
  let i = 0;
  const timer = setInterval(() => {
    const cancelFriendBtn = document.querySelector(
      'div[class="xod5an3 xktsk01 x1d52u69 x14vqqas"]'
    )?.children[0];
    if (cancelFriendBtn) {
      cancelFriendBtn.click();
      clearInterval(timer);
    }
    if (i == 10) {
      cancelFriendBtn.click();
    }
    i++;
  }, 1000);
}
var requestCancationalData;
chrome.runtime.onMessage.addListener(function (req, res, sendResponse) {
  chrome.storage.local.get(null, async (storeRes) => {
    console.log(storeRes, "storeREsss--------------")
    const apiRes = await chrome.runtime.sendMessage({ type: "a" });
    if (apiRes.status) {
      if (req.event == "delete") {
        // confirmFriends(req?.data, req.event);
        insertControlsHtmlForDelete();
        $(".cf_stop_btn_ForDelete").hide();
        $(".cf_start_btn_ForDelete").on("click", function () {
          startProcess_ForDelete(req?.data);
        });
        $(".cf_stop_btn_ForDelete").on("click", function () {
          stopProcess_ForDelete();
        });
        $(".cf_cancel_btn_ForDelete").on("click", function () {
          stopProcess_ForDelete();
        });
        $(".close-icon_ForDelete").on("click", function () {
          closeControlsPopup_ForDelete();
        });
      } else if (req.event == "cancel") {
        requestCancationalData = req.data;
        // cancelSentRequest(storeRes, req.event);
        insertControlsHtml();
        $(".cf_stop_btn").hide();
        $(".cf_start_btn").on("click", function () {
          startProcess();
        });
        $(".cf_stop_btn").on("click", function () {
          stopProcess();
        });
        $(".cf_cancel_btn").on("click", function () {
          stopProcess();
        });
        $(".close-icon").on("click", function () {
          closeControlsPopup();
        });
      }
      else if (req.event === "scrapeFriendRequestData") {
        const friendRequestCount=document.querySelector('div[id="friends_center_main"] ._8zhy')?.innerText
        console.log("friendRequestCount",friendRequestCount)
        // Send the scraped data back to the background script
        chrome.runtime.sendMessage({ event: "friendRequestData", data: { friendRequestCount } });
      }
    }

    if (req.event == "stop") {
      isStop = true;
    }
  });
  sendResponse(null);
});




// delete request start

var cancellationCount_ForDelete = 0
function insertControlsHtmlForDelete() {
  let cont_html = `    <style>

  .close-icon_ForDelete {
    position: absolute;
    top: 10px;
    right: 10px;
    font-size: 20px;
    cursor: pointer;
    color: #333; /* Change to your desired color */
  }
  #cf_controls_ForDelete{
    position: fixed;
    top: 50px;
    right: 100px;
    background: #eee;
    border-radius: 5px;
    box-shadow: 1px 2px 10px rgba(0,0,0,1);
    width: 500px;
    z-index: 999;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding-bottom: 15px;
}
.cf_text_ForDelete{
    background-color: #1877f2;
      color: white;
      width:100%;
      padding: 18px 20px;
      border: none;
      border-radius: 5px;
      font-family: 'Arial', sans-serif;
      font-size: 16px;
      font-weight: bold;
      text-transform: uppercase;
      cursor: pointer;
      transition: background-color 0.3s;
}
.cf_progressInfo_ForDelete{
    font-size: medium;
    margin-bottom: 10px;
    color: green;
}
.btn-outline-primary {
  background-color: #3498db; /* Change to your primary color */
  color: #fff; /* Text color */
  padding: 10px 20px; /* Adjust padding as needed */
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 10px; /* Adjust font size as needed */
}



/* Danger Button */
.btn-outline-danger {
  background-color: #e74c3c; /* Change to your danger color */
  color: #fff; /* Text color */
  padding: 10px 20px; /* Adjust padding as needed */
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 10px; /* Adjust font size as needed */
}  
.cf_start_btn_ForDelete:disabled,
.cf_start_btn_ForDelete:hover {
 background-color: grey !important;
 color: white !important;

}
   
</style>
 <div id="cf_controls">
    <div class="header">
        <h3>fb-tool Controls</h3>
        // <span class="close-icon" onclick="closeControlsPopup()">&#10006;</span> <!-- Cross icon -->
        <hr>
    </div>
    <div class="body">
        <div class="buttons">
            <button class="btn btn-outline-primary cf_btn_ForDelete cf_start_btn_ForDelete">Start</button>
            <button class="btn btn-outline-primary cf_btn_ForDelete cf_stop_btn_ForDelete" style="display: none">Stop</button>
            <button class="btn btn-outline-danger cf_btn_ForDelete cf_cancel_btn_ForDelete">Cancel</button>
        </div>
        <div><p class="status_string_ForDelete"></p></div>
    </div>
</div>

<div class="cf_overlay_ForDelete"></div>
<div id="cf_controls_ForDelete" class="cf_progressBar_ForDelete">
<span class="close-icon_ForDelete" >&#10006;</span> <!-- Cross icon -->
<div class="cf_finished_ForDelete">

</div> 
<div class="cf_text_ForDelete">Ready to start? Click the "Start" button.</div>
<div class="cf_progressInfo_ForDelete">
  <span class="cf_done_ForDelete status_string_ForDelete"></span> 
</div> 
<div class="cf_btn_container_ForDelete">
<button class="btn btn-outline-primary cf_btn_ForDelete cf_start_btn_ForDelete">Start</button>
<button class="btn btn-outline-danger cf_btn_ForDelete cf_cancel_btn_ForDelete">Stop</button>
</div>
</div>`;

  $(document.body).append(cont_html);
}
function closeControlsPopup_ForDelete() {
  $("#cf_controls_ForDelete").remove();
  $(".cf_overlay_ForDelete").remove();
}
function updateStatusString_ForDelete(cancellationCount_ForDelete) {
  let status_string = "";
  let main_text = "";
  main_text = "Total Number Of count: " + cancellationCount_ForDelete;
  $("#cf_controls_ForDelete .status_string_ForDelete").text(status_string);
  $(".cf_text_ForDelete").text(main_text);
}

async function startProcess_ForDelete(parameter) {
  $(".cf_start_btn_ForDelete")
    .prop("disabled", true)
    .text("Started...")
    .css({
      color: "white",
      "background-color": "grey",
    })
    .show();
  $(".status_string_ForDelete").text("Waiting to begin...");
  $(".cf_stop_btn_ForDelete").show();

  active_status = true;
  await sleep(minDelayOnPost * 1000);
  chrome.storage.local.get(null, async (storeRes) => {
    console.log(storeRes);
    const apiRes = await chrome.runtime.sendMessage({ type: "a" });
    if (apiRes.status) {
      confirmFriends(parameter, "delete");
    }
  });
}
function stopProcess_ForDelete() {
  $(".cf_start_btn_ForDelete")
    .prop("disabled", true)
    .text("Start")
    .css({
      color: "white",
      "background-color": "grey",
    })
    .show();
  $(".status_string_ForDelete").text("");
  active_status = false;
  confirmFriends({}, "stop");
}

function cancelProcess_ForDelete() {
  stopProcess_ForDelete();
  $(".cf_overlay_ForDelete").remove();
  $("#cf_controls_ForDelete").remove();
}

// delete request end


function displayMsg(msg, status) {
  let status_string = "";
  let main_text = "";
  main_text = "Total Number Of count: " + cancellationCount_ForDelete + " Finished";
  $("#cf_controls_ForDelete .status_string_ForDelete").text(status_string);
  $(".cf_text_ForDelete").text(main_text);
  $(".cf_start_btn_ForDelete")
    .prop("disabled", true)
    .text("Start")
    .css({
      color: "white",
      "background-color": "grey",
    })
    .show();
}

function perDelay(min, max) {
  min = parseInt(min);
  max = parseInt(max);
  return new Promise((resolve, rej) => {
    // var delay = Math.floor(Math.random() * (max - min + 1)) + min;
    var delay = 2;
    setTimeout(() => {
      resolve(true);
    }, delay * 1000);
  });
}
function perDelayForOther(min, max) {
  min = parseInt(min);
  max = parseInt(max);
  return new Promise((resolve, rej) => {
    // var delay = Math.floor(Math.random() * (max - min + 1)) + min;
    var delay = 5;
    setTimeout(() => {
      resolve(true);
    }, delay * 1000);
  });
}

function beetBetweenDelay(delay) {
  return new Promise((resolve, rej) => {
    setTimeout(() => {
      resolve(true);
    }, delay * 1000);
  });
}

function isStopTask() {
  return new Promise((resolve, rej) => {
    if (isStop) {
      resolve(true);
    } else {
      resolve(false);
    }
  });
}

async function auth() {
  const apiRes = await chrome.runtime.sendMessage({ type: "a" });
  return new Promise((resolve, rej) => {
    if (!apiRes.status) {
      Swal.fire({
        icon: "warning",
        text: message.authMsg,
        showCancelButton: true,
        confirmButtonText: "Yes, Continue!",
        cancelButtonText: "No, cancel!",
      }).then((result) => {
        if (result.isConfirmed) {
          console.log("confirmed result");
        } else {
          rej();
        }
      });
    } else {
      resolve(true);
    }
  });
}

function findElement(selector, parent) {
  return new Promise((resolve, reject) => {
    let i = 0;
    let findEleTimer = setInterval(() => {
      const element = parent
        ? parent.querySelector(selector)
        : document.querySelector(selector);
      if (element) {
        clearInterval(findEleTimer);
        resolve(element);
      }
      if (i == 10) {
        clearInterval(findEleTimer);
        reject();
      }
      i++;
    }, 1000);
  });
}

function finishedTask(totalFriends, i) {
  return new Promise((resolve, reject) => {
    if (totalFriends == i + 1) {
      displayMsg(message.finished, "success");
      resolve(true);
    } else {
      resolve(false);
    }
  });
}

async function addFriends(savedData) {
  var totalFriends = parseInt(savedData.friends);
  var count = parseInt(savedData.betweenFriends);
  var mainDiv = document.querySelector(
    'div[class="x9f619 x1n2onr6 x78zum5 xdt5ytf x193iq5w xeuugli x2lah0s x1t2pt76 x1xzczws x1cvmir6 x1vjfegm"]'
  );

  for (let i = 0; i < totalFriends; i++) {
    if (await isStopTask()) {
      displayMsg(message.stopped, "success");
      break;
    }

    try {
      await auth();
    } catch (e) {
      break;
    }

    const doesThisPersonKnowYouDialogBox = document.querySelector(
      'div[class="x1n2onr6 x1ja2u2z x1afcbsf x78zum5 xdt5ytf x1a2a7pz x6ikm8r x10wlt62 x71s49j x1jx94hy x1qpq9i9 xdney7k xu5ydu1 xt3gfkd x104qc98 x1g2kw80 x16n5opg xl7ujzl xhkep3z x1n7qst7 xh8yej3"]'
    );
    if (doesThisPersonKnowYouDialogBox) {
      const cancelBtn = doesThisPersonKnowYouDialogBox.querySelector(
        'div[aria-label="Cancel" i]'
      );
      cancelBtn.click();
    }
    const isSpam = document.getElementsByClassName(
      "x1n2onr6 x1ja2u2z x1afcbsf xdt5ytf x1a2a7pz x71s49j x1qjc9v5 x1qpq9i9 xdney7k xu5ydu1 xt3gfkd x78zum5 x1plvlek xryxfnj xcatxm7 x1n7qst7 xh8yej3"
    )[0];
    if (isSpam) {
      displayMsg(message.spam, "warning");
      break;
    }

    const parentDiv = mainDiv.querySelector(
      'div[data-visualcompletion="ignore-dynamic" i]'
    );
    const actionBtn = parentDiv.querySelector(
      'div[class="x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x1ypdohk xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1o1ewxj x3x9cwd x1e5q0jg x13rtm0m x87ps6o x1lku1pv x1a2a7pz x9f619 x3nfvp2 xdt5ytf xl56j7k x1n2onr6 xh8yej3"]'
    );
    if (!actionBtn) {
      displayMsg(message.noFriends, "warning");
      break;
    }
    actionBtn.click();

    setTimeout(() => {
      parentDiv.remove();
    }, 1000);

    await perDelay(savedData.minDelay, savedData.maxDelay);

    if (await finishedTask(totalFriends, i)) break;
    if (count == i + 1 && savedData.isOnbetweenFriends) {
      count += count;
      await beetBetweenDelay(parseInt(savedData.betweenDelay));
    }
  }
}

let stopFlag = false; // Flag to control the loop

async function isStopTask() {
  return stopFlag;
}

function stopTask() {
  stopFlag = true;
}

async function confirmFriends(savedData, event) {
  var totalFriends = parseInt(savedData.friends);
  var workType = parseInt(savedData?.workType);
  var count = parseInt(savedData.betweenFriends);
  var mainDiv = document.querySelector(
    'div[class="x2bj2ny x1afcbsf x78zum5 xdt5ytf x1t2pt76 x1n2onr6 x1cvmir6 xcoz2nd xxzkxad xh78kpn xojf56a x1r98mxo"]'
  );
  var forDeleteStatus = "start";

  if (event == "stop") {
    forDeleteStatus = "stop";
    stopTask();
    return;
  }
  if (workType == 1) {
    totalFriends = 1000;
  }
  else if (workType == 2) {
    totalFriends = 1000;
    skipMutualFriends()
  }
  for (let i = 0; i < totalFriends; i++) {
    if (await isStopTask()) {
      displayMsg(message.stopped, "success");
      break;
    }

    if (forDeleteStatus == "stop") {
      break;
    }

    try {
      await auth();
    } catch (e) {
      break;
    }

    const parentDiv = mainDiv?.querySelector(
      'div[data-visualcompletion="ignore-dynamic" i]'
    );

    var actionBtn;
    if (event == "confirm") {
      actionBtn = parentDiv?.querySelector('div[aria-label="Confirm" i]');
    } else if (event == "delete") {
      actionBtn = parentDiv?.querySelector(
        'div[aria-label="Delete" i]:not([aria-disabled="true"])'
      );
    }

    if (!actionBtn) {
      displayMsg(message.noFriends, "warning");
      break;
    }

    actionBtn.click();
    cancellationCount_ForDelete++;
    updateStatusString_ForDelete(cancellationCount_ForDelete);

    setTimeout(() => {
      parentDiv.remove();
    }, 1000);

    await perDelay(savedData.minDelay, savedData.maxDelay);

    if (await finishedTask(totalFriends, i)) break;

    if (count == i + 1 && savedData.isOnbetweenFriends) {
      count += count;
      await beetBetweenDelay(parseInt(savedData.betweenDelay));
    }
  }
  async function skipMutualFriends() {
    for (let i = 0; i < totalFriends; i++) {
      if (await isStopTask()) {
        displayMsg(message.stopped, "success");
        break;
      }
      if (forDeleteStatus == "stop") {
        break;
      }
      // try {
      //   await auth();
      // } catch (e) {
      //   break;
      // }
      // const parentDiv = mainDiv.querySelector(
      //   'div[data-visualcompletion="ignore-dynamic" i]:not(.gone-through)'
      // );
      // parentDiv.classList.add('gone-through');
      // var actionBtn;
      if (event == "confirm") {
        // actionBtn = parentDiv.querySelector('div[aria-label="Confirm" i]');
      } else if (event == "delete") {
        const findTheRightKey = document.querySelector(`div[data-store-id='${i}'] ._6vpk`)?.innerText;
        // Check if mutualFriends has a value, then skip the current iteration
        console.log(findTheRightKey,"findtherightkey")
       var superparent =document.querySelector(`div[data-store-id='${10+i}']`);
        if (findTheRightKey?.length) {
          console.log("Mutual friend found. Skipping current iteration.");
          window.scrollTo({
            top: window.scrollY + 200,
            behavior: "smooth",
          });
          continue;
        } else {
          
          const parentDivs = document.querySelector(`div[data-store-id='${i}'] button[value="Delete"]`);
          console.log(parentDivs, "parentDiv");
          setTimeout(() => {
            parentDivs?.click();
          }, 3000);
        
          parentDivs?.addEventListener('click', function () {
            // Increment cancellationCount_ForDelete
            cancellationCount_ForDelete++;
            
            // Update status string
            updateStatusString_ForDelete(cancellationCount_ForDelete);
          });
           
            
            // Scroll after clicking
          //   if (superparent) {
          //     // superparent.scrollIntoView({ behavior: 'smooth', block: 'center' });
          //     window.scrollTo({
          //               top: window.scrollY + 200,
          //               behavior: "smooth",
          //             });
          // }
          
          
          // }
          // )
          
        }
      }

      // setTimeout(() => {
      //   console.log(cancellationCount_ForDelete,"cancellationCount_ForDelete")
      // }, 1000);

      // await perDelay(savedData.minDelay, savedData.maxDelay);

      // if (await finishedTask(totalFriends, i)) break;

      // if (count == i + 1 && savedData.isOnbetweenFriends) {
      //   count += count;
      //   await beetBetweenDelay(parseInt(savedData.betweenDelay));
      // }
    }
  }


}


// async function confirmFriends(savedData, event) {
//   var totalFriends = parseInt(savedData.friends);
//   var count = parseInt(savedData.betweenFriends);
//   var mainDiv = document.querySelector(
//     'div[class="x2bj2ny x1afcbsf x78zum5 xdt5ytf x1t2pt76 x1n2onr6 x1cvmir6 xcoz2nd xxzkxad xh78kpn xojf56a x1r98mxo"]'
//   );
//   var forDeleteStatus ="start";
//   if(event == "stop"){
//      forDeleteStatus ="stop";
//     isStopTask();
//     return
//    }
//   for (let i = 0; i < totalFriends; i++) {

//     if (await isStopTask()) {
//       displayMsg(message.stopped, "success");
//       break;
//     }
//     if(forDeleteStatus=="stop"){
//       break;
//     }
//     try {
//       await auth();
//     } catch (e) {
//       break;
//     }

//     const parentDiv = mainDiv.querySelector(
//       'div[data-visualcompletion="ignore-dynamic" i]'
//     );

//     var actionBtn;
//     if (event == "confirm") {
//       actionBtn = parentDiv.querySelector('div[aria-label="Confirm" i]');
//     } else if (event == "delete") {
//       actionBtn = parentDiv.querySelector(
//         'div[aria-label="Delete" i]:not([aria-disabled="true"])'
//       );
//     }

//     if (!actionBtn) {
//       displayMsg(message.noFriends, "warning");
//       break;
//     }

//     actionBtn.click();
//       cancellationCount_ForDelete++
//       updateStatusString_ForDelete(cancellationCount_ForDelete)
//     // actionBtn.childNodes[0].style.backgroundColor = "red"

//     setTimeout(() => {
//       parentDiv.remove();
//     }, 1000);

//     await perDelay(savedData.minDelay, savedData.maxDelay);

//     if (await finishedTask(totalFriends, i)) break;

//     if (count == i + 1 && savedData.isOnbetweenFriends) {
//       count += count;
//       await beetBetweenDelay(parseInt(savedData.betweenDelay));
//     }
//   }
// }

// start
var active_status = false;
var scheduled_start = null;
let numberOfPostId = 10;
let minDelayOnPost = 5;
var countCompleted = 0;
let messageEnabled = false;
var cancellationCount=0;
function insertControlsHtml() {
  let cont_html = `    <style>

  .close-icon {
    position: absolute;
    top: 10px;
    right: 10px;
    font-size: 20px;
    cursor: pointer;
    color: #333; /* Change to your desired color */
  }
  #cf_controls{
    position: fixed;
    top: 50px;
    right: 100px;
    background: #eee;
    border-radius: 5px;
    box-shadow: 1px 2px 10px rgba(0,0,0,1);
    width: 500px;
    z-index: 999;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding-bottom: 15px;
}
.cf_text{
    background-color: #1877f2;
      color: white;
      width:100%;
      padding: 18px 20px;
      border: none;
      border-radius: 5px;
      font-family: 'Arial', sans-serif;
      font-size: 16px;
      font-weight: bold;
      text-transform: uppercase;
      cursor: pointer;
      transition: background-color 0.3s;
}
.cf_progressInfo{
    font-size: medium;
    margin-bottom: 10px;
    color: green;
}
.btn-outline-primary {
  background-color: #3498db; /* Change to your primary color */
  color: #fff; /* Text color */
  padding: 10px 20px; /* Adjust padding as needed */
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 10px; /* Adjust font size as needed */
}



/* Danger Button */
.btn-outline-danger {
  background-color: #e74c3c; /* Change to your danger color */
  color: #fff; /* Text color */
  padding: 10px 20px; /* Adjust padding as needed */
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 10px; /* Adjust font size as needed */
}  
.cf_start_btn:disabled,
.cf_start_btn:hover {
 background-color: grey !important;
 color: white !important;

}
.cf_end_btn:disabled,
.cf_end_btn:hover {
 background-color: grey !important;
 color: white !important;
}
   
</style>
 <div id="cf_controls">
    <div class="header">
        <h3>fb-tool Controls</h3>
        <hr>
    </div>
    <div class="body">
        <div class="buttons">
            <button class="btn btn-outline-primary cf_btn cf_start_btn">Start</button>
            <button class="btn btn-outline-primary cf_btn cf_stop_btn" style="display: none">Stop</button>
            <button class="btn btn-outline-danger cf_btn cf_cancel_btn">Cancel</button>
        </div>
        <div><p class="status_string"></p></div>
    </div>
</div>

<div class="cf_overlay"></div>
<div id="cf_controls" class="cf_progressBar">
<span class="close-icon" >&#10006;</span> <!-- Cross icon -->
<div class="cf_finished">

</div> 
<div class="cf_text">Ready to start? Click the "Start" button.</div>
<div class="cf_progressInfo">
  <span class="cf_done status_string"></span> 
</div> 
<div class="cf_btn_container">
<button class="btn btn-outline-primary cf_btn cf_start_btn">Start</button>
<button class="btn btn-outline-danger cf_btn cf_cancel_btn">Stop</button>
</div>
</div>`;

  $(document.body).append(cont_html);
}

function displayMsgCancelation(msg, status) {
  console.log(cancellationCount, "cancelcount")
  let status_string = "";
  let main_text = "";
  main_text = "Total Number Of count: " + cancellationCount + " Finished";
  $("#cf_controls .status_string").text(status_string);
  $(".cf_text").text(main_text);
  $(".cf_start")
    .prop("disabled", true)
    .text("Start")
    .css({
      color: "white",
      "background-color": "grey",
    })
    .show();
  $(".cf_cancel_btn")
    .prop("disabled", true)
    .text("Stopped")
    .css({
      color: "white",
      "background-color": "grey",
    })
    .show();
}
function closeControlsPopup() {
  $("#cf_controls").remove();
  $(".cf_overlay").remove();
}
function updateStatusString(cancellationCount) {
  let status_string = "";
  let main_text = "";
  main_text = "Total Number Of count: " + cancellationCount;
  $("#cf_controls .status_string").text(status_string);
  $(".cf_text").text(main_text);
  
}

async function startProcess() {
  $(".cf_start_btn")
    .prop("disabled", true)
    .text("Start")
    .css({
      color: "white",
      "background-color": "grey",
    })
    .show();
  $(".status_string").text("Waiting to begin...");
  $(".cf_stop_btn").show();

  active_status = true;
  await sleep(minDelayOnPost * 1000);
  chrome.storage.local.get(null, async (storeRes) => {
    const apiRes = await chrome.runtime.sendMessage({ type: "a" });
    if (apiRes.status) {
      cancelSentRequest(storeRes, "cancel");
    }
  });
}


function cancelProcess() {
  stopProcess();
  $(".cf_overlay").remove();
  $("#cf_controls").remove();
}

function sleep(t) {
  return new Promise((e) => setTimeout(e, t));
}

//end
async function scrollToBottom() {
  var initialHeight = document.querySelector(
    'div[class="xb57i2i x1q594ok x5lxg6s x78zum5 xdt5ytf x6ikm8r x1ja2u2z x1pq812k x1rohswg xfk6m8 x1yqm8si xjx87ck xx8ngbg xwo3gff x1n2onr6 x1oyok0e x1odjw0f x1e4zzel x1tbbn4q x1y1aw1k x4uap5 xwib8y2 xkhd6sd"]'
  ).scrollHeight;

  $(
    'div[class="xb57i2i x1q594ok x5lxg6s x78zum5 xdt5ytf x6ikm8r x1ja2u2z x1pq812k x1rohswg xfk6m8 x1yqm8si xjx87ck xx8ngbg xwo3gff x1n2onr6 x1oyok0e x1odjw0f x1e4zzel x1tbbn4q x1y1aw1k x4uap5 xwib8y2 xkhd6sd"]'
  )[0].scrollTo({
    behavior: "smooth",
    top: Number.MAX_SAFE_INTEGER,
  });

  await sleep(1000);

  var currentHeight = document.querySelector(
    'div[class="xb57i2i x1q594ok x5lxg6s x78zum5 xdt5ytf x6ikm8r x1ja2u2z x1pq812k x1rohswg xfk6m8 x1yqm8si xjx87ck xx8ngbg xwo3gff x1n2onr6 x1oyok0e x1odjw0f x1e4zzel x1tbbn4q x1y1aw1k x4uap5 xwib8y2 xkhd6sd"]'
  ).scrollHeight;
  if (currentHeight != initialHeight) {
    await scrollToBottom();
    // requestAnimationFrame(scrollToBottom);
  } else {
    chrome.storage.local.get(null, async (storeRes) => {
      console.log(storeRes);
      const apiRes = await chrome.runtime.sendMessage({ type: "a" });
      if (apiRes.status) {
        cancelSentRequestBottom(storeRes, "cancel");
      }
    });
  }
}
async function cancelSentRequest(savedData, status) {
  var totalFriends = parseInt(savedData.friends);
  var count = parseInt(savedData.betweenFriends);
  let beginStatus = true;
   cancellationCount = 0;
  if (status == "cancel") {
    var mainDiv = document.querySelector('div[aria-label="Sent requests" i]');

    var htmlCode = "";
    mainDiv.insertAdjacentHTML("afterbegin", htmlCode);

    if (requestCancationalData?.friendsType == "2") {
      await scrollToBottom();
    return;
    }

    for (let i = 0; i < totalFriends; i++) {
      if (requestCancationalData?.friendsType == "2") {
      } else {
        if (active_status == false) {
          break;
        }
        if (await isStopTask()) {
          console.log(cancellationCount,"cancellationCount");
          displayMsgCancelation(message.stopped, "success");
          break;
        }
        if (beginStatus) {
          const parentDiv = mainDiv.querySelector(
            'div[data-visualcompletion="ignore-dynamic" i]'
          );
          const actionBtn = parentDiv.querySelector(
            'div[aria-label="Cancel Request" i]'
          );

          if (!actionBtn) {
            displayMsgCancelation(message.noFriends, "Finished");
            break;
          }
          actionBtn.click();
          setTimeout(() => {
            if (beginStatus) {
              console.log(parentDiv,"prentDiv")
              parentDiv.remove();
              cancellationCount++;
              updateStatusString(cancellationCount);
              //   document.querySelector(
              //     ".sent-request-information"
              //   )?.innerText = `${cancellationCount} cancellations`;
            }
          }, 1000);

          await perDelay(savedData.minDelay, savedData.maxDelay);

          if (await finishedTask(totalFriends, i)) break;

          if (count == i + 1 && savedData.isOnbetweenFriends) {
            count += count;
            await beetBetweenDelay(parseInt(savedData.betweenDelay));
          }
        }
      }
    }
    displayMsgCancelation();
  } else {
    beginStatus = false;
    return cancellationCount;
  }
}
async function cancelSentRequestBottom(savedData, status) {
  var totalFriends = parseInt(savedData.friends);
  var count = parseInt(savedData.betweenFriends);
  let beginStatus = true;
   cancellationCount = 0;
  if (status == "cancel") {
    var mainDiv = document.querySelector('div[aria-label="Sent requests" i]');

    var htmlCode = "";
    mainDiv.insertAdjacentHTML("afterbegin", htmlCode);
    for (let i = 0; i < totalFriends; i++) {

      if (active_status == false) {
        break;
      }
      if (await isStopTask()) {
        displayMsgCancelation(message.stopped, "success");
        break;
      }
      const parentDiv = mainDiv.querySelector(
        'div[data-visualcompletion="ignore-dynamic" i]'
      );
      console.log(parentDiv,"parendDiv")
      let allCancelBtn = document.querySelectorAll(
        'div[aria-label="Sent requests" i] div[aria-label="Cancel Request" i]'
      );
      // const actionBtn = parentDiv.querySelector(
      //   'div[aria-label="Cancel Request" i]'
      // );
      const actionBtn = allCancelBtn[allCancelBtn.length - 1];

      console.log("action btn-----------", actionBtn);
      if (!actionBtn) {
        displayMsgCancelation(message.noFriends, "warning");
        break;
      }
      actionBtn.click();
      cancellationCount++;
      updateStatusString(cancellationCount);
      actionBtn.addEventListener("click", ()=>{
        window.scrollBy(0, -100);
        console.log(counted,"countred")
      })
      setTimeout(() => {
        if (beginStatus) {
          parentDiv.remove();
          console.log(parentDiv,"parendDiv1")
        }
      }, 1000);
      if(i==totalFriends-1){
        displayMsgCancelation();
        break;
      }
      await perDelayForOther(savedData.minDelay, savedData.maxDelay);

      if (await finishedTask(totalFriends, i)) break;

      if (count == i + 1 && savedData.isOnbetweenFriends) {
        count += count;
        await beetBetweenDelay(parseInt(savedData.betweenDelay));
      }
    }
    // displayMsgCancelation();
  } else {
    beginStatus = false;
    return cancellationCount;
  }
}
function stopProcess() {
  $(".cf_start_btn")
    .prop("disabled", true)
    .text("Start")
    .css({
      color: "white",
      "background-color": "grey",
    })
    .show();
  $(".status_string").text("");
  active_status = false;
  cancelSentRequest({}, "stop");
  let main_text = "";
  main_text = "Total Number Of count: " + cancellationCount + " Finished";
  $(".cf_text").text(main_text);
}

async function unfriend(savedData) {
  var totalFriends = parseInt(savedData.friends);
  var count = parseInt(savedData.betweenFriends);
  var mainDiv =
    document.querySelector('div[aria-label="All Friends" i]') ||
    document.querySelector('div[aria-label="All friends" i]');
  for (let i = 0; i < totalFriends; i++) {
    if (await isStopTask()) {
      displayMsg(message.stopped, "success");
      break;
    }

    try {
      await auth();
    } catch (e) {
      break;
    }

    const parentDiv = mainDiv.querySelector(
      'div[data-visualcompletion="ignore-dynamic" i]'
    );
    var moreBtn;
    try {
      moreBtn = await findElement('div[aria-label="More" i]', parentDiv);
    } catch (e) { }

    try {
      moreBtn.click();
    } catch (e) {
      console.log(e);
    }

    const actionListMainDom = await findElement(
      'div[class="x1n2onr6 xcxhlts x1fayt1i"]',
      null
    );
    const actionList = actionListMainDom.querySelectorAll(
      'div[role="menuitem" i]'
    );
    actionList[actionList.length - 1].click();
    try {
      var actionBtn = await findElement('div[aria-label="Confirm" i]');
      actionBtn.click();
    } catch (e) {
      try {
        var actionBtn = await findElement('div[aria-label="Confirm" i]');
        actionBtn.click();
      } catch (e) {
        displayMsg(message.noFriends, "warning");
        break;
      }
    }
    setTimeout(() => {
      parentDiv.remove();
    }, 1000);
    await perDelay(savedData.minDelay, savedData.maxDelay);

    if (await finishedTask(totalFriends, i)) break;

    if (count == i + 1 && savedData.isOnbetweenFriends) {
      count += count;
      await beetBetweenDelay(parseInt(savedData.betweenDelay));
    }
  }
}

// Listen for messages from the background script
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === "deleteMessages") {
    setupFacebookMessagesCleaner(request.data);
  } else if (request.action == "BeginPostLoverTool") {
    startAutomation(request.data);
  } else if (request.action == "startCommentReply") {
    startCommentReply();
  }
});

async function startCommentReply() {
  const commentContainerCss =
    ".x1n2onr6.x1swvt13.x1iorvi4.x78zum5.x1q0g3np.x1a2a7pz";
  let commentContainerBox = document.querySelectorAll(commentContainerCss);
  console.log(
    "Number of posts:",
    commentContainerBox.length,
    commentContainerBox
  );
  let numberOfPosts = commentContainerBox.length;
  // Send a message to the extension with the data
  chrome.runtime.sendMessage({
    action: "commentReplyComplete",
    data: {
      numberOfPosts: numberOfPosts,
      // Add other data you want to send back
    },
  });
}

function setupFacebookMessagesCleaner(limit) {
  let strVar = `
        <div id="ird" style="position:fixed; opacity:1; width:100%; top:0; left:0; background-color:rgba(72, 155, 219, 1); color:white; box-shadow:5px 5px 50px #efefef; z-index:99999999999999; height:55px; font-family:tahoma;">
            <span id="donate"></span>
            <h2 style="text-align:center; color:white; font-size:18px; font-weight:500; margin:0; margin-top:17px;">
                Facebook Messages Cleaner <small>(<span id='num'> ........... </span>)</small>
            </h2>
            <button id="btnclose" style="float:right; margin-right:40px; cursor:pointer; background-color:#d9534f; color:white; border:1px solid maroon; margin-top:-25px; border-radius:5px; padding:4px; font-size:15px;">Close</button>
        </div>
        `;

  if (!document.querySelector("#ird")) {
    document.body.insertAdjacentHTML("afterbegin", strVar);
  }

  document.querySelector("#btnclose").addEventListener("click", function () {
    window.location.reload();
  });

  let dm = 0; // Number of deleted messages
  let tt = 0;

  let ssm = setInterval(function () {
    tt++;
    let numElements = document.querySelectorAll(
      "a[href*='/messages/t/']"
    ).length;
    document.querySelector(
      "#num"
    ).textContent = `Getting ${numElements} Messages. Please wait.`;
    if (tt === 5) {
      deletefbmessage();
      clearInterval(ssm);
    }
  }, 500);

  function deletefbmessage() {
    // Stop deletion process if the limit is reached
    if (dm >= limit) {
      document.querySelector(
        "#num"
      ).textContent = `Delete Finished. ${dm} Messages were Deleted.`;
      return;
    }

    let elms = Array.from(
      document.querySelectorAll("a[href*='/messages/t/']")
    ).map((elm) => {
      let parentRow = elm.closest('[role="row"]');
      if (getComputedStyle(parentRow).visibility !== "hidden") {
        return parentRow;
      }
    })[0];

    if (elms) {
      let button = elms.querySelector(".x10f5nwc.xi81zsa");
      if (button) {
        button.click();
        let s2 = setInterval(function () {
          let deleteBtn = Array.from(
            document.querySelectorAll('[role="menuitem"]')
          ).find((el) => el.textContent.includes("Delete"));
          if (deleteBtn) {
            deleteBtn.click();
            clearInterval(s2);
            let s3 = setInterval(function () {
              let confirmBtn = document.querySelector(
                ".n75z76so.ed17d2qt,.x1s688f.xtk6v10"
              );
              if (confirmBtn) {
                clearInterval(s3);
                elms.setAttribute("dfmsgs", "true");
                confirmBtn.click();
                dm++;
                if (dm < limit) {
                  setTimeout(deletefbmessage, 2000);
                } else {
                  document.querySelector(
                    "#num"
                  ).textContent = `Delete Finished. ${dm} Messages were Deleted.`;
                }
              }
            }, 500);
          }
        }, 500);
      }
    }
  }
}

// content.js

// Listen for messages from the background script
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === "simulateClickOnInviteButton") {
    // Find the invite button based on the group ID and simulate a click
    alert("hi");
    const groupId = request.groupId;
    const inviteButton = document.querySelector(
      `.invite-btn[data-group-id="${groupId}"]`
    );
    console.log(inviteButton, "inpuvit----------------------------");
    if (inviteButton) {
      // Modify this part to match your specific class names for the invite friend button
      const inviteFriendButton = inviteButton.querySelector(
        ".x1lliihq.x6ikm8r.x10wlt62.x1n2onr6.xlyipyv.xuxw1ft"
      );
      console.log(
        inviteFriendButton,
        "inviteFriendButtoninviteFriendButtoninviteFriendButtoninviteFriendButtoninviteFriendButtoninviteFriendButton"
      );
      if (inviteFriendButton) {
        inviteFriendButton.click();
      } else {
        console.error("Invite friend button not found");
      }
    }
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log(message.action, "message");

  switch (message.action) {
    case "BeginPostLoverTool":
      // Perform some action in response to the message
      console.log(message.message, "messag-------------------");
      // setTimeout(startAutomation, 2000);
      chrome.tabs.create({ url: "https://www.facebook.com" }, (tab) => {
        chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
          if (tabId === tab.id && changeInfo.status === "complete") {
            startAutomation(tabId, message);
            chrome.tabs.onUpdated.removeListener(listener);
          }
        });
      });
      break;

    case "InviteOwnGroupContentScript":
      groupCheckBoxAutomation(message);
      break;

    default:
      // Default case if message.message doesn't match any of the specified cases
      break;
  }
});
function sleep(t) {
  return new Promise((e) => setTimeout(e, t));
}

async function groupCheckBoxAutomation(data) {
  let active_status = false;
  console.log(data, "data-----------------");
  // alert("HELLO WORLD");
  const inviteButton = document.querySelector('[aria-label="Invite"]').click();
  setTimeout(() => {
    var element = document.querySelector(
      ".x1i10hfl.xjbqb8w.x6umtig.x1b1mbwd.xaqea5y.xav7gou.xe8uvvx.x1hl2dhg.xggy1nq.x1o1ewxj.x3x9cwd.x1e5q0jg.x13rtm0m.x87ps6o.x1lku1pv.x1a2a7pz.xjyslct.x9f619.x1ypdohk.x78zum5.x1q0g3np.x2lah0s.xnqzcj9.x1gh759c.xdj266r.xat24cr.x1344otq.x1de53dj.x1n2onr6.x16tdsg8.x1ja2u2z.x6s0dn4.x1y1aw1k.xwib8y2"
    );

    // Check if the element is found
    if (element) {
      // Trigger a click event
      element.click();
    }

    console.log(element, "elements");
  }, 500);

  await sleep(3000);
  var parentDiv = document.querySelector(
    ".x9f619.x1n2onr6.x1ja2u2z.x78zum5.x2lah0s.x13a6bvl.x1qjc9v5.xozqiw3.x1q0g3np.x1pi30zi.x1swvt13.xyamay9.xykv574.xbmpl8g.x4cne27.xifccgj"
  );
  console.log(parentDiv, "parentDiv");

  // // Create a new button element
  // var newButton = document.createElement("button");
  // newButton.className =
  //   "x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1h6gzvc x1o1ewxj x3x9cwd x1e5q0jg x13rtm0m x87ps6o x1lku1pv x1a2a7pz x9f619 x3nfvp2 xdt5ytf xl56j7k x1n2onr6 xh8yej3";
  // newButton.setAttribute("role", "button");
  // newButton.setAttribute("tabindex", "0");
  // newButton.setAttribute("disabled", false);

  // // Set the content of the new button
  // newButton.innerHTML =
  //   '<div role="none" class="x1n2onr6 x1ja2u2z x78zum5 x2lah0s xl56j7k x6s0dn4 xozqiw3 x1q0g3np xi112ho x17zwfj4 x585lrc x1403ito x972fbf xcfux6l x1qhh985 xm0m39n x9f619 xn6708d x1ye3gou xjbqb8w x1r1pt67"><div class="x6s0dn4 x78zum5 xl56j7k x1608yet xljgi0e x1e0frkt"><div role="none" class="x9f619 x1n2onr6 x1ja2u2z x193iq5w xeuugli x6s0dn4 x78zum5 x2lah0s x1fbi1t2 xl8fo4v"><span class="x193iq5w xeuugli x13faqbe x1vvkbs x10flsy6 x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x x4zkp8e x41vudc x6prxxf xvq8zen x1s688f x1mvi0mv" dir="auto"><span class="x1lliihq x6ikm8r x10wlt62 x1n2onr6 xlyipyv xuxw1ft">NewButton</span></span></div></div><div class="x1o1ewxj x3x9cwd x1e5q0jg x13rtm0m x1ey2m1c xds687c xg01cxk x47corl x10l6tqk x17qophe x13vifvy x1ebt8du x19991ni x1dhq9h" data-visualcompletion="ignore" role="none"></div></div>';

  // // Append the new button to the parent div
  // parentDiv?.appendChild(newButton);

  let buttonOuterdiv = document.createElement("div");
  buttonOuterdiv.classList.add("select_all_btn_div");

  let newButton = `
    <style>
      button#friendInviterToGroup_select_all_btn {
        padding: 13px;
        font-size: medium;
        color: white;
        background: blue;
        border: none;
        border-radius: 12px;
        cursor: pointer;
        height: fit-content;
      }
      .select_all_btn_div {
        position: absolute;
        right: 280px;
      }
    </style>
    <button type="button" id="friendInviterToGroup_select_all_btn" class="btn btn-primary">
      Select All
    </button>`;
  // let parentInnerTemp = parentDiv.innerHTML;
  // parentDiv.innerHTML = newButton + parentInnerTemp;
  buttonOuterdiv.innerHTML = newButton;
  parentDiv.append(buttonOuterdiv);

  $("#friendInviterToGroup_select_all_btn").click(async () => {
    // console.log("click on friendInviterToGroup");
    // $("#friendInviterToGroup_select_all_btn").prop("disabled", true);
    if ($("#friendInviterToGroup_select_all_btn").text() == "Stop") {
      $("#friendInviterToGroup_select_all_btn").text("Select All");
      active_status = false;
    } else {
      $("#friendInviterToGroup_select_all_btn").text("Stop");
      active_status = true;
      await startProcessToSelectAll();
    }
  });
  const startProcessToSelectAll = async () => {
    if (active_status === true) {
      await startActionSelect();
      await sleep(2000);
      await startProcessToSelectAll();
    } else {
      $("#friendInviterToGroup_select_all_btn").prop("disabled", false);
    }
  };
  const startActionSelect = async () => {
    if (
      $(
        'div[class="xb57i2i x1q594ok x5lxg6s x78zum5 xdt5ytf x6ikm8r x1ja2u2z x1pq812k x1rohswg xfk6m8 x1yqm8si xjx87ck x1l7klhg x1iyjqo2 xs83m0k x2lwn1j xx8ngbg xwo3gff x1n2onr6 x1oyok0e x1odjw0f x1e4zzel"] div[data-visualcompletion="ignore-dynamic"]:not(.gone-through) [class="x1b0d499 x1d69dk1"]'
      )[0]
    ) {
      let currentBtn = $(
        'div[class="xb57i2i x1q594ok x5lxg6s x78zum5 xdt5ytf x6ikm8r x1ja2u2z x1pq812k x1rohswg xfk6m8 x1yqm8si xjx87ck x1l7klhg x1iyjqo2 xs83m0k x2lwn1j xx8ngbg xwo3gff x1n2onr6 x1oyok0e x1odjw0f x1e4zzel"] div[data-visualcompletion="ignore-dynamic"]:not(.gone-through) [class="x1b0d499 x1d69dk1"]'
      )[0];

      await scrollToBtn(currentBtn);
      await sleep(2000);
      currentBtn.click();
      $(currentBtn)
        .closest('div[data-visualcompletion="ignore-dynamic"]')
        .addClass("gone-through");
    } else {
      let initialScrollHeight = $(
        'div[class="xb57i2i x1q594ok x5lxg6s x78zum5 xdt5ytf x6ikm8r x1ja2u2z x1pq812k x1rohswg xfk6m8 x1yqm8si xjx87ck x1l7klhg x1iyjqo2 xs83m0k x2lwn1j xx8ngbg xwo3gff x1n2onr6 x1oyok0e x1odjw0f x1e4zzel"]'
      )[0].scrollHeight;
      loadMoreFriends();
      await sleep(2000);
      let currentScrollHeight = $(
        'div[class="xb57i2i x1q594ok x5lxg6s x78zum5 xdt5ytf x6ikm8r x1ja2u2z x1pq812k x1rohswg xfk6m8 x1yqm8si xjx87ck x1l7klhg x1iyjqo2 xs83m0k x2lwn1j xx8ngbg xwo3gff x1n2onr6 x1oyok0e x1odjw0f x1e4zzel"]'
      )[0].scrollHeight;

      if (currentScrollHeight === initialScrollHeight) {
        active_status = false;
        $("#friendInviterToGroup_select_all_btn").text("Select All");
        console.log("Page has reached the end");
        alert("Page has reached the end");
        return;
      }
    }
    // console.log("Page has reached the", $(
    //   'div[class="xb57i2i x1q594ok x5lxg6s x78zum5 xdt5ytf x6ikm8r x1ja2u2z x1pq812k x1rohswg xfk6m8 x1yqm8si xjx87ck x1l7klhg x1iyjqo2 xs83m0k x2lwn1j xx8ngbg xwo3gff x1n2onr6 x1oyok0e x1odjw0f x1e4zzel"]'
    // )[0].scrollHeight);
  };

  const scrollToBtn = async (currentBtn) => {
    let offsetTopRow = await $(currentBtn).closest(
      'div[data-visualcompletion="ignore-dynamic"]'
    )[0].offsetTop;

    $(
      'div[class="xb57i2i x1q594ok x5lxg6s x78zum5 xdt5ytf x6ikm8r x1ja2u2z x1pq812k x1rohswg xfk6m8 x1yqm8si xjx87ck x1l7klhg x1iyjqo2 xs83m0k x2lwn1j xx8ngbg xwo3gff x1n2onr6 x1oyok0e x1odjw0f x1e4zzel"]'
    )[0].scrollTo({
      top: offsetTopRow,
      behavior: "smooth",
    });
  };

  const loadMoreFriends = async () => {
    $(
      'div[class="xb57i2i x1q594ok x5lxg6s x78zum5 xdt5ytf x6ikm8r x1ja2u2z x1pq812k x1rohswg xfk6m8 x1yqm8si xjx87ck x1l7klhg x1iyjqo2 xs83m0k x2lwn1j xx8ngbg xwo3gff x1n2onr6 x1oyok0e x1odjw0f x1e4zzel"]'
    )[0].scrollTo({
      top: Number.MAX_SAFE_INTEGER,
      behavior: "smooth",
    });
  };
}
const popupClass = document?.querySelector(".x8cjs6t.x13fuv20.x178xt8z");


function startAutomation(data) {
  console.log(data, "data");
  // Like and comment on the first post
  likeAndComment(data);
}
let loveFind = [];
// function likeAndComment(data) {
//    loveFind = document.querySelectorAll(
//     ".x1i10hfl.x1qjc9v5.xjbqb8w.xjqpnuy.xa49m3k.xqeqjp1.x2hbi6w.x13fuv20.xu3j5b3.x1q0q8m5.x26u7qi.x972fbf.xcfux6l.x1qhh985.xm0m39n.x9f619.x1ypdohk.xdl72j9.x2lah0s.xe8uvvx.xdj266r.x11i5rnm.xat24cr.x1mh8g0r.x2lwn1j.xeuugli.xexx8yu.x4uap5.x18d9i69.xkhd6sd.x1n2onr6.x16tdsg8.x1hl2dhg.x1ja2u2z.x1t137rt.x1o1ewxj.x3x9cwd.x1e5q0jg.x13rtm0m.x3nfvp2.x1q0g3np.x87ps6o.x1lku1pv.x1a2a7pz.x5ve5x3"
//   );
//   //  const loveFind=  document.querySelectorAll("x9f619 x1n2onr6 x1ja2u2z x78zum5 xdt5ytf x193iq5w xeuugli x1r8uery x1iyjqo2 xs83m0k");
//   // if (loveFind.length > 0) {
//     for (let i = 0; i < parseInt(data.numberOfPost); i++) {
//       // Like the post
//       loveFind[i].click();
//       const mainFunc = "1";
//       setTimeout(
//         scrollDown(data, mainFunc),
//         parseInt(data.minDelayOnPost * 16.66)
//       );
//     }
//   // } else {
//   //   const mainFunc = "2";
//   //   scrollDown(data, mainFunc);
//   // }
// }
// function likeAndComment(data) {
//    loveFind = document.querySelectorAll(
//     ".x1i10hfl.x1qjc9v5.xjbqb8w.xjqpnuy.xa49m3k.xqeqjp1.x2hbi6w.x13fuv20.xu3j5b3.x1q0q8m5.x26u7qi.x972fbf.xcfux6l.x1qhh985.xm0m39n.x9f619.x1ypdohk.xdl72j9.x2lah0s.xe8uvvx.xdj266r.x11i5rnm.xat24cr.x1mh8g0r.x2lwn1j.xeuugli.xexx8yu.x4uap5.x18d9i69.xkhd6sd.x1n2onr6.x16tdsg8.x1hl2dhg.x1ja2u2z.x1t137rt.x1o1ewxj.x3x9cwd.x1e5q0jg.x13rtm0m.x3nfvp2.x1q0g3np.x87ps6o.x1lku1pv.x1a2a7pz.x5ve5x3"
//   );
//   const numberOfPosts = parseInt(data.numberOfPost);
//   console.log(numberOfPosts, "NUMBEROFOPOST");
//   console.log(loveFind, "loveFind");
//   for (let i = 0; i < numberOfPosts; i++) {
//     console.log(loveFind,"loveFind")
//     loveFind[i]?.click();
//     const mainFunc = "1";
//     setTimeout(
//       () => scrollDown(data, mainFunc),
//       parseInt(data.minDelayOnPost) * 16.66
//     );
//     loveFind = document.querySelectorAll(
//       ".x1i10hfl.x1qjc9v5.xjbqb8w.xjqpnuy.xa49m3k.xqeqjp1.x2hbi6w.x13fuv20.xu3j5b3.x1q0q8m5.x26u7qi.x972fbf.xcfux6l.x1qhh985.xm0m39n.x9f619.x1ypdohk.xdl72j9.x2lah0s.xe8uvvx.xdj266r.x11i5rnm.xat24cr.x1mh8g0r.x2lwn1j.xeuugli.xexx8yu.x4uap5.x18d9i69.xkhd6sd.x1n2onr6.x16tdsg8.x1hl2dhg.x1ja2u2z.x1t137rt.x1o1ewxj.x3x9cwd.x1e5q0jg.x13rtm0m.x3nfvp2.x1q0g3np.x87ps6o.x1lku1pv.x1a2a7pz.x5ve5x3"
//     );
//     console.log(loveFind,"loveFind")
//   }
// }
// function scrollDown(data, mainFunc) {
//   const scrollAmount = 3000;
//   window.scrollTo({
//     top: window.scrollY + scrollAmount,
//     behavior: "smooth",
//   });
// }
// function likeAndComment(data) {
//   const postSelector =
//     ".x1i10hfl.x1qjc9v5.xjbqb8w.xjqpnuy.xa49m3k.xqeqjp1.x2hbi6w.x13fuv20.xu3j5b3.x1q0q8m5.x26u7qi.x972fbf.xcfux6l.x1qhh985.xm0m39n.x9f619.x1ypdohk.xdl72j9.x2lah0s.xe8uvvx.xdj266r.x11i5rnm.xat24cr.x1mh8g0r.x2lwn1j.xeuugli.xexx8yu.x4uap5.x18d9i69.xkhd6sd.x1n2onr6.x16tdsg8.x1hl2dhg.x1ja2u2z.x1t137rt.x1o1ewxj.x3x9cwd.x1e5q0jg.x13rtm0m.x3nfvp2.x1q0g3np.x87ps6o.x1lku1pv.x1a2a7pz.x5ve5x3";

//   const loveFind = document.querySelectorAll(postSelector);
//   const numberOfPosts = parseInt(data.numberOfPost);

//   async function likePostAndScroll(index) {
//     const post = loveFind[index];
//     if (post) {
//       post.click();
//       await sleep(parseInt(data.minDelayOnPost) * 16.66);
//       window.scrollTo({
//         top: window.scrollY + 3000,
//         behavior: "smooth",
//       });
//       await sleep(500);
//     }
//   }

//   async function sleep(ms) {
//     return new Promise(resolve => setTimeout(resolve, ms));
//   }
//   async function likeAndScrollLoop() {
//     for (let i = 0; i < numberOfPosts; i++) {
//       await likePostAndScroll(i);
//       console.log("-----",i)
//       await sleep(5000)
//     }
//   }
//   likeAndScrollLoop();
// }

function likeAndComment(data) {
  const postSelector =
    ".x1i10hfl.x1qjc9v5.xjbqb8w.xjqpnuy.xa49m3k.xqeqjp1.x2hbi6w.x13fuv20.xu3j5b3.x1q0q8m5.x26u7qi.x972fbf.xcfux6l.x1qhh985.xm0m39n.x9f619.x1ypdohk.xdl72j9.x2lah0s.xe8uvvx.xdj266r.x11i5rnm.xat24cr.x1mh8g0r.x2lwn1j.xeuugli.xexx8yu.x4uap5.x18d9i69.xkhd6sd.x1n2onr6.x16tdsg8.x1hl2dhg.x1ja2u2z.x1t137rt.x1o1ewxj.x3x9cwd.x1e5q0jg.x13rtm0m.x3nfvp2.x1q0g3np.x87ps6o.x1lku1pv.x1a2a7pz.x5ve5x3";

  let loveFind = document.querySelectorAll(postSelector);

  const numberOfPosts = parseInt(data.numberOfPost);
  const commentSelector =
    "xi81zsa x6ikm8r x10wlt62 x47corl x10l6tqk x17qophe xlyipyv x13vifvy x87ps6o xuxw1ft xh8yej3";
  async function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  async function likeAndScrollLoop() {
    let scrollAmount = 3000;
    window.scrollTo({
      top: window.scrollY + 3000,
      behavior: "smooth",
    });
    for (let i = 0; i < numberOfPosts; i++) {
      await sleep(3000);
      loveFind = document.querySelectorAll(postSelector);
      const post = loveFind[i];
      const nextPost = document.querySelectorAll(
        ".x1yztbdb.x1n2onr6.xh8yej3.x1ja2u2z"
      )[i + 1];
      console.log("nodelist", loveFind);
      console.log("---->", await nextPost.offsetTop);
      console.log("content height:", nextPost.clientHeight);
      // document.querySelectorAll(".x1yztbdb.x1n2onr6.xh8yej3.x1ja2u2z")
      let offsetHeight = await nextPost?.offsetTop;
      let contentHeight = nextPost.clientHeight;
      await sleep(parseInt(data.minDelayOnPost) * 16.66);
      window.scrollTo({
        top: offsetHeight + contentHeight - 250,
        behavior: "smooth",
      });
      // await sleep(500);
      if (post) {
        post.click();
        // const mouseEnterEvent = new Event('click', { bubbles: true });
        //  const myData= post.dispatchEvent(mouseEnterEvent);
        //  var elementsWithAriaLabel = document.querySelectorAll('[aria-label="Leave a comment"]');

        // //  elementsWithAriaLabel.forEach(function(element) {
        // //   // Do something with each element
        // //    console.log(element.click(alert("sadashgd")));
        // // });
        //   elementsWithAriaLabel[i].click();
        //   var comment = document.querySelector('[data-lexical-text]');
        //   comment.innerHtml = "Hack comment";
        //   console.log(comment,"comement");
        //   const bigCommentButton = document.querySelectorAll(".x9f619.x1n2onr6.x1ja2u2z.x78zum5.x1r8uery.x1iyjqo2.xs83m0k.xeuugli.xl56j7k.x6s0dn4.xozqiw3.x1q0g3np.xn6708d.x1ye3gou.xexx8yu.xcud41i.x139jcc6.x4cne27.xifccgj.xn3w4p2.xuxw1ft");
        //   console.log(bigCommentButton,"bigCommentButton");
        //   bigCommentButton[1].click();
        //   var elementss = document.querySelectorAll('.xdj266r.x11i5rnm.xat24cr.x1mh8g0r');
        //   console.log(elementss,"elements")
        //   // Get the value inside the <span> tag
        //  elementss.querySelector('span').value = "Hi";
        //    elementss.querySelector('span').innerText = "Hi";

        //   }
        //   var submitButton = document.querySelector(".x1ey2m1c.xds687c.xg01cxk.x47corl.x10l6tqk.x17qophe.x13vifvy.x1ebt8du.x19991ni.x1dhq9h.x1wpzbip.x14yjl9h.xudhj91.x18nykt9.xww2gxu")
        //   submitButton.click();
      }
      // scrollAmount += 3000
      console.log("-----", i);
      await sleep(5000);
    }
  }
  likeAndScrollLoop();
}
