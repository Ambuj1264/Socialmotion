document.addEventListener("DOMContentLoaded", function () {
  const emailInput = document.getElementById("exampleInputEmail1");
  const passwordInput = document.getElementById("exampleInputEmail2");
  const signInButton = document.getElementById("signInButton");
  emailInput.addEventListener("input", function () {
    validateEmail();
  });
  passwordInput.addEventListener("input", function () {
    validatePassword();
  });

  $(document).ready(function () {
    $('#togglePassword').on('click', function () {
        const passwordInput = $('#exampleInputEmail2');
        const passwordFieldType = passwordInput.attr('type');

        // Toggle between password and text
        passwordInput.attr('type', passwordFieldType === 'password' ? 'text' : 'password');

        // Toggle eye icon
        const eyeIcon = $('#togglePassword i');
        eyeIcon.toggleClass('fa-eye-slash fa-eye');
    });
});

  signInButton.addEventListener("click", async function (event) {
    event.preventDefault(); // Prevent form submission for this example
    const isValidEmail = validateEmail();
    const isValidPassword = validatePassword();
    if (isValidEmail && isValidPassword) {
       const email = emailInput.value.trim().toLowerCase();
      const password = passwordInput.value.trim();
      console.log(email, "email");
      const url = "https://socialmotion.vercel.app/api/login";
      const data = {
          email: email,
          password: password,
      };

      try {
        const response = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            
          },
          body: JSON.stringify(data),
        });

        if (response.ok) {
          const responseData = await response.json();
          if (responseData.data.login) {
            localStorage.setItem(
              "AUTH_TOKEN",
              responseData?.data?.login?.token
            );
            localStorage.setItem(
              "USER_DATA",
              JSON.stringify({
                email: responseData?.data?.login?.email,
                password: responseData?.data?.login?.password,
                name: responseData?.data?.login?.name,
              })
            );

            chrome.storage.sync.set({
              email: email,
              password: password,
              token: responseData?.data?.login?.token,
            });
            chrome.tabs.create({
              url: `chrome-extension://${chrome.runtime.id}/html/index.html`,
            });
            chrome.tabs.query(
              { active: true, currentWindow: true },
              function (tabs) {
                chrome.tabs.sendMessage(tabs[0].id, {
                  email: email,
                  password: password,
                });
              }
            );
          } else {
            const loginError = document.getElementById("emailValidation");
            loginError.innerHTML = "Email or password are not matched";
          }
        } else {
          throw new Error("Network response was not ok.");
        }
      } catch (error) {
        console.error("Error:", error);
        // Handle errors here
      }
    } else {
      console.log("Please fill in all required fields correctly.");
    }
  });

  function validateEmail() {
    const email = emailInput.value.trim();
    const emailValidation = document.getElementById("emailValidation");
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email === "") {
      emailValidation.textContent = "Email address is required";
      return false;
    } else if (!emailRegex.test(email)) {
      emailValidation.textContent = "Please enter a valid email address";
      return false;
    } else {
      emailValidation.textContent = "";
      return true;
    }
  }
  function validatePassword() {
    const password = passwordInput.value.trim();
    const passwordValidation = document.getElementById("passwordValidation");
    if (password === "") {
      passwordValidation.textContent = "Password is required";
      return false;
    } else if (password.length < 8) {
      passwordValidation.textContent =
        "Password should be at least 8 characters long";
      return false;
    } else {
      passwordValidation.textContent = "";
      return true;
    }
  }
});
document.addEventListener("keypress", function (event) {
  if (event.key === "Enter") {
    event.preventDefault(); // Prevent the default Enter key behavior (e.g., form submission)
    signInButton.click(); // Simulate a click on the signInButton
  }
});
document.getElementById("forgot-password").addEventListener("click", () => {
  chrome.tabs.create({
    url: `chrome-extension://${chrome.runtime.id}/html/send-forget-password.html`,
  });
});
